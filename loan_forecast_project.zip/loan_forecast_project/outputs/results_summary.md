# Ontario loan balance forecast — results summary

Target: organic q/q log change of `loan_balance` (inorganic events removed). Estimation 2002Q2–2025Q4; backtest origins 2010Q4 onward, 1–9 quarters ahead, macro paths at actual values.

## Selection funnel

- Moody's + constructed variables: **406**
- Relevant geography & theme: **175**
- With a stationary transform: **175**
- Pass screen (sig. + right sign): **101**
- Independent clusters: **44**
- Shortlist: **25**
- Final champion drivers: **2**

## Champion drivers

- **Loan growth last quarter (momentum)** — coef 0.2072, t = 3.35. 0.21 of last quarter's growth carries into this quarter (persistence).
- **Single-detached price index, Toronto** — coef 0.1206, t = 9.73. A 1 % increase in Single-detached price index, Toronto [q/q % growth] raises q/q loan growth by 0.121 pp 1 quarter later; cumulative long-run effect 0.152 pp.
- **Personal disposable income, Ontario (C$)** — coef 0.2773, t = 5.55. A 1 % increase in Personal disposable income, Ontario (C$) [q/q % growth] raises q/q loan growth by 0.277 pp 1 quarter later; cumulative long-run effect 0.350 pp.

## Model comparison (average level MAPE over 1–9 quarters, COVID windows excluded)

| Model | Inputs | Avg MAPE ex-COVID | h=4 | h=9 | vs AR |
|---|---|---|---|---|---|
| AR(1) benchmark | 0 drivers | 1.50% | 1.30% | 2.50% | +0% |
| Champion (data-driven) | 2 drivers | 0.61% | 0.50% | 1.04% | +59% |
| Elastic Net (post-selection OLS) | 6 drivers | 0.63% | 0.57% | 0.93% | +58% |
| Literature ARDL (classic) | 5 drivers | 0.84% | 0.79% | 1.30% | +44% |
| Literature ECM | 5 drivers | 0.90% | 0.85% | 1.31% | +40% |
| Literature ARDL (ECB BEAST 2023) | 5 drivers | 1.51% | 1.33% | 2.52% | -1% |
| Champion + deposits (2-eq.) | 2 drivers | 0.64% | 0.51% | 1.08% | +58% |
| Ridge (whole shortlist) | 25 drivers | 0.84% | 0.69% | 1.43% | +44% |
| Factor model (Stock-Watson) | 3 factors from 173 series | 1.03% | 0.84% | 1.78% | +31% |
| Targeted factors (Bai-Ng) | 2 factors from 101 series | 1.12% | 0.88% | 1.98% | +25% |
| Forecast combination (top 10) | 10 models, 11 distinct drivers | 0.55% | 0.46% | 0.90% | +64% |
| ARIMAX (champion drivers) | 2 drivers | 0.64% | 0.54% | 1.05% | +57% |
| Quantile regression (median) | 2 drivers | 0.72% | 0.61% | 1.23% | +52% |
| Gradient boosting (challenger) | 25 drivers | 1.04% | 0.83% | 1.87% | +30% |
| Random forest (challenger) | 25 drivers | 0.96% | 0.79% | 1.63% | +36% |
| Theory ARDL (literature core) | 4 drivers | 0.77% | 0.65% | 1.32% | +49% |
| Theory ridge (core, all lags) | 13 drivers | 0.91% | 0.72% | 1.61% | +39% |
| Theory quantile regression | 4 drivers | 0.75% | 0.67% | 1.22% | +50% |
| Theory ARIMAX | 4 drivers | 0.81% | 0.66% | 1.40% | +46% |
| Theory-restricted factors | 3 factors from 90 series | 0.94% | 0.84% | 1.52% | +37% |
| Theory random forest | 13 drivers | 1.05% | 0.90% | 1.73% | +30% |
| Theory combination (4 literature models) | 4 models, 9 distinct drivers | 0.66% | 0.60% | 1.03% | +56% |
| Hybrid: theory core + data add-ons | 4 drivers | 0.77% | 0.65% | 1.32% | +49% |
| Hybrid: theory-anchored ridge | 28 drivers | 0.79% | 0.67% | 1.36% | +47% |
| Unconstrained data mining (no theory) | 4 drivers | 0.55% | 0.52% | 0.84% | +63% |
| Hybrid: theory long run + data short run | 2 drivers | 0.73% | 0.72% | 1.04% | +51% |
| Hybrid: theory channels, data measures | 4 drivers | 0.86% | 0.71% | 1.44% | +43% |
| Hybrid: 50/50 data + theory | 2 models, 5 distinct drivers | 0.68% | 0.56% | 1.18% | +55% |
| Hybrid: performance-weighted | 3 models, 8 distinct drivers | 0.67% | 0.61% | 1.05% | +55% |

## Diagnostics

| model                                    |   n_obs |   adj_R2 |    AIC |    BIC |   n_macro_drivers |   max_abs_p_driver |   Ljung-Box p (4) |   Ljung-Box p (8) |   Breusch-Pagan p |   Jarque-Bera p |   Durbin-Watson |   CUSUM p |   max VIF | wrong-sign drivers   |
|:-----------------------------------------|--------:|---------:|-------:|-------:|------------------:|-------------------:|------------------:|------------------:|------------------:|----------------:|----------------:|----------:|----------:|:---------------------|
| AR(1) benchmark                          |      95 |    0.381 | -756.2 | -735.8 |                 0 |           nan      |             0.234 |             0.375 |             0.666 |           0.694 |            2.12 |     0.679 |      1    | none                 |
| Champion (data-driven)                   |      95 |    0.675 | -815.7 | -790.1 |                 2 |             0      |             0.23  |             0.546 |             0.57  |           0.961 |            2.23 |     0.275 |      1.2  | none                 |
| Elastic Net (post-selection OLS)         |      95 |    0.705 | -821.4 | -785.7 |                 6 |             0.2553 |             0.612 |             0.909 |             0.848 |           0.873 |            2.05 |     0.33  |      3.19 | none                 |
| Literature ARDL (classic)                |      95 |    0.629 | -800.4 | -767.2 |                 5 |             0.6977 |             0.799 |             0.985 |             0.552 |           0.419 |            2.15 |     0.311 |      4.46 | FRMORT5Y.IC|diff|L4  |
| Literature ECM                           |      95 |    0.658 | -807.4 | -771.7 |                 5 |             0.4701 |             0.912 |             0.978 |             0.648 |           0.231 |            2.03 |     0.121 |      4.46 | FRMORT5Y.IC|diff|L4  |
| Literature ARDL (ECB BEAST 2023)         |      95 |    0.391 | -753.4 | -720.2 |                 5 |             0.9405 |             0.505 |             0.718 |             0.745 |           0.82  |            2.08 |     0.691 |     28.95 | none                 |
| Champion + deposits (2-eq.)              |      95 |    0.672 | -813.8 | -785.7 |                 2 |             0      |             0.236 |             0.556 |             0.184 |           0.994 |            2.22 |     0.279 |      1.2  | none                 |
| Ridge (whole shortlist)                  |     nan |  nan     |  nan   |  nan   |               nan |           nan      |           nan     |           nan     |           nan     |         nan     |          nan    |   nan     |    nan    | nan                  |
| Factor model (Stock-Watson)              |      95 |    0.609 | -794.6 | -758.8 |                 6 |             0.6712 |             0.772 |             0.61  |             0.985 |           0.76  |            2.02 |     0.104 |      2.69 | none                 |
| Targeted factors (Bai-Ng)                |      95 |    0.638 | -803.7 | -773   |                 4 |             0.3939 |             0.508 |             0.606 |             0.859 |           0.958 |            2    |     0.015 |      1.67 | none                 |
| Forecast combination (top 10)            |     nan |  nan     |  nan   |  nan   |               nan |           nan      |           nan     |           nan     |           nan     |         nan     |          nan    |   nan     |    nan    | nan                  |
| ARIMAX (champion drivers)                |     nan |  nan     |  nan   |  nan   |               nan |           nan      |           nan     |           nan     |           nan     |         nan     |          nan    |   nan     |    nan    | nan                  |
| Quantile regression (median)             |     nan |  nan     |  nan   |  nan   |               nan |           nan      |           nan     |           nan     |           nan     |         nan     |          nan    |   nan     |    nan    | nan                  |
| Gradient boosting (challenger)           |     nan |  nan     |  nan   |  nan   |               nan |           nan      |           nan     |           nan     |           nan     |         nan     |          nan    |   nan     |    nan    | nan                  |
| Random forest (challenger)               |     nan |  nan     |  nan   |  nan   |               nan |           nan      |           nan     |           nan     |           nan     |         nan     |          nan    |   nan     |    nan    | nan                  |
| Theory ARDL (literature core)            |      95 |    0.683 | -816.3 | -785.6 |                 4 |             0.7506 |             0.653 |             0.818 |             0.524 |           0.592 |            2.13 |     0.158 |      1.75 | FRMORT5Y.IC|diff|L4  |
| Theory ridge (core, all lags)            |     nan |  nan     |  nan   |  nan   |               nan |           nan      |           nan     |           nan     |           nan     |         nan     |          nan    |   nan     |    nan    | nan                  |
| Theory quantile regression               |     nan |  nan     |  nan   |  nan   |               nan |           nan      |           nan     |           nan     |           nan     |         nan     |          nan    |   nan     |    nan    | nan                  |
| Theory ARIMAX                            |     nan |  nan     |  nan   |  nan   |               nan |           nan      |           nan     |           nan     |           nan     |         nan     |          nan    |   nan     |    nan    | nan                  |
| Theory-restricted factors                |      95 |    0.649 | -804.8 | -769   |                 6 |             0.8665 |             0.86  |             0.946 |             0.909 |           0.429 |            2.07 |     0.108 |      2.03 | none                 |
| Theory random forest                     |     nan |  nan     |  nan   |  nan   |               nan |           nan      |           nan     |           nan     |           nan     |         nan     |          nan    |   nan     |    nan    | nan                  |
| Theory combination (4 literature models) |     nan |  nan     |  nan   |  nan   |               nan |           nan      |           nan     |           nan     |           nan     |         nan     |          nan    |   nan     |    nan    | nan                  |
| Hybrid: theory core + data add-ons       |      95 |    0.683 | -816.3 | -785.6 |                 4 |             0.7506 |             0.653 |             0.818 |             0.524 |           0.592 |            2.13 |     0.158 |      1.75 | FRMORT5Y.IC|diff|L4  |
| Hybrid: theory-anchored ridge            |     nan |  nan     |  nan   |  nan   |               nan |           nan      |           nan     |           nan     |           nan     |         nan     |          nan    |   nan     |    nan    | nan                  |
| Unconstrained data mining (no theory)    |      95 |    0.724 | -829.4 | -798.8 |                 4 |             0.0016 |             0.424 |             0.516 |             0.832 |           0.024 |            2.09 |     0.208 |      2.08 | none                 |
| Hybrid: theory long run + data short run |      95 |    0.683 | -817.1 | -789   |                 2 |             0.0002 |             0.413 |             0.723 |             0.399 |           0.788 |            2.11 |     0.197 |      1.2  | none                 |
| Hybrid: theory channels, data measures   |      95 |    0.637 | -803.5 | -772.8 |                 4 |             0.0484 |             0.895 |             0.908 |             0.206 |           0.944 |            2.09 |     0.131 |      1.14 | none                 |
| Hybrid: 50/50 data + theory              |     nan |  nan     |  nan   |  nan   |               nan |           nan      |           nan     |           nan     |           nan     |         nan     |          nan    |   nan     |    nan    | nan                  |
| Hybrid: performance-weighted             |     nan |  nan     |  nan   |  nan   |               nan |           nan      |           nan     |           nan     |           nan     |         nan     |          nan    |   nan     |    nan    | nan                  |

Engle-Granger cointegration p-value for the literature long-run relation: 0.001

## Year-end balance by scenario ($ millions)

scenario                                         Baseline  S1 Upside  S3 Downside  S4 Severe
model                                    date                                               
AR(1) benchmark                          2026Q4  162995.0   162995.0     162995.0   162995.0
                                         2027Q4  169428.0   169428.0     169428.0   169428.0
                                         2028Q4  176100.0   176100.0     176100.0   176100.0
                                         2029Q4  183033.0   183033.0     183033.0   183033.0
                                         2030Q4  190240.0   190240.0     190240.0   190240.0
ARIMAX (champion drivers)                2026Q4  162703.0   163513.0     160869.0   159081.0
                                         2027Q4  169137.0   170667.0     166323.0   162548.0
                                         2028Q4  175874.0   178038.0     173270.0   169477.0
                                         2029Q4  182896.0   185569.0     179988.0   176127.0
                                         2030Q4  190199.0   193256.0     186967.0   182800.0
Champion (data-driven)                   2026Q4  162801.0   163663.0     160930.0   159084.0
                                         2027Q4  169194.0   170924.0     165910.0   161585.0
                                         2028Q4  175919.0   178395.0     172869.0   168481.0
                                         2029Q4  182934.0   186013.0     179569.0   175120.0
                                         2030Q4  190228.0   193768.0     186487.0   181687.0
Champion + deposits (2-eq.)              2026Q4  162796.0   163659.0     160927.0   159082.0
                                         2027Q4  169194.0   170922.0     165929.0   161606.0
                                         2028Q4  175931.0   178398.0     172907.0   168528.0
                                         2029Q4  182957.0   186022.0     179621.0   175184.0
                                         2030Q4  190264.0   193784.0     186557.0   181772.0
Elastic Net (post-selection OLS)         2026Q4  162625.0   163524.0     160672.0   158746.0
                                         2027Q4  168991.0   170913.0     165251.0   160462.0
                                         2028Q4  175809.0   178548.0     172473.0   167610.0
                                         2029Q4  182938.0   186316.0     179438.0   174668.0
                                         2030Q4  190353.0   194189.0     186547.0   181494.0
Factor model (Stock-Watson)              2026Q4  163665.0   164666.0     161066.0   158782.0
                                         2027Q4  170583.0   172653.0     166438.0   161489.0
                                         2028Q4  177854.0   180754.0     174528.0   169991.0
                                         2029Q4  185431.0   188969.0     182040.0   177752.0
                                         2030Q4  193314.0   197299.0     189779.0   185341.0
Forecast combination (top 10)            2026Q4  162506.0   163259.0     160935.0   159344.0
                                         2027Q4  168828.0   170439.0     165684.0   161606.0
                                         2028Q4  175542.0   177838.0     172740.0   168596.0
                                         2029Q4  182549.0   185375.0     179629.0   175579.0
                                         2030Q4  189831.0   193033.0     186664.0   182387.0
Gradient boosting (challenger)           2026Q4  162596.0   163349.0     160864.0   159431.0
                                         2027Q4  168153.0   170475.0     164870.0   161996.0
                                         2028Q4  174532.0   177591.0     172320.0   169686.0
                                         2029Q4  181325.0   185236.0     178065.0   176091.0
                                         2030Q4  188399.0   192724.0     183779.0   181723.0
Hybrid: 50/50 data + theory              2026Q4  162776.0   163700.0     160795.0   158829.0
                                         2027Q4  169160.0   171014.0     165661.0   161017.0
                                         2028Q4  175881.0   178520.0     172660.0   167980.0
                                         2029Q4  182889.0   186153.0     179365.0   174652.0
                                         2030Q4  190173.0   193905.0     186288.0   181229.0
Hybrid: performance-weighted             2026Q4  162490.0   163446.0     160498.0   158493.0
                                         2027Q4  168655.0   170661.0     164774.0   159739.0
                                         2028Q4  175207.0   178179.0     171361.0   165954.0
                                         2029Q4  182090.0   185887.0     177807.0   172232.0
                                         2030Q4  189264.0   193710.0     184482.0   178453.0
Hybrid: theory channels, data measures   2026Q4  162241.0   162874.0     161015.0   159712.0
                                         2027Q4  168654.0   169988.0     166153.0   162643.0
                                         2028Q4  175335.0   177255.0     173094.0   169535.0
                                         2029Q4  182286.0   184650.0     179879.0   176411.0
                                         2030Q4  189503.0   192179.0     186806.0   183101.0
Hybrid: theory core + data add-ons       2026Q4  162751.0   163737.0     160661.0   158573.0
                                         2027Q4  169126.0   171103.0     165413.0   160451.0
                                         2028Q4  175843.0   178645.0     172451.0   167480.0
                                         2029Q4  182844.0   186292.0     179161.0   174184.0
                                         2030Q4  190119.0   194042.0     186089.0   180772.0
Hybrid: theory long run + data short run 2026Q4  161971.0   162995.0     159802.0   157658.0
                                         2027Q4  167606.0   169998.0     162801.0   156942.0
                                         2028Q4  173663.0   177479.0     168216.0   161191.0
                                         2029Q4  180068.0   185246.0     173698.0   165880.0
                                         2030Q4  186785.0   193188.0     179515.0   170761.0
Hybrid: theory-anchored ridge            2026Q4  162671.0   163653.0     160552.0   158453.0
                                         2027Q4  169050.0   171043.0     165255.0   160270.0
                                         2028Q4  175760.0   178585.0     172309.0   167337.0
                                         2029Q4  182751.0   186225.0     179031.0   174077.0
                                         2030Q4  190014.0   193967.0     185972.0   180693.0
Literature ARDL (ECB BEAST 2023)         2026Q4  163045.0   163097.0     162938.0   162842.0
                                         2027Q4  169319.0   169472.0     168726.0   168314.0
                                         2028Q4  175682.0   176003.0     175139.0   174288.0
                                         2029Q4  182341.0   182910.0     181933.0   181176.0
                                         2030Q4  189297.0   190054.0     188632.0   187865.0
Literature ARDL (classic)                2026Q4  162286.0   163135.0     160842.0   159174.0
                                         2027Q4  168573.0   170263.0     165555.0   161101.0
                                         2028Q4  175181.0   177567.0     172305.0   167650.0
                                         2029Q4  182079.0   185004.0     178935.0   174237.0
                                         2030Q4  189249.0   192559.0     185742.0   180704.0
Literature ECM                           2026Q4  161462.0   162589.0     159335.0   157087.0
                                         2027Q4  166858.0   169506.0     161467.0   154825.0
                                         2028Q4  172818.0   177096.0     166682.0   158584.0
                                         2029Q4  179265.0   185080.0     172251.0   163578.0
                                         2030Q4  186050.0   193148.0     178089.0   168627.0
Quantile regression (median)             2026Q4  162860.0   163860.0     160708.0   158592.0
                                         2027Q4  169158.0   171244.0     165128.0   159946.0
                                         2028Q4  175808.0   178818.0     172038.0   166718.0
                                         2029Q4  182747.0   186511.0     178613.0   173225.0
                                         2030Q4  189961.0   194306.0     185364.0   179549.0
Random forest (challenger)               2026Q4  162447.0   163142.0     161107.0   160088.0
                                         2027Q4  168008.0   170033.0     165137.0   163126.0
                                         2028Q4  174154.0   177057.0     172113.0   170110.0
                                         2029Q4  180695.0   184220.0     178333.0   176863.0
                                         2030Q4  187508.0   191469.0     184569.0   182814.0
Ridge (whole shortlist)                  2026Q4  162630.0   163454.0     160771.0   158977.0
                                         2027Q4  168986.0   170849.0     165178.0   160557.0
                                         2028Q4  175738.0   178459.0     172179.0   167376.0
                                         2029Q4  182804.0   186246.0     179030.0   174245.0
                                         2030Q4  190168.0   194184.0     186085.0   181001.0
Targeted factors (Bai-Ng)                2026Q4  163138.0   163839.0     161679.0   160191.0
                                         2027Q4  169375.0   170591.0     167174.0   163890.0
                                         2028Q4  175908.0   177492.0     174988.0   172293.0
                                         2029Q4  182775.0   184707.0     181625.0   179098.0
                                         2030Q4  189959.0   192100.0     188314.0   185507.0
Theory ARDL (literature core)            2026Q4  162751.0   163737.0     160661.0   158573.0
                                         2027Q4  169126.0   171103.0     165413.0   160451.0
                                         2028Q4  175843.0   178645.0     172451.0   167480.0
                                         2029Q4  182844.0   186292.0     179161.0   174184.0
                                         2030Q4  190119.0   194042.0     186089.0   180772.0
Theory ARIMAX                            2026Q4  162679.0   163605.0     160622.0   158594.0
                                         2027Q4  169106.0   170846.0     165951.0   161640.0
                                         2028Q4  175839.0   178274.0     172973.0   168701.0
                                         2029Q4  182853.0   185830.0     179696.0   175398.0
                                         2030Q4  190142.0   193513.0     186682.0   182088.0
Theory combination (4 literature models) 2026Q4  162385.0   163139.0     160939.0   159405.0
                                         2027Q4  168466.0   170085.0     165270.0   161102.0
                                         2028Q4  174877.0   177325.0     171616.0   166906.0
                                         2029Q4  181627.0   184818.0     178034.0   173179.0
                                         2030Q4  188673.0   192445.0     184595.0   179357.0
Theory quantile regression               2026Q4  162746.0   163824.0     160499.0   158251.0
                                         2027Q4  169032.0   171348.0     164560.0   158758.0
                                         2028Q4  175682.0   178971.0     171589.0   165757.0
                                         2029Q4  182599.0   186621.0     178292.0   172547.0
                                         2030Q4  189770.0   194321.0     185179.0   179113.0
Theory random forest                     2026Q4  162593.0   163151.0     160575.0   159546.0
                                         2027Q4  168977.0   170436.0     165766.0   163163.0
                                         2028Q4  175643.0   178226.0     172889.0   170404.0
                                         2029Q4  182649.0   185856.0     179461.0   176845.0
                                         2030Q4  189924.0   193367.0     186180.0   182852.0
Theory ridge (core, all lags)            2026Q4  162738.0   163675.0     160807.0   158859.0
                                         2027Q4  169109.0   170939.0     165621.0   161018.0
                                         2028Q4  175827.0   178382.0     172672.0   168075.0
                                         2029Q4  182821.0   185959.0     179466.0   174861.0
                                         2030Q4  190093.0   193656.0     186469.0   181592.0
Theory-restricted factors                2026Q4  162640.0   163698.0     160464.0   158274.0
                                         2027Q4  169070.0   171075.0     165249.0   160233.0
                                         2028Q4  175823.0   178503.0     172596.0   167805.0
                                         2029Q4  182823.0   186003.0     179663.0   175071.0
                                         2030Q4  190089.0   193577.0     186937.0   182286.0
Unconstrained data mining (no theory)    2026Q4  162938.0   163869.0     160958.0   158975.0
                                         2027Q4  169396.0   171209.0     166048.0   161500.0
                                         2028Q4  176195.0   178767.0     173112.0   168529.0
                                         2029Q4  183290.0   186469.0     179883.0   175247.0
                                         2030Q4  190670.0   194302.0     186889.0   181903.0
