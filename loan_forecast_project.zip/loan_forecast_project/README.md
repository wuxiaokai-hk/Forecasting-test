# Ontario Loan Balance Forecast — explainable macro model

Forecasts the Ontario loan balance from ~400 Moody's Canada macro variables plus internal deposits.
The pipeline narrows the 400 down to a handful of drivers you can explain. It then compares that model against
a benchmark, a literature-based specification and a machine-learning challenger, and forecasts every Moody's scenario.

## Files

| File | What it does |
|---|---|
| `simulate_data.py` | Builds **simulated** data in the same layout as the real inputs (writes `data/`). The true loan equation is printed at the end, so you can check what the pipeline recovers. |
| `loan_forecast_pipeline.py` | The full project, steps 1–11. All settings are in the `CONFIG` and `LITERATURE` blocks at the top. |
| `outputs/` | Tables (CSV and `model_results.xlsx`), 7 charts, and `results_summary.md`. |

Run: `pip install pandas numpy statsmodels scikit-learn scipy matplotlib openpyxl tabulate`
then `python simulate_data.py` and `python loan_forecast_pipeline.py` (about 3 minutes).

## Pipeline steps

1. **Target.** Loan growth is the q/q log change of the balance, which you confirmed is stationary (ADF and KPSS are reported).
   Inorganic events listed in `bank_events.csv` (acquisitions, portfolio sales) are removed so they don't look like
   economic growth: g_t = log((L_t − A_t)/L_{t−1}).
2. **Relevance and transforms.** The pipeline keeps Ontario and Canada variables and drops "Other" and industry-detail themes.
   It adds six constructed variables: the real mortgage rate, the mortgage spread, the term spread, real house prices,
   real income per capita, and payment-to-income. Every variable is tried in several forms:
   - **Levels:** q/q growth, y/y growth, 2-quarter growth, acceleration, gap from the 3-year trailing average,
     and real (CPI-deflated) q/q and y/y growth.
   - **Rates:** q/q, 2-quarter and y/y change, the level itself, and gap from the 3-year average.

   All windows are one-sided (no look-ahead). Only forms that pass the ADF test are kept, each with lags 0–4.
3. **Univariate screen.** Each candidate is regressed alongside the loan-growth lag and the COVID dummies, using HAC t-stats.
   A candidate must be significant **and** have the economically expected sign.
4. **Redundancy.** Variables are clustered by correlation (|ρ| > 0.75 counts as the same information). Each cluster keeps one variable,
   and an Ontario series is preferred when it is nearly as strong as the best member.
5. **Selection.**
   - (a) An exhaustive search over 2–4 variables with constraints: correct signs, |t| > 1.96, VIF < 5, at most one variable per theme.
     The surviving combinations race on out-of-sample error. A **parsimony rule** then picks the simplest model within 5% of the best.
   - (b) An Elastic Net with time-series cross-validation, for comparison.
6. **Models compared (14).**
   - AR(1) benchmark
   - **Champion** (the data-driven selection)
   - Elastic Net model
   - Ridge on the whole shortlist
   - **Literature ARDL**
   - **Literature ECM**
   - Champion + deposits (two-equation system)
   - **Stock-Watson factor model**
   - **Bai-Ng targeted factors**
   - **Forecast combination** of the top 10 models
   - ARIMAX
   - Median quantile regression
   - Gradient-boosting challenger
   - Random-forest challenger

   The champion's scenario forecasts also get a bootstrap 10–90% band.
7. **Backtest.** Rolling origins from 2010Q4, forecasting 1–9 quarters ahead. Errors are measured on the **balance level**, both with and without the COVID windows.
   Coefficients are re-estimated at every origin, which produces the stability chart.
8. **Diagnostics.** Ljung-Box, Breusch-Pagan, Jarque-Bera, Durbin-Watson, CUSUM, VIF, and a wrong-sign check.
9. **Scenarios.** Every model is run under Baseline, S1, S3 and S4.
10. **Explainability.** A plain-language driver table (per-unit and long-run effects) and an exact dynamic contribution chart.

## Literature model (variables chosen from papers)

The full literature review and methodology are in `Methodology_and_Literature_Review.docx`.

| Concept | Variable | Expected sign | Source |
|---|---|---|---|
| Real GDP | FGDPR.ION | + | Hofmann (2001, BIS WP 108); Calza, Gartner & Sousa (2001, ECB WP 55; *Applied Economics* 2003); Guo & Stepanyan (2011, IMF WP 11/51) |
| Property prices | FHPI.ION | + | Hofmann (2001; 2004, *International Finance*) |
| Long-term lending rate | FRMORT5Y.IC | − | Calza et al. (2001); Hofmann (2001) |
| Short-term rate | FRBOC.IC | − | Calza et al. (2001); Hofmann (2001) |
| Inflation | FCPI.ION | ± | Guo & Stepanyan (2011) |
| Deposits / domestic funding | deposit growth | + | Guo & Stepanyan (2011), used in the two-equation model |

The **ECM** follows the long-run "credit demand" relation in Hofmann (2001) and Calza et al. (2001):
log real loans = a + b₁·log real GDP + b₂·log real house prices + b₃·real lending rate. An Engle-Granger cointegration test is reported.

## Switching to your real data

1. Bank file: `date, loan_balance, deposit_balance`. Dates can be `2020Q1` or actual dates. Set `BANK_FREQ="M"` if the data is monthly; it is converted to quarter-end.
2. Moody's: one CSV per scenario, with dates in the first column and one column per mnemonic, **history + forecast in the same file** (the usual Moody's export).
3. Metadata: `mnemonic, description, geography, theme, transform, expected_sign`. If the file is missing, the pipeline writes a
   guessed template and stops. **Review it carefully**: `expected_sign` (+1 / −1 / 0) and `theme` drive the selection rules,
   and this is where your economic judgement enters the model.
4. Update `HIST_END`, the `DUMMIES` dates, and the literature mnemonics so they match your database.
5. Options worth knowing:
   - `REQUIRED_THEMES=["Interest rates"]` forces a rate driver into the champion when stress tests need rate sensitivity.
     On the simulated data this costs about 0.1 pp of MAPE.
   - `ALLOWED_GEOGRAPHIES` and `EXCLUDED_THEMES` control the relevance filter.
   - `MAX_VARS` sets the maximum number of drivers.

## Caveats

- The backtest feeds in the **actual** macro paths (perfect foresight on the macro inputs), which is standard for scenario models.
  It measures model error, not Moody's forecast error.
- Deposits are internal, so the two-equation model must forecast them too. On the simulated data they add no accuracy, so the
  single-equation champion is the cleaner choice unless the deposit link is needed for planning.
- The gradient-boosting challenger is a check that the linear model isn't missing signal. It is not meant for production.

## Data vs theory, and hybrids (added)

- **Theory versions of every model type.** A "literature core" (Ontario house prices, disposable income,
  5-year mortgage rate, unemployment, each with a theory lag window) is estimated as ARDL, ridge, quantile regression,
  ARIMAX, theory-restricted factors, random forest, and as a combination of the four literature models.
  `outputs/17_data_vs_theory.csv` pairs each with its data-driven twin.
- **Six hybrids:**
  - theory core + data add-ons
  - theory-anchored ridge (core unpenalised)
  - theory long run + data short run (champion + literature error-correction term)
  - theory channels with data-chosen measures
  - 50/50 combination
  - performance-weighted combination (inverse-MSE weights computed only from past errors)
- **Encompassing tests** (`17c_encompassing_tests.csv`) show which model carries information at each horizon.
- **Unconstrained data-mining reference** (`RUN_UNCONSTRAINED`) shows what the theory constraints cost and buy.
- **Chart:** `outputs/08_data_vs_theory.png`.

There are now 29 models, and a full run takes about 5 minutes. Set `RUN_UNCONSTRAINED=False` to save about 30 seconds.
