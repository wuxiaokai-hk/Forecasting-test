"""
loan_forecast_pipeline.py
=========================
Explainable macro-driven forecast of a loan balance (Ontario section) using a large
Moody's-style macro database (~400 variables) plus internal financials (deposits).

Steps (each writes its own output table/chart into ./outputs):
  1. Load data, adjust the target for inorganic events, build log-difference target, stationarity tests
  2. Transform every macro variable (dlog / yoy for levels; diff / diff4 for rates), ADF test, lags 0..4
  3. Univariate screen: partial regression of loan growth on each candidate (controlling for AR term
     and dummies), HAC t-stats, economic sign check, best lag/transform per variable
  4. Redundancy removal: correlation clustering, keep the strongest variable per cluster -> shortlist
  5. Variable selection: (a) constrained exhaustive search ranked by out-of-sample error,
                         (b) Elastic Net with time-series cross-validation
  6. Models: AR benchmark, data-driven champion, Elastic Net model, literature ARDL, literature ECM,
             champion + deposits (two-equation system), gradient-boosting challenger
  7. Rolling-origin backtest (1-9 quarters, level errors), coefficient stability
  8. Diagnostics (Ljung-Box, Breusch-Pagan, Jarque-Bera, VIF, CUSUM)
  9. Scenario forecasts (Moody's baseline / upside / downside / severe)
 10. Explainability: driver table in plain language, dynamic contribution chart
 11. Excel workbook + markdown summary

Run:  python loan_forecast_pipeline.py
To use REAL data: edit CONFIG (file paths, column names, dates) and the LITERATURE block.
"""
import os
import re
import sys
import json
import itertools
import warnings
import subprocess
import importlib.util


# -----------------------------------------------------------------------------
# Auto-install missing packages into the SAME Python that runs this script
# (IDLE, VS Code, Terminal or Jupyter can each use a different Python).
# -----------------------------------------------------------------------------
def _ensure_packages():
    required = {"numpy": "numpy", "pandas": "pandas", "scipy": "scipy", "statsmodels": "statsmodels",
                "sklearn": "scikit-learn", "matplotlib": "matplotlib", "openpyxl": "openpyxl", "tabulate": "tabulate"}
    missing = [pip for mod, pip in required.items() if importlib.util.find_spec(mod) is None]
    if not missing:
        return
    print(f"Installing missing packages {missing}\n  into {sys.executable} ...", flush=True)
    base = [sys.executable, "-m", "pip", "install", "--quiet"]
    for extra in ([], ["--user"], ["--user", "--break-system-packages"]):
        if subprocess.call(base + extra + missing) == 0:
            # pip may fall back to a per-user install (even without --user); that folder may not
            # have existed when Python started, so make sure it is on the search path now.
            import site
            user_site = site.getusersitepackages()
            if user_site not in sys.path:
                sys.path.append(user_site)
            importlib.invalidate_caches()
            print("Packages installed.\n", flush=True)
            return
    sys.exit("\nAutomatic install failed. In Terminal run:\n"
             f"  {sys.executable} -m pip install {' '.join(missing)}\n"
             "If the error mentions SSL/certificates (python.org installer on macOS), first double-click\n"
             "'Install Certificates.command' in /Applications/Python 3.x/, then run the command again.")


_ensure_packages()

import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.tsa.stattools import adfuller, kpss
from statsmodels.stats.diagnostic import acorr_ljungbox, het_breuschpagan, breaks_cusumolsresid
from statsmodels.stats.stattools import jarque_bera, durbin_watson
from scipy.cluster.hierarchy import linkage, fcluster
from scipy.spatial.distance import squareform
from sklearn.linear_model import ElasticNetCV
from sklearn.model_selection import TimeSeriesSplit
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import RidgeCV
from statsmodels.tsa.statespace.sarimax import SARIMAX
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__))

# =============================================================================
# CONFIG  -- edit this block for the real data
# =============================================================================
CONFIG = {
    # ---- files -------------------------------------------------------------
    "BANK_FILE": os.path.join(HERE, "data", "bank_data.csv"),          # date, loan_balance, deposit_balance
    "EVENTS_FILE": os.path.join(HERE, "data", "bank_events.csv"),      # optional: date, series, amount
    "META_FILE": os.path.join(HERE, "data", "macro_metadata.csv"),     # mnemonic, description, theme, transform, expected_sign
    "SCENARIO_FILES": {                                                 # each = history + scenario path
        "Baseline": os.path.join(HERE, "data", "moodys_baseline.csv"),
        "S1 Upside": os.path.join(HERE, "data", "moodys_s1_upside.csv"),
        "S3 Downside": os.path.join(HERE, "data", "moodys_s3_downside.csv"),
        "S4 Severe": os.path.join(HERE, "data", "moodys_s4_severe.csv"),
    },
    "BASE_SCENARIO": "Baseline",
    "OUT_DIR": os.path.join(HERE, "outputs"),
    # ---- columns / dates ---------------------------------------------------
    "LOAN_COL": "loan_balance",
    "DEPOSIT_COL": "deposit_balance",
    "BANK_FREQ": "Q",                     # "Q" or "M" (monthly is converted to quarter-end)
    "HIST_END": "2025Q4",                 # last quarter of actual loan data
    "ESTIMATION_START": "2002Q2",         # first quarter used in regressions (leave room for lags)
    "BACKTEST_START": "2010Q4",           # first forecast origin in the rolling backtest
    "HORIZON": 9,                         # backtest horizon in quarters
    "MAX_LAG": 4,                         # lags 0..MAX_LAG tested for every macro variable
    # One dummy per COVID quarter: these observations cannot drive the coefficients or the selection
    "DUMMIES": {f"D_{q}": [q] for q in ["2020Q1", "2020Q2", "2020Q3", "2020Q4", "2021Q1", "2021Q2"]},
    "COVID_WINDOW": ["2020Q1", "2021Q2"], # target dates excluded from the "ex-COVID" error metrics
    # ---- selection rules ---------------------------------------------------
    "ADF_P": 0.05,                        # transformed variable must be stationary
    "SCREEN_P": 0.05,                     # univariate screen significance (HAC)
    "REQUIRE_SIGN_PRIOR": True,           # True = drop variables with expected_sign 0 (no economic prior)
    # Economic-relevance filter: an Ontario book should be explained by Ontario / Canada variables.
    # A variable is kept if its geography starts with one of these strings (CMAs are "Ontario - Toronto", ...)
    "ALLOWED_GEOGRAPHIES": ["Ontario", "Canada"],
    # Industry-level detail is excluded for a total (retail/mortgage) book; remove from the list for a commercial book.
    "EXCLUDED_THEMES": ["Other", "Output (by industry)", "Labour (by industry)"],
    # Within a cluster of near-duplicates, prefer the book's own geography if its |t| is >= REP_TOLERANCE x best
    "PRIMARY_GEOGRAPHY": "Ontario",
    "REP_TOLERANCE": 0.75,
    "CLUSTER_CORR": 0.75,                 # variables with |corr| above this are treated as redundant
    "SHORTLIST_MAX": 25,
    "MIN_VARS": 2, "MAX_VARS": 4,         # size of the final macro driver set
    "T_MIN": 1.96,                        # every driver must be significant
    "VIF_MAX": 5.0,
    "ONE_PER_THEME": True,                # at most one driver per economic theme
    # Force themes into every candidate combo, e.g. ["Interest rates", "Labour"] if the model must respond
    # to rate / unemployment shocks in stress tests. Empty = let the data decide.
    "REQUIRED_THEMES": [],
    "N_OOS_CANDIDATES": 300,              # best in-sample combos sent to the out-of-sample race
    "RANK_METRIC": "mape_exc",            # rank by average level MAPE h=1..H, excluding COVID windows
    # Parsimony rule (like the one-standard-error rule): among combos within this % of the best error,
    # pick the one with the fewest drivers, then the highest minimum |t|. Guards against winning by luck.
    "SELECTION_TOLERANCE": 0.05,
    "DEP_MAX_VARS": 3,                    # max drivers in the deposit equation
    # ---- transformations ---------------------------------------------------
    # Every variable is tried in each of these forms (x lags 0..MAX_LAG); only stationary forms survive.
    "TRANSFORMS_LEVEL": ["dlog", "yoy", "dlog2", "acc", "gap"],
    "TRANSFORMS_RATE": ["diff", "diff2", "diff4", "lvl", "rgap"],
    "REAL_THEMES": ["Income", "Housing", "Consumption", "Money & credit"],   # also tried deflated by CPI
    "DEFLATOR": "FCPI.ION",
    # ---- alternative models --------------------------------------------------
    "N_FACTORS": 3,                       # Stock-Watson diffusion-index factors
    "N_TARGETED_FACTORS": 2,              # Bai-Ng targeted-predictor factors
    "N_COMBINE": 10,                      # forecast combination: equal-weight average of the top-N combos
    "N_SIM": 1000,                        # bootstrap paths for the forecast fan chart
    # Reference point with NO theory: no sign priors, geography or theme rules (shows what theory buys)
    "RUN_UNCONSTRAINED": True,
}


# Constructed variables (built from Moody's series before transformation). Edit mnemonics to match your data.
def _annuity_payment(rate_pct, principal, years=25):
    r = rate_pct / 1200.0
    n = years * 12
    return principal * r / (1 - (1 + r) ** (-n))


CONSTRUCTED = [
    {"mnemonic": "XRMORTREAL.IC", "description": "Real 5-year mortgage rate (5Y rate minus Ontario CPI y/y inflation, %)",
     "geography": "Canada", "theme": "Interest rates", "transform": "diff", "expected_sign": -1,
     "fn": lambda m: m["FRMORT5Y.IC"] - 100 * np.log(m["FCPI.ION"]).diff(4)},
    {"mnemonic": "XMORTSPRD.IC", "description": "Mortgage spread: 5Y mortgage rate minus 5Y GoC yield (pp)",
     "geography": "Canada", "theme": "Credit spreads", "transform": "diff", "expected_sign": -1,
     "fn": lambda m: m["FRMORT5Y.IC"] - m["FRGOV5Y.IC"]},
    {"mnemonic": "XTERM.IC", "description": "Term spread: 10Y GoC yield minus overnight rate (pp)",
     "geography": "Canada", "theme": "Yield curve", "transform": "diff", "expected_sign": 0,
     "fn": lambda m: m["FRGOV10Y.IC"] - m["FRBOC.IC"]},
    {"mnemonic": "XHPIREAL.ION", "description": "Real house price index, Ontario (HPI / CPI)",
     "geography": "Ontario", "theme": "Housing", "transform": "dlog", "expected_sign": 1,
     "fn": lambda m: 100 * m["FHPI.ION"] / m["FCPI.ION"]},
    {"mnemonic": "XYPDPC.ION", "description": "Real disposable income per capita, Ontario",
     "geography": "Ontario", "theme": "Income", "transform": "dlog", "expected_sign": 1,
     "fn": lambda m: 1e5 * m["FYPD.ION"] / m["FCPI.ION"] / m["FPOPT.ION"]},
    {"mnemonic": "XPTI.ION", "description": "Mortgage payment-to-income, Ontario (annuity on HPI at 5Y rate / income)",
     "geography": "Ontario", "theme": "Affordability", "transform": "dlog", "expected_sign": -1,
     "fn": lambda m: 1000 * _annuity_payment(m["FRMORT5Y.IC"], m["FHPI.ION"]) / m["FYPD.ION"]},
]

# Literature-based specification. Each concept maps to a Moody's mnemonic in YOUR database.
LITERATURE = [
    {"concept": "Real GDP (economic activity)", "mnemonic": "FGDPR.ION", "transform": "dlog", "expected_sign": 1,
     "source": "Hofmann (2001, BIS WP 108); Calza, Gartner & Sousa (2001, ECB WP 55); Guo & Stepanyan (2011, IMF WP 11/51)"},
    {"concept": "Property prices", "mnemonic": "FHPI.ION", "transform": "dlog", "expected_sign": 1,
     "source": "Hofmann (2001, BIS WP 108; 2004, International Finance)"},
    {"concept": "Long-term lending rate", "mnemonic": "FRMORT5Y.IC", "transform": "diff", "expected_sign": -1,
     "source": "Calza, Gartner & Sousa (2001); Hofmann (2001)"},
    {"concept": "Short-term interest rate", "mnemonic": "FRBOC.IC", "transform": "diff", "expected_sign": -1,
     "source": "Calza, Gartner & Sousa (2001); Hofmann (2001)"},
    {"concept": "Inflation", "mnemonic": "FCPI.ION", "transform": "dlog", "expected_sign": 0,
     "source": "Guo & Stepanyan (2011): inflation raises nominal but lowers real credit growth"},
]
# Recent literature: loan-demand block of the ECB's BEAST stress-test model (Budnik et al., 2023, ECB WP 2855),
# which projects loan volumes dynamically from activity, prices, unemployment, rates and the yield curve.
LITERATURE_RECENT = [
    {"concept": "Real GDP growth", "mnemonic": "FGDPR.ION", "transform": "dlog", "expected_sign": 1,
     "source": "Budnik et al. (2023, ECB WP 2855, BEAST loan demand)"},
    {"concept": "Inflation", "mnemonic": "FCPI.ION", "transform": "dlog", "expected_sign": 1,
     "source": "Budnik et al. (2023): activity and inflation enter loan demand positively"},
    {"concept": "Change in unemployment", "mnemonic": "FLBR.ION", "transform": "diff", "expected_sign": -1,
     "source": "Budnik et al. (2023); Pugh, Wang & Webley (2026, BoC SAP 2026-12)"},
    {"concept": "Short-term interest rate", "mnemonic": "FRBOC.IC", "transform": "diff", "expected_sign": -1,
     "source": "Budnik et al. (2023): higher market rates reduce loan demand"},
    {"concept": "Term spread (long minus short)", "mnemonic": "XTERM.IC", "transform": "diff", "expected_sign": -1,
     "source": "Budnik et al. (2023); Bluwstein et al. (2023, J. Int. Econ.)"},
]

# "Best of the literature" core: the four channels most consistently supported for Canadian household/mortgage
# credit, with theory-based lag windows (rates pass through slowly because of 5-year renewals).
LITERATURE_CORE = [
    {"concept": "House prices (collateral)", "mnemonic": "FHPI.ION", "transform": "dlog", "lags": [0, 1, 2],
     "expected_sign": 1, "theme": "Housing",
     "source": "Hofmann (2001, 2004); Muellbauer, St-Amant & Williams (2015); Bailliu, Kartashova & Meh (2012)"},
    {"concept": "Household income", "mnemonic": "FYPD.ION", "transform": "dlog", "lags": [0, 1, 2],
     "expected_sign": 1, "theme": "Income",
     "source": "Muellbauer et al. (2015); Calza, Gartner & Sousa (2001); Guo & Stepanyan (2011)"},
    {"concept": "Mortgage rate (cost of credit)", "mnemonic": "FRMORT5Y.IC", "transform": "diff", "lags": [1, 2, 3, 4],
     "expected_sign": -1, "theme": "Interest rates",
     "source": "Calza et al. (2001); Bounajm & McWhirter (2024); Godbout, Su & Xu (2025)"},
    {"concept": "Unemployment (labour market)", "mnemonic": "FLBR.ION", "transform": "diff", "lags": [0, 1, 2],
     "expected_sign": -1, "theme": "Labour",
     "source": "Budnik et al. (2023, BEAST); Hirtle et al. (CLASS); Pugh, Wang & Webley (2026)"},
]
THEORY_THEMES = ["Housing", "Income", "Interest rates", "Labour", "Affordability", "Credit spreads"]

# Long-run (cointegrating) relation for the literature ECM, in the spirit of Hofmann (2001) / Calza et al. (2001):
# log real loans = a + b1 log real GDP + b2 log real house prices + b3 real lending rate
ECM_SPEC = {"deflator": "FCPI.ION", "gdp": "FGDPR.ION", "hpi": "FHPI.ION", "rate": "FRMORT5Y.IC"}

# ---- chart style (validated categorical palette, light surface) -------------
PAL = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#4a3aa7", "#e34948"]
INK, INK2, GRID, SURF = "#0b0b0b", "#52514e", "#e4e3df", "#fcfcfb"
plt.rcParams.update({
    "figure.facecolor": SURF, "axes.facecolor": SURF, "savefig.facecolor": SURF, "font.size": 10,
    "axes.edgecolor": GRID, "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2,
    "axes.titlecolor": INK, "axes.titlesize": 12, "axes.titleweight": "bold", "axes.titlelocation": "left",
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6, "axes.spines.top": False,
    "axes.spines.right": False, "axes.spines.left": False, "lines.linewidth": 2, "legend.frameon": False,
    "legend.labelcolor": INK2, "figure.dpi": 110,
})


# =============================================================================
# Helpers
# =============================================================================
META_GEO = {}


def log(msg):
    print(msg, flush=True)


def to_quarter_index(s):
    """Parse '2020Q1', '2020-03-31', etc. into a quarterly PeriodIndex."""
    s = pd.Series(s).astype(str)
    if s.str.match(r"^\d{4}\s*[Qq]\d$").all():
        return pd.PeriodIndex(s.str.replace(" ", "").str.upper(), freq="Q")
    return pd.PeriodIndex(pd.to_datetime(s), freq="Q")


def ols_np(X, y):
    XtX_inv = np.linalg.pinv(X.T @ X)
    b = XtX_inv @ X.T @ y
    e = y - X @ b
    n, k = X.shape
    s2 = e @ e / max(n - k, 1)
    se = np.sqrt(np.clip(np.diag(XtX_inv) * s2, 1e-30, None))
    return b, se, e


def vif_from_matrix(F):
    if F.shape[1] < 2:
        return np.ones(F.shape[1])
    R = np.corrcoef(F, rowvar=False)
    try:
        return np.diag(np.linalg.inv(R))
    except np.linalg.LinAlgError:
        return np.full(F.shape[1], np.inf)


def parse_feat(name):
    code, tr, lag = name.split("|")
    return code, tr, int(lag[1:])


# ---- Transformations ---------------------------------------------------------
# Level-type series (indexes, $ amounts, counts) are log-based; rate-type series (%, pp) are difference-based.
TR_DESC = {
    "dlog": "q/q % growth", "yoy": "y/y % growth", "dlog2": "2-quarter % growth",
    "acc": "acceleration (change in y/y growth vs a year ago)", "gap": "% gap from its 3-year trailing average",
    "rdlog": "real q/q % growth (deflated by CPI)", "ryoy": "real y/y % growth (deflated by CPI)",
    "diff": "q/q change", "diff2": "2-quarter change", "diff4": "y/y change", "lvl": "level",
    "rgap": "gap from its 3-year trailing average (pp)",
}
RATE_TRS = {"diff", "diff2", "diff4", "lvl", "rgap"}


def transform_col(mdf, code, tr):
    """Transform column `code` of macro frame `mdf`. All windows are one-sided (no look-ahead)."""
    x = mdf[code]
    if tr in RATE_TRS:
        if tr == "diff":
            return x.diff()
        if tr == "diff2":
            return x.diff(2)
        if tr == "diff4":
            return x.diff(4)
        if tr == "lvl":
            return x
        if tr == "rgap":
            return x - x.rolling(12, min_periods=12).mean()
    lx = np.log(x)
    if tr == "dlog":
        return lx.diff()
    if tr == "yoy":
        return lx.diff(4)
    if tr == "dlog2":
        return lx.diff(2)
    if tr == "acc":
        return lx.diff(4) - lx.diff(4).shift(4)
    if tr == "gap":
        return lx - lx.rolling(12, min_periods=12).mean()
    if tr in ("rdlog", "ryoy"):
        lp = np.log(mdf[CONFIG["DEFLATOR"]])
        k = 1 if tr == "rdlog" else 4
        return lx.diff(k) - lp.diff(k)
    raise ValueError(tr)


def feat(mdf, name):
    code, tr, lag = parse_feat(name)
    return transform_col(mdf, code, tr).shift(lag)


def describe_feat(name, meta):
    code, tr, lag = parse_feat(name)
    d = meta.loc[code, "description"] if code in meta.index else code
    trd = TR_DESC[tr]
    lagd = "same quarter" if lag == 0 else f"lag {lag}Q"
    return f"{d} ({trd}, {lagd})"


def short_label(name, meta, width=38):
    code, tr, lag = parse_feat(name)
    d = meta.loc[code, "description"] if code in meta.index else code
    d = re.sub(r"\s*\(.*?\)", "", d)
    d = d if len(d) <= width else d[:width - 1] + "…"
    return f"{d} [{tr}, L{lag}]"


def save(fig, name):
    path = os.path.join(CONFIG["OUT_DIR"], name)
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return path


# =============================================================================
# STEP 1 - Load data & build target
# =============================================================================
def load_bank(cfg):
    b = pd.read_csv(cfg["BANK_FILE"])
    b.index = to_quarter_index(b.iloc[:, 0])
    b = b.drop(columns=b.columns[0])
    if cfg["BANK_FREQ"] == "M":
        b = b.groupby(level=0).last()                # quarter-end balance
    b = b.sort_index()
    return b.loc[:pd.Period(cfg["HIST_END"], freq="Q")]


def organic_dlog(level, events, col):
    """Log growth with inorganic events removed: g_t = log((L_t - A_t) / L_{t-1})."""
    y = np.log(level).diff()
    if events is not None:
        for _, ev in events[events["series"] == col].iterrows():
            q = pd.Period(str(ev["date"]), freq="Q")
            if q in level.index:
                y.loc[q] = np.log((level.loc[q] - ev["amount"]) / level.shift(1).loc[q])
    return y


def load_macro(cfg):
    out = {}
    for s, fn in cfg["SCENARIO_FILES"].items():
        m = pd.read_csv(fn)
        m.index = to_quarter_index(m.iloc[:, 0])
        m = m.drop(columns=m.columns[0]).sort_index()
        out[s] = m.apply(pd.to_numeric, errors="coerce")
    return out


def build_metadata_template(macro, path):
    """For real Moody's data without metadata: guess transform/theme, leave expected_sign for you to fill."""
    themes = {"Interest rates": r"rate|yield|mortgage|prime|t-bill|bond", "Labour": r"employ|unemploy|labou?r",
              "Housing": r"house|housing|home|starts|permit|condo|rent", "Output": r"gdp|output|production",
              "Income": r"income|wage|earning", "Prices": r"cpi|price index|deflator|inflation",
              "Demographics": r"population|migration|household", "Financial markets": r"tsx|s&p|equity|stock",
              "Money & credit": r"credit|money|loan|debt"}
    rows = []
    for c in macro.columns:
        x = macro[c].dropna()
        is_rate = (x <= 0).any() or (x.between(-5, 25).all() and x.std() < 3)
        theme = next((k for k, v in themes.items() if re.search(v, c, re.I)), "Unassigned")
        rows.append({"mnemonic": c, "description": c, "geography": "Ontario" if c.upper().endswith(".ION") else "",
                     "theme": theme, "transform": "diff" if is_rate else "dlog", "expected_sign": 0})
    pd.DataFrame(rows).to_csv(path, index=False)
    log(f"Metadata template written to {path}. Fill description/theme/expected_sign, then re-run.")


def step1_target(cfg, bank, events):
    y = organic_dlog(bank[cfg["LOAN_COL"]], events, cfg["LOAN_COL"])
    yd = organic_dlog(bank[cfg["DEPOSIT_COL"]], events, cfg["DEPOSIT_COL"]) if cfg["DEPOSIT_COL"] in bank else None
    logL = np.log(bank[cfg["LOAN_COL"]].iloc[0]) + y.fillna(0).cumsum()          # organic log level
    rows = []
    for nm, s in [("log loan balance (level)", np.log(bank[cfg["LOAN_COL"]])), ("dlog loan balance (organic)", y)]:
        s = s.dropna()
        adf_p = adfuller(s, autolag="AIC")[1]
        kpss_p = kpss(s, regression="c", nlags="auto")[1]
        rows.append({"series": nm, "ADF p-value": round(adf_p, 4), "KPSS p-value": round(kpss_p, 4),
                     "stationary?": "yes" if (adf_p < 0.05 and kpss_p > 0.05) else "no"})
    st = pd.DataFrame(rows)
    # chart
    fig, ax = plt.subplots(2, 1, figsize=(10, 6.5), sharex=True, gridspec_kw={"height_ratios": [1.2, 1]})
    xs = bank.index.to_timestamp()
    ax[0].plot(xs, bank[cfg["LOAN_COL"]] / 1000, color=PAL[0], label="Reported balance")
    ax[0].plot(xs, np.exp(logL) / 1000, color=PAL[1], lw=1.5, ls="--", label="Organic (inorganic events removed)")
    ax[0].set_title("Ontario loan balance ($ billions)")
    ax[0].legend(loc="upper left")
    ax[1].bar(xs, y * 400, width=60, color=PAL[0])
    ax[1].axhline(0, color=INK2, lw=0.8)
    ax[1].set_title("Organic loan growth, q/q annualised (%)  — the modelling target is dlog(loan)")
    save(fig, "01_target.png")
    return y, yd, logL, st


# =============================================================================
# STEP 2 - Transform macro variables + stationarity
# =============================================================================
def step2_transforms(cfg, macro_base, meta):
    hist = macro_base.loc[:pd.Period(cfg["HIST_END"], freq="Q")]
    rows = []
    for code in macro_base.columns:
        if code not in meta.index:
            continue
        geo = str(meta.loc[code, "geography"])
        if cfg.get("ALLOWED_GEOGRAPHIES") and not any(geo.startswith(g) for g in cfg["ALLOWED_GEOGRAPHIES"]):
            continue
        if meta.loc[code, "theme"] in cfg.get("EXCLUDED_THEMES", []):
            continue
        x = hist[code]
        tr0 = meta.loc[code, "transform"]
        if tr0 == "dlog" and (x <= 0).any():
            tr0 = "diff"
            meta.loc[code, "transform"] = "diff"
        if tr0 == "dlog":
            trs = list(cfg["TRANSFORMS_LEVEL"])
            if meta.loc[code, "theme"] in cfg["REAL_THEMES"] and cfg["DEFLATOR"] in macro_base:
                trs += ["rdlog", "ryoy"]
        else:
            trs = list(cfg["TRANSFORMS_RATE"])
        for tr in trs:
            s = transform_col(hist, code, tr).dropna()
            if s.std() == 0 or len(s) < 30:
                p = 1.0
            else:
                try:
                    p = adfuller(s, autolag="AIC")[1]
                except Exception:
                    p = 1.0
            rows.append({"mnemonic": code, "transform": tr, "adf_p": p, "stationary": p < cfg["ADF_P"]})
    return pd.DataFrame(rows)


# =============================================================================
# STEP 3 - Univariate screen (partial regressions with HAC t-stats)
# =============================================================================
def base_regressors(cfg, idx, y):
    B = pd.DataFrame(index=idx)
    B["const"] = 1.0
    B["y_lag1"] = y.shift(1)
    for d, qs in cfg["DUMMIES"].items():
        B[d] = [1.0 if str(q) in qs else 0.0 for q in idx]
    return B


def step3_screen(cfg, macro_base, meta, stat_tbl, y, label="loan"):
    est = (y.index >= pd.Period(cfg["ESTIMATION_START"], freq="Q"))
    idx = y.index[est]
    B = base_regressors(cfg, y.index, y).loc[idx]
    yy = y.loc[idx]
    hist = macro_base.loc[:y.index[-1]]
    rows = []
    ok = stat_tbl[stat_tbl["stationary"]]
    for _, r in ok.iterrows():
        code, tr = r["mnemonic"], r["transform"]
        base = transform_col(hist, code, tr)
        for lag in range(cfg["MAX_LAG"] + 1):
            f = base.shift(lag).loc[idx]
            if f.isna().any() or f.std() == 0:
                continue
            X = B.copy()
            X["f"] = f
            res = sm.OLS(yy, X).fit(cov_type="HAC", cov_kwds={"maxlags": 4})
            rows.append({"feature": f"{code}|{tr}|L{lag}", "mnemonic": code, "transform": tr, "lag": lag,
                         "coef": res.params["f"], "t_hac": res.tvalues["f"], "p_hac": res.pvalues["f"],
                         "corr_with_target": np.corrcoef(f, yy)[0, 1]})
    sc = pd.DataFrame(rows)
    sc["theme"] = sc["mnemonic"].map(meta["theme"])
    sc["description"] = sc["mnemonic"].map(meta["description"])
    sc["expected_sign"] = sc["mnemonic"].map(meta["expected_sign"]).fillna(0).astype(int)
    sc["sign_ok"] = (sc["expected_sign"] == 0) | (np.sign(sc["coef"]) == sc["expected_sign"])
    if cfg["REQUIRE_SIGN_PRIOR"]:
        sc["sign_ok"] &= sc["expected_sign"] != 0
    sc["abs_t"] = sc["t_hac"].abs()
    # best transform/lag per variable among sign-consistent candidates
    cand = sc[sc["sign_ok"]].sort_values("abs_t", ascending=False)
    best = cand.groupby("mnemonic").head(1).copy()
    best["passed"] = best["p_hac"] < cfg["SCREEN_P"]
    return sc, best.sort_values("abs_t", ascending=False)


# =============================================================================
# STEP 4 - Correlation clustering -> shortlist
# =============================================================================
def step4_cluster(cfg, macro_base, best, y):
    passed = best[best["passed"]].copy()
    idx = y.index[y.index >= pd.Period(cfg["ESTIMATION_START"], freq="Q")]
    hist = macro_base.loc[:y.index[-1]]
    F = pd.DataFrame({f: feat(hist, f).loc[idx] for f in passed["feature"]})
    if F.shape[1] == 1:
        passed["cluster"] = 1
    else:
        C = F.corr().abs().fillna(0).values.copy()
        np.fill_diagonal(C, 1.0)
        D = squareform(np.clip(1 - C, 0, None), checks=False)
        Z = linkage(D, method="average")
        passed["cluster"] = fcluster(Z, t=1 - cfg["CLUSTER_CORR"], criterion="distance")
    passed["cluster_size"] = passed.groupby("cluster")["feature"].transform("count")
    passed["is_representative"] = False
    passed["geography"] = passed["mnemonic"].map(META_GEO)
    reps = []
    for _, g in passed.groupby("cluster"):
        g = g.sort_values("abs_t", ascending=False)
        prim = g[g["geography"] == cfg["PRIMARY_GEOGRAPHY"]]
        if len(prim) and prim["abs_t"].iloc[0] >= cfg["REP_TOLERANCE"] * g["abs_t"].iloc[0]:
            reps.append(prim.index[0])
        else:
            reps.append(g.index[0])
    passed.loc[reps, "is_representative"] = True
    shortlist = passed[passed["is_representative"]].sort_values("abs_t", ascending=False).head(cfg["SHORTLIST_MAX"])
    return passed.sort_values(["cluster", "abs_t"], ascending=[True, False]), shortlist


# =============================================================================
# Fast backtest for AR + exogenous OLS (used in the combination race)
# =============================================================================
def covid_mask(cfg, idx, origins, H):
    a, b = [pd.Period(q, freq="Q") for q in cfg["COVID_WINDOW"]]
    M = np.zeros((len(origins), H), dtype=bool)
    for i, o in enumerate(origins):
        for h in range(1, H + 1):
            if o + h < len(idx):
                win = idx[o + 1:o + h + 1]
                M[i, h - 1] = ((win >= a) & (win <= b)).any()
    return M


def fast_backtest(F, y, D, est0, origins, H):
    """F: exog matrix (T x k); y: target array; D: dummy matrix. Returns cumulative level % errors."""
    T = len(y)
    E = np.full((len(origins), H), np.nan)
    for i, o in enumerate(origins):
        rows = np.arange(est0, o + 1)
        Dk = D[rows]
        keep = Dk.std(axis=0) > 0
        X = np.column_stack([np.ones(len(rows)), y[rows - 1], Dk[:, keep], F[rows]])
        b = np.linalg.lstsq(X, y[rows], rcond=None)[0]
        c, rho, beta = b[0], b[1], b[2 + keep.sum():]
        yprev, cp, ca = y[o], 0.0, 0.0
        for h in range(1, H + 1):
            t = o + h
            if t >= T:
                break
            yh = c + rho * yprev + F[t] @ beta
            cp += yh
            ca += y[t]
            E[i, h - 1] = np.exp(cp - ca) - 1
            yprev = yh
    return E


def score_errors(E, M):
    abs_all = np.nanmean(np.abs(E))
    Ex = np.where(M, np.nan, E)
    return {"mape_all": abs_all, "mape_exc": np.nanmean(np.abs(Ex)),
            "mape_h4_exc": np.nanmean(np.abs(Ex[:, 3])) if Ex.shape[1] > 3 else np.nan,
            "mape_h9_exc": np.nanmean(np.abs(Ex[:, -1]))}


# =============================================================================
# STEP 5a - Constrained exhaustive search
# =============================================================================
def step5_combo_search(cfg, macro_base, shortlist, y, max_vars=None, label="loan"):
    max_vars = max_vars or cfg["MAX_VARS"]
    idx_all = y.index
    hist = macro_base.loc[:idx_all[-1]]
    est0 = int(np.where(idx_all == pd.Period(cfg["ESTIMATION_START"], freq="Q"))[0][0])
    feats = list(shortlist["feature"])
    Fall = np.column_stack([feat(hist, f).reindex(idx_all).values for f in feats])
    yv = y.values
    Dm = base_regressors(cfg, idx_all, y)[list(cfg["DUMMIES"])].values
    rows = np.arange(est0, len(yv))
    base = np.column_stack([np.ones(len(rows)), yv[rows - 1], Dm[rows]])
    signs = shortlist["expected_sign"].values
    themes = shortlist["theme"].values
    n = len(rows)
    res = []
    for k in range(cfg["MIN_VARS"], max_vars + 1):
        for combo in itertools.combinations(range(len(feats)), k):
            if cfg["ONE_PER_THEME"] and len(set(themes[list(combo)])) < k:
                continue
            if cfg.get("REQUIRED_THEMES") and not set(cfg["REQUIRED_THEMES"]) <= set(themes[list(combo)]):
                continue
            Fk = Fall[rows][:, combo]
            X = np.column_stack([base, Fk])
            b, se, e = ols_np(X, yv[rows])
            bk, tk = b[-k:], b[-k:] / se[-k:]
            if np.any(np.abs(tk) < cfg["T_MIN"]):
                continue
            sg = signs[list(combo)]
            if np.any((sg != 0) & (np.sign(bk) != sg)):
                continue
            vif = vif_from_matrix(Fk)
            if np.max(vif) > cfg["VIF_MAX"]:
                continue
            ssr = e @ e
            bic = n * np.log(ssr / n) + X.shape[1] * np.log(n)
            tss = ((yv[rows] - yv[rows].mean()) ** 2).sum()
            adj = 1 - (ssr / (n - X.shape[1])) / (tss / (n - 1))
            res.append({"combo": combo, "k": k, "bic": bic, "adj_r2": adj, "max_vif": np.max(vif),
                        "min_abs_t": np.min(np.abs(tk))})
    if not res:
        raise RuntimeError(f"[{label}] No combination satisfied the constraints - relax T_MIN / VIF_MAX / ONE_PER_THEME.")
    R = pd.DataFrame(res).sort_values("bic").head(cfg["N_OOS_CANDIDATES"])
    origins = [int(np.where(idx_all == p)[0][0]) for p in idx_all
               if p >= pd.Period(cfg["BACKTEST_START"], freq="Q") and p < idx_all[-1]]
    M = covid_mask(cfg, idx_all, origins, cfg["HORIZON"])
    scores = []
    for _, r in R.iterrows():
        E = fast_backtest(Fall[:, list(r["combo"])], yv, Dm, est0, origins, cfg["HORIZON"])
        scores.append(score_errors(E, M))
    R = pd.concat([R.reset_index(drop=True), pd.DataFrame(scores)], axis=1)
    R["features"] = R["combo"].apply(lambda c: [feats[i] for i in c])
    R = R.sort_values(cfg["RANK_METRIC"]).reset_index(drop=True)
    best_err = R[cfg["RANK_METRIC"]].iloc[0]
    R["within_tolerance"] = R[cfg["RANK_METRIC"]] <= best_err * (1 + cfg.get("SELECTION_TOLERANCE", 0))
    R["selected"] = False
    pick = R[R["within_tolerance"]].sort_values(["k", "min_abs_t"], ascending=[True, False]).index[0]
    R.loc[pick, "selected"] = True
    R = pd.concat([R.loc[[pick]], R.drop(index=pick)]).reset_index(drop=True)
    n_tested = sum(1 for k in range(cfg["MIN_VARS"], max_vars + 1)
                   for _ in itertools.combinations(range(len(feats)), k))
    return R, n_tested


# =============================================================================
# STEP 5c - Hybrid: theory core kept, data may add drivers that improve out-of-sample accuracy
# =============================================================================
def hybrid_addon_search(cfg, macro_base, core_feats, core_themes, shortlist, y, max_add=2):
    idx_all = y.index
    hist = macro_base.loc[:idx_all[-1]]
    est0 = int(np.where(idx_all == pd.Period(cfg["ESTIMATION_START"], freq="Q"))[0][0])
    core_codes = {parse_feat(f)[0] for f in core_feats}
    cand = shortlist[~shortlist["theme"].isin(core_themes) & ~shortlist["mnemonic"].isin(core_codes)]
    feats, themes, signs = list(cand["feature"]), cand["theme"].values, cand["expected_sign"].values
    Fcore = np.column_stack([feat(hist, f).reindex(idx_all).values for f in core_feats])
    Fall = np.column_stack([feat(hist, f).reindex(idx_all).values for f in feats]) if feats else np.zeros((len(y), 0))
    yv = y.values
    Dm = base_regressors(cfg, idx_all, y)[list(cfg["DUMMIES"])].values
    rows = np.arange(est0, len(yv))
    base = np.column_stack([np.ones(len(rows)), yv[rows - 1], Dm[rows], Fcore[rows]])
    n = len(rows)
    res = []
    for k in range(0, max_add + 1):
        for combo in itertools.combinations(range(len(feats)), k):
            if k and len(set(themes[list(combo)])) < k:
                continue
            Fk = Fall[rows][:, combo]
            X = np.column_stack([base, Fk])
            b, se, e = ols_np(X, yv[rows])
            if k:
                bk, tk = b[-k:], b[-k:] / se[-k:]
                if np.any(np.abs(tk) < cfg["T_MIN"]):
                    continue
                sg = signs[list(combo)]
                if np.any((sg != 0) & (np.sign(bk) != sg)):
                    continue
            if np.max(vif_from_matrix(np.column_stack([Fcore[rows], Fk]))) > cfg["VIF_MAX"]:
                continue
            ssr = e @ e
            res.append({"combo": combo, "k_added": k, "bic": n * np.log(ssr / n) + X.shape[1] * np.log(n)})
    R = pd.DataFrame(res).sort_values("bic").head(cfg["N_OOS_CANDIDATES"])
    origins = [int(np.where(idx_all == p)[0][0]) for p in idx_all
               if p >= pd.Period(cfg["BACKTEST_START"], freq="Q") and p < idx_all[-1]]
    M = covid_mask(cfg, idx_all, origins, cfg["HORIZON"])
    sc_ = [score_errors(fast_backtest(np.column_stack([Fcore, Fall[:, list(c)]]), yv, Dm, est0, origins,
                                      cfg["HORIZON"]), M) for c in R["combo"]]
    R = pd.concat([R.reset_index(drop=True), pd.DataFrame(sc_)], axis=1)
    R["added_drivers"] = R["combo"].apply(lambda c: ", ".join(feats[i] for i in c) or "(none)")
    R = R.sort_values(cfg["RANK_METRIC"]).reset_index(drop=True)
    best_err = R[cfg["RANK_METRIC"]].iloc[0]
    pick = R[R[cfg["RANK_METRIC"]] <= best_err * (1 + cfg["SELECTION_TOLERANCE"])].sort_values("k_added").index[0]
    added = [feats[i] for i in R.loc[pick, "combo"]]
    R["selected"] = R.index == pick
    return list(core_feats) + added, added, R.drop(columns="combo")


def theory_channels_data_measures(cfg, macro_base, best, y, reps=None, prune_t=1.0):
    """Theory fixes the channels (themes) and signs; data picks the best-measured series/transform/lag in each
    channel; channels the data cannot support jointly (|t| < prune_t) are dropped one at a time."""
    rows_, feats_ = [], []
    for L_ in LITERATURE_CORE:
        pool = [reps, best] if reps is not None else [best]
        c_ = pd.DataFrame()
        for src in pool:                       # cluster representatives first (de-duplicated, Ontario-preferred)
            c_ = src[(src["theme"] == L_["theme"]) & (np.sign(src["coef"]) == L_["expected_sign"])]
            if not c_.empty:
                break
        if c_.empty:
            continue
        r_ = c_.sort_values("abs_t", ascending=False).iloc[0]
        feats_.append(r_["feature"])
        rows_.append({"channel": L_["concept"], "chosen measure": r_["feature"], "description": r_["description"],
                      "univariate t": r_["t_hac"]})
    idx_all = y.index
    hist = macro_base.loc[:idx_all[-1]]
    est0 = int(np.where(idx_all == pd.Period(cfg["ESTIMATION_START"], freq="Q"))[0][0])
    rows = np.arange(est0, len(y))
    Dm = base_regressors(cfg, idx_all, y)[list(cfg["DUMMIES"])].values
    kept = list(feats_)
    while kept:
        F = np.column_stack([feat(hist, f).reindex(idx_all).values for f in kept])
        X = np.column_stack([np.ones(len(rows)), y.values[rows - 1], Dm[rows], F[rows]])
        b, se, _ = ols_np(X, y.values[rows])
        t = (b / se)[-len(kept):]
        if np.min(np.abs(t)) >= prune_t:
            break
        kept.pop(int(np.argmin(np.abs(t))))
    for r_ in rows_:
        r_["kept after joint pruning"] = r_["chosen measure"] in kept
    return kept, pd.DataFrame(rows_)


# =============================================================================
# STEP 5b - Elastic Net
# =============================================================================
def step5_elasticnet(cfg, macro_base, shortlist, y):
    idx = y.index[y.index >= pd.Period(cfg["ESTIMATION_START"], freq="Q")]
    hist = macro_base.loc[:y.index[-1]]
    feats = list(shortlist["feature"])
    X = pd.DataFrame({f: feat(hist, f).loc[idx] for f in feats})
    B = base_regressors(cfg, y.index, y).loc[idx].drop(columns="const")
    Xall = pd.concat([B, X], axis=1)
    Xs = StandardScaler().fit_transform(Xall)
    en = ElasticNetCV(l1_ratio=[0.2, 0.5, 0.8, 0.95, 1.0], cv=TimeSeriesSplit(n_splits=5), max_iter=50000,
                      random_state=0).fit(Xs, y.loc[idx].values)
    coefs = pd.Series(en.coef_, index=Xall.columns)
    sel = coefs[feats][coefs[feats] != 0].abs().sort_values(ascending=False)
    chosen = list(sel.index[:cfg["MAX_VARS"] + 2])
    tbl = pd.DataFrame({"feature": feats, "std_coef": coefs[feats].values,
                        "selected": [f in chosen for f in feats]})
    tbl["description"] = tbl["feature"].map(lambda f: shortlist.set_index("feature").loc[f, "description"])
    return chosen, tbl, {"alpha": en.alpha_, "l1_ratio": en.l1_ratio_}


# =============================================================================
# Generic model engine (OLS / ECM / two-equation / GBM)
# =============================================================================
class Model:
    """One forecasting model. kind: ols | qr | arimax | ridge | gbm | rf | combo.
    Optional: ar (lagged target), ecm (error-correction term), dep_model (two-equation system),
    factor = {"universe": [...features], "k": int} (principal-component factors re-estimated at every fit)."""

    def __init__(self, name, features, kind="ols", ar=True, ecm=False, dep_model=None, target="y",
                 family="", note="", factor=None, quantile=0.5, members=None, unpenalized=None,
                 weighting="equal"):
        self.name, self.features, self.kind, self.ar, self.ecm = name, list(features), kind, ar, ecm
        self.dep_model, self.target, self.family, self.note = dep_model, target, family, note
        self.factor, self.quantile, self.members = factor, quantile, members or []
        self.unpenalized = set(unpenalized or [])      # ridge: columns exempt from shrinkage (theory core)
        self.weighting = weighting                     # combo: "equal" or "inv_mse" (Bates-Granger, shrunk)
        self.weights = None

    # --- factors (Stock-Watson / Bai-Ng) -----------------------------------------
    def _fit_factors(self, P, rows):
        U = P[self.factor["universe"]].iloc[rows]
        U = U.loc[:, U.notna().all() & (U.std() > 0)]
        self.f_cols = list(U.columns)
        self.f_mu, self.f_sd = U.mean(), U.std()
        Z = ((U - self.f_mu) / self.f_sd).values
        _, S, Vt = np.linalg.svd(Z, full_matrices=False)
        k = self.factor["k"]
        load = Vt[:k].T
        load *= np.sign(load.sum(axis=0))                 # sign convention: mostly positive loadings
        self.f_load = load
        self.f_share = (S[:k] ** 2) / (S ** 2).sum()
        self.features = [f"F{j + 1}" for j in range(k)] + [f"F{j + 1}_L1" for j in range(k)]

    def _augment(self, P):
        if not self.factor:
            return P
        Z = ((P[self.f_cols] - self.f_mu) / self.f_sd).fillna(0.0).values
        F = Z @ self.f_load
        P2 = P.copy()
        for j in range(F.shape[1]):
            P2[f"F{j + 1}"] = F[:, j]
            P2[f"F{j + 1}_L1"] = pd.Series(F[:, j], index=P.index).shift(1)
        return P2

    def loadings_table(self, meta, top=10):
        rows = []
        for j in range(self.f_load.shape[1]):
            order = np.argsort(-np.abs(self.f_load[:, j]))[:top]
            for r_, i in enumerate(order):
                rows.append({"factor": f"F{j + 1}", "variance share": round(float(self.f_share[j]), 3), "rank": r_ + 1,
                             "feature": self.f_cols[i], "description": describe_feat(self.f_cols[i], meta),
                             "loading": round(float(self.f_load[i, j]), 3)})
        return pd.DataFrame(rows)

    # --- design matrix ------------------------------------------------------------
    def _X(self, P, ect=None):
        X = pd.DataFrame(index=P.index)
        X["const"] = 1.0
        if self.ar:
            X["y_lag1"] = P[self.target].shift(1)
        if self.ecm:
            X["ect_lag1"] = ect.shift(1)
        for f in self.features:
            X[f] = P[f]
        if self.dep_model is not None:
            X["dep_growth_lag1"] = P["yd"].shift(1)
        for d in CONFIG["DUMMIES"]:
            X[d] = P[d]
        return X

    def _lr_fit(self, P, rows):
        Z = sm.add_constant(P[["LR_gdp", "LR_hpi", "LR_rate"]].iloc[rows])
        r = sm.OLS(P["LR_loan"].iloc[rows], Z).fit()
        self.lr_params, self.lr_res = r.params, r
        return P["LR_loan"] - sm.add_constant(P[["LR_gdp", "LR_hpi", "LR_rate"]]) @ r.params

    def fit(self, P, end, est0):
        if self.kind == "combo":
            self.weights = np.full(len(self.members), 1.0 / len(self.members))
            if self.weighting == "inv_mse":
                self.weights = self._performance_weights(P, end, est0)
            for m in self.members:
                m.fit(P, end, est0)
            return self
        rows = np.arange(est0, end + 1)
        if self.factor:
            self._fit_factors(P, rows)
        P = self._augment(P)
        ect = self._lr_fit(P, rows) if self.ecm else None
        X = self._X(P, ect).iloc[rows]
        X = X.loc[:, (X.std() > 0) | (X.columns == "const")]
        yv = P[self.target].iloc[rows]
        ok = X.notna().all(axis=1) & yv.notna()
        X, yv = X[ok], yv[ok]
        self.cols = list(X.columns)
        if self.kind == "ols":
            self.res = sm.OLS(yv, X).fit(cov_type="HAC", cov_kwds={"maxlags": 4})
            self.params = self.res.params
        elif self.kind == "qr":
            self.res = sm.QuantReg(yv, X).fit(q=self.quantile, max_iter=5000)
            self.params = self.res.params
        elif self.kind == "arimax":
            ex = X.drop(columns=[c for c in ("const", "y_lag1") if c in X])
            self.ax_cols = list(ex.columns)
            self.res = SARIMAX(yv.values, exog=ex.values, order=(1, 0, 1), trend="c").fit(disp=False, maxiter=200)
        else:
            Xg = X.drop(columns="const")
            self.gcols = list(Xg.columns)
            if self.kind == "ridge":
                self.scaler = StandardScaler().fit(Xg.values)
                # Differential shrinkage: scaling a standardised column by a large factor makes its ridge penalty
                # negligible, so theory (unpenalized) columns keep OLS-like coefficients while the rest are shrunk.
                self.boost = np.array([1000.0 if c in self.unpenalized or c == "y_lag1" and self.unpenalized else 1.0
                                       for c in self.gcols])
                self.sk = RidgeCV(alphas=np.logspace(-4, 3, 40), cv=TimeSeriesSplit(n_splits=5)).fit(
                    self.scaler.transform(Xg.values) * self.boost, yv.values)
            elif self.kind == "gbm":
                self.sk = GradientBoostingRegressor(n_estimators=300, max_depth=2, learning_rate=0.03, subsample=0.8,
                                                    random_state=0).fit(Xg.values, yv.values)
            elif self.kind == "rf":
                self.sk = RandomForestRegressor(n_estimators=200, min_samples_leaf=3, max_features=0.5,
                                                random_state=0, n_jobs=-1).fit(Xg.values, yv.values)
                self.sk.n_jobs = 1          # one-row predictions: thread start-up would dominate
        if self.dep_model is not None:
            self.dep_model.fit(P, end, est0)
        return self

    def _predict_row(self, x):
        if self.kind in ("ols", "qr"):
            return sum(self.params[c] * x[c] for c in self.cols)
        v = np.array([[x[c] for c in self.gcols]])
        if self.kind == "ridge":
            v = self.scaler.transform(v) * self.boost
        return float(self.sk.predict(v)[0])

    def _performance_weights(self, P, end, est0, window=24, step=2, h=4, shrink=0.5):
        """Bates-Granger inverse-MSE weights from each member's recent pseudo out-of-sample 4-quarter errors,
        using only information available at `end`; shrunk halfway toward equal weights (forecast-combination puzzle)."""
        a, b = [pd.Period(q, freq="Q") for q in CONFIG["COVID_WINDOW"]]
        origins = [o for o in range(max(est0 + 40, end - window), end - h + 1, step)
                   if not ((P.index[o + 1:o + h + 1] >= a) & (P.index[o + 1:o + h + 1] <= b)).any()]
        n = len(self.members)
        if len(origins) < 4:
            return np.full(n, 1.0 / n)
        mse = np.zeros(n)
        for j, m in enumerate(self.members):
            errs = []
            for o in origins:
                m.fit(P, o, est0)
                fc = m.forecast(P, o, h)
                errs.append(fc.sum() - P[self.target].iloc[o + 1:o + h + 1].sum())
            mse[j] = np.mean(np.square(errs))
        w = (1 / mse) / (1 / mse).sum()
        return shrink * w + (1 - shrink) / n

    def forecast(self, P, end, H, shocks=None):
        T = len(P)
        H = min(H, T - end - 1)
        if self.kind == "combo":
            return np.average([m.forecast(P, end, H) for m in self.members], axis=0, weights=self.weights)
        P = self._augment(P)
        if self.kind == "arimax":
            ex = np.array([[0.0 if c in CONFIG["DUMMIES"] else P[c].iloc[end + h] for c in self.ax_cols]
                           for h in range(1, H + 1)])
            return np.asarray(self.res.forecast(steps=H, exog=ex))
        dep_fc = self.dep_model.forecast(P, end, H) if self.dep_model is not None else None
        yprev = P[self.target].iloc[end]
        logL = P["logL"].iloc[end]
        out = np.zeros(H)
        for h in range(1, H + 1):
            t = end + h
            x = {"const": 1.0, "y_lag1": yprev}
            if self.ecm:
                lr = self.lr_params
                x["ect_lag1"] = (logL - P["logCPI"].iloc[t - 1]) - (lr["const"] + lr["LR_gdp"] * P["LR_gdp"].iloc[t - 1]
                                 + lr["LR_hpi"] * P["LR_hpi"].iloc[t - 1] + lr["LR_rate"] * P["LR_rate"].iloc[t - 1])
            for f in self.features:
                x[f] = P[f].iloc[t]
            if self.dep_model is not None:
                x["dep_growth_lag1"] = P["yd"].iloc[end] if h == 1 else dep_fc[h - 2]
            for d in CONFIG["DUMMIES"]:
                x[d] = 0.0                                   # one-off events are not projected
            yh = self._predict_row(x) + (shocks[h - 1] if shocks is not None else 0.0)
            out[h - 1] = yh
            yprev = yh
            logL += yh
        return out

    def inputs(self):
        if self.kind == "combo":
            return f"{len(self.members)} models, {len(set(f for m in self.members for f in m.features))} distinct drivers"
        if self.factor:
            return f"{self.factor['k']} factors from {len(self.factor['universe'])} series"
        return f"{len(self.features)} drivers"


def simulate_fan(model, P, end, H, n_sim, seed=0):
    """Bootstrap residuals through the recursive model -> distribution of cumulative growth paths."""
    rng = np.random.default_rng(seed)
    e = model.res.resid.values
    e = e[np.abs(e) > 1e-12]                       # dummy quarters have zero residual by construction
    sims = np.array([np.cumsum(model.forecast(P, end, H, shocks=rng.choice(e, H))) for _ in range(n_sim)])
    return sims


def make_panel(cfg, mdf, y, yd, logL, features):
    idx = mdf.index
    P = pd.DataFrame(index=idx)
    P["y"] = y.reindex(idx)
    P["yd"] = yd.reindex(idx) if yd is not None else np.nan
    P["logL"] = logL.reindex(idx)
    for d, qs in cfg["DUMMIES"].items():
        P[d] = [1.0 if str(q) in qs else 0.0 for q in idx]
    for f in set(features):
        P[f] = feat(mdf, f)
    e = ECM_SPEC
    if all(c in mdf for c in e.values()):
        P["logCPI"] = np.log(mdf[e["deflator"]])
        P["LR_loan"] = P["logL"] - P["logCPI"]
        P["LR_gdp"] = np.log(mdf[e["gdp"]])
        P["LR_hpi"] = np.log(mdf[e["hpi"]]) - P["logCPI"]
        P["LR_rate"] = mdf[e["rate"]] - 100 * (np.log(mdf[e["deflator"]]).diff(4))
    return P


# =============================================================================
# STEP 7 - Rolling-origin backtest (generic)
# =============================================================================
def backtest(cfg, model, P, est0, origins, H):
    T_hist = P["y"].last_valid_index()
    last = int(np.where(P.index == T_hist)[0][0])
    E = np.full((len(origins), H), np.nan)
    paths, coefs = [], []
    for i, o in enumerate(origins):
        model.fit(P, o, est0)
        fc = model.forecast(P.iloc[:last + 1], o, H)
        act = P["y"].iloc[o + 1:o + 1 + len(fc)].values
        E[i, :len(fc)] = np.exp(np.cumsum(fc) - np.cumsum(act)) - 1
        paths.append((P.index[o], fc))
        if model.kind == "ols" and not model.factor:
            coefs.append(pd.concat([model.params.rename(lambda c: c + "|coef"),
                                    model.res.bse.rename(lambda c: c + "|se")]).rename(P.index[o]))
    return E, paths, (pd.DataFrame(coefs) if coefs else None)


# =============================================================================
# STEP 8 - Diagnostics
# =============================================================================
def diagnostics(model, P, est0, end, meta, shortlist_signs):
    model.fit(P, end, est0)
    if model.kind != "ols":
        notes = {"qr": "quantile regression - judged on backtest; residual tests not applicable",
                 "arimax": "ARMA(1,1) errors - see backtest", "combo": "average of OLS models - see members",
                 "ridge": "penalised regression - see backtest"}
        return {"model": model.name, "note": notes.get(model.kind, "non-parametric challenger - no residual diagnostics")}
    r = model.res
    X = r.model.exog
    e = r.resid
    lb = acorr_ljungbox(e, lags=[4, 8], return_df=True)["lb_pvalue"].values
    bp = het_breuschpagan(e, X)[1]
    jb = jarque_bera(e)[1]
    try:
        cus = breaks_cusumolsresid(e.values, ddof=X.shape[1])[1]
    except Exception:
        cus = np.nan
    drivers = [c for c in r.params.index if c not in ("const",) and c not in CONFIG["DUMMIES"]]
    macro_cols = [c for c in drivers if c in model.features]
    exog = pd.DataFrame(r.model.exog, columns=r.model.exog_names)
    vif = vif_from_matrix(exog[macro_cols].values) if len(macro_cols) > 1 else [1.0]
    sign_fail = []
    for c in [c for c in macro_cols if "|" in c]:
        s = shortlist_signs.get(parse_feat(c)[0], 0)
        if s != 0 and np.sign(r.params[c]) != s:
            sign_fail.append(c)
    return {"model": model.name, "n_obs": int(r.nobs), "adj_R2": round(r.rsquared_adj, 3),
            "AIC": round(r.aic, 1), "BIC": round(r.bic, 1), "n_macro_drivers": len(macro_cols),
            "max_abs_p_driver": round(max([r.pvalues[c] for c in macro_cols] or [np.nan]), 4),
            "Ljung-Box p (4)": round(lb[0], 3), "Ljung-Box p (8)": round(lb[1], 3),
            "Breusch-Pagan p": round(bp, 3), "Jarque-Bera p": round(jb, 3), "Durbin-Watson": round(durbin_watson(e), 2),
            "CUSUM p": round(cus, 3), "max VIF": round(float(np.max(vif)), 2),
            "wrong-sign drivers": ", ".join(sign_fail) if sign_fail else "none"}


# =============================================================================
# STEP 10 - Explainability
# =============================================================================
def driver_table(model, P, est0, end, meta):
    model.fit(P, end, est0)
    r = model.res
    rho = r.params.get("y_lag1", 0.0)
    rows = []
    for c in r.params.index:
        if c == "const" or c in CONFIG["DUMMIES"]:
            continue
        b, t, p = r.params[c], r.tvalues[c], r.pvalues[c]
        if "|" in c:
            code, tr, lag = parse_feat(c)
            sd = P[c].iloc[est0:end + 1].std()
            is_rate = tr in RATE_TRS
            unit = "1 pp" if is_rate else "1 %"
            per_unit = b * (1 if is_rate else 0.01) * 100      # pp of q/q loan growth
            lr = per_unit / (1 - rho) if c != "y_lag1" else np.nan
            when = "in the same quarter" if lag == 0 else f"{lag} quarter{'s' if lag > 1 else ''} later"
            move = TR_DESC[tr]
            direction = "raises" if b > 0 else "lowers"
            text = (f"A {unit} increase in {meta.loc[code, 'description']} [{move}] {direction} q/q loan growth "
                    f"by {abs(per_unit):.3f} pp {when}; cumulative long-run effect {abs(lr):.3f} pp.")
            rows.append({"driver": c, "description": meta.loc[code, "description"], "theme": meta.loc[code, "theme"],
                         "transform": tr, "lag": lag, "coef": b, "t (HAC)": t, "p": p,
                         "expected sign": int(meta.loc[code, "expected_sign"]),
                         "effect per unit (pp q/q growth)": per_unit, "long-run effect (pp)": lr,
                         "1-sd shock -> annualised loan growth (pp, long-run)": b * sd * 400 / (1 - rho),
                         "plain-language reading": text})
        else:
            lab = {"y_lag1": "Loan growth last quarter (momentum)", "ect_lag1": "Error-correction term (gap to long-run level)",
                   "dep_growth_lag1": "Deposit growth last quarter"}.get(c, c)
            txt = {"y_lag1": f"{b:.2f} of last quarter's growth carries into this quarter (persistence).",
                   "ect_lag1": f"{abs(b) * 100:.1f}% of any gap between the loan book and its long-run level closes each quarter.",
                   "dep_growth_lag1": f"1 pp faster deposit growth adds {b:.3f} pp to next quarter's loan growth."}.get(c, "")
            rows.append({"driver": c, "description": lab, "theme": "Dynamics", "coef": b, "t (HAC)": t, "p": p,
                         "plain-language reading": txt})
    return pd.DataFrame(rows)


def contributions(model, P, est0, end, fc, scen_P):
    """Exact dynamic decomposition of loan growth: y_t = rho*y_{t-1} + sum(terms) -> filter each term by rho."""
    model.fit(P, end, est0)
    pr = model.params
    rho = pr.get("y_lag1", 0.0)
    feats = [c for c in pr.index if "|" in c]
    Q = scen_P.index[est0:end + 1 + len(fc)]
    Xh = model._X(scen_P).loc[Q]
    yfull = np.r_[P["y"].iloc[est0:end + 1].values, fc]
    fitted_terms = {}
    means = {f: P[f].iloc[est0:end + 1].mean() for f in feats}
    fitted_terms["Trend (constant + average drivers)"] = np.full(len(Q), pr["const"] + sum(pr[f] * means[f] for f in feats))
    for f in feats:
        fitted_terms[f] = pr[f] * (Xh[f].values - means[f])
    other = np.zeros(len(Q))
    for d in CONFIG["DUMMIES"]:
        if d in pr:
            other += pr[d] * np.r_[Xh[d].values[:end + 1 - est0], np.zeros(len(fc))]
    # residual so that components add up exactly to actual (history) / forecast (future)
    ylag = np.r_[P["y"].iloc[est0 - 1], yfull[:-1]]
    explained = rho * ylag + sum(fitted_terms.values()) + other
    other += yfull - explained
    fitted_terms["COVID dummies + unexplained"] = other
    comp = {}
    for k, v in fitted_terms.items():
        c = np.zeros(len(Q))
        for i in range(len(Q)):
            c[i] = (rho * c[i - 1] if i > 0 else 0) + v[i]
        comp[k] = c
    init = P["y"].iloc[est0 - 1] * rho ** np.arange(1, len(Q) + 1)
    comp["COVID dummies + unexplained"] += init
    return pd.DataFrame(comp, index=Q), pd.Series(yfull, index=Q)


# =============================================================================
# MAIN
# =============================================================================
def main(cfg=CONFIG):
    os.makedirs(cfg["OUT_DIR"], exist_ok=True)
    tables = {}

    # ---------------- Step 1 ----------------
    log("Step 1  Loading data and building the target ...")
    bank = load_bank(cfg)
    events = pd.read_csv(cfg["EVENTS_FILE"]) if os.path.exists(cfg["EVENTS_FILE"]) else None
    macro = load_macro(cfg)
    mb = macro[cfg["BASE_SCENARIO"]]
    if not os.path.exists(cfg["META_FILE"]):
        build_metadata_template(mb, cfg["META_FILE"])
        sys.exit(0)
    meta = pd.read_csv(cfg["META_FILE"]).set_index("mnemonic")
    META_GEO.update(meta["geography"].to_dict())
    meta["expected_sign"] = meta["expected_sign"].fillna(0).astype(int)
    # Constructed variables (real rates, spreads, affordability ...)
    built = []
    for c in CONSTRUCTED:
        try:
            for sname in macro:
                macro[sname][c["mnemonic"]] = c["fn"](macro[sname])
        except KeyError as e:
            log(f"        constructed variable {c['mnemonic']} skipped (missing input {e})")
            continue
        meta.loc[c["mnemonic"]] = {k: c[k] for k in ["description", "geography", "theme", "transform", "expected_sign"]}
        built.append(c["mnemonic"])
    META_GEO.update(meta["geography"].to_dict())
    mb = macro[cfg["BASE_SCENARIO"]]
    log(f"        added {len(built)} constructed variables: {', '.join(built)}")
    y, yd, logL, st = step1_target(cfg, bank, events)
    tables["01_target_stationarity"] = st
    log(st.to_string(index=False))

    # ---------------- Step 2 ----------------
    log("Step 2  Transforming macro variables and testing stationarity ...")
    stat = step2_transforms(cfg, mb, meta)
    tables["02_macro_stationarity"] = stat
    n_vars = mb.shape[1]
    n_stat_vars = stat[stat["stationary"]]["mnemonic"].nunique()
    n_relevant = stat["mnemonic"].nunique()
    log(f"        {n_vars} variables, {n_relevant} pass the relevance filter, {len(stat)} transformed series, {stat['stationary'].sum()} stationary "
        f"({n_stat_vars} variables with at least one stationary form)")

    # ---------------- Step 3 ----------------
    log("Step 3  Univariate screen ...")
    sc, best = step3_screen(cfg, mb, meta, stat, y)
    tables["03_screen_all_candidates"] = sc.sort_values("abs_t", ascending=False)
    tables["03_screen_best_per_variable"] = best
    tu = pd.DataFrame({"tested (features)": sc.groupby("transform").size(),
                       "best form for a passing variable": best[best["passed"]].groupby("transform").size()}).fillna(0)
    tu["description"] = tu.index.map(TR_DESC)
    tables["03b_transform_usage"] = tu.reset_index().rename(columns={"index": "transform"})
    log(f"        {len(sc)} candidate features tested; {best['passed'].sum()} variables pass (p<{cfg['SCREEN_P']}, correct sign)")

    # ---------------- Step 4 ----------------
    log("Step 4  Clustering redundant variables ...")
    clus, shortlist = step4_cluster(cfg, mb, best, y)
    for th in cfg.get("REQUIRED_THEMES", []):          # make sure a required theme has a candidate
        if th not in set(shortlist["theme"]):
            cand = best[best["theme"] == th].head(1)
            if cand.empty:
                raise RuntimeError(f"No sign-consistent candidate for required theme '{th}'")
            shortlist = pd.concat([shortlist, cand])
            log(f"        Required theme '{th}': added {cand['feature'].iloc[0]} (t={cand['t_hac'].iloc[0]:.2f})")
    tables["04_clusters"] = clus
    tables["05_shortlist"] = shortlist
    log(f"        {clus['cluster'].nunique()} clusters -> shortlist of {len(shortlist)}")
    log(shortlist[["feature", "theme", "coef", "t_hac"]].head(15).to_string(index=False))

    # ---------------- Step 5 ----------------
    log("Step 5a Constrained exhaustive search + out-of-sample race ...")
    R, n_tested = step5_combo_search(cfg, mb, shortlist, y)
    tables["06_combo_search_top50"] = R.head(50).drop(columns="combo").assign(features=lambda d: d["features"].apply(", ".join))
    champ_feats = R.iloc[0]["features"]
    log(f"        {n_tested} combinations enumerated, {len(R)} passed constraints and were backtested")
    log(f"        Champion: {champ_feats}")

    log("Step 5b Elastic Net ...")
    en_feats, en_tbl, en_par = step5_elasticnet(cfg, mb, shortlist, y)
    tables["07_elasticnet"] = en_tbl
    log(f"        Elastic Net selected: {en_feats}")

    # Literature features: best lag per (mnemonic, transform) from the screen, regardless of sign
    def pick_literature(spec, label):
        feats_, rows_ = [], []
        for L_ in spec:
            cand = sc[(sc["mnemonic"] == L_["mnemonic"]) & (sc["transform"] == L_["transform"])]
            if cand.empty:
                log(f"        WARNING literature variable {L_['mnemonic']} ({L_['transform']}) not available - skipped")
                continue
            if "lags" in L_:
                cand = cand[cand["lag"].isin(L_["lags"])]
            right = cand[np.sign(cand["coef"]) == L_["expected_sign"]] if L_["expected_sign"] else cand
            cand = right if len(right) else cand            # prefer a lag with the theoretically expected sign
            bestlag = cand.sort_values("abs_t", ascending=False).iloc[0]
            feats_.append(bestlag["feature"])
            rows_.append({"model": label, **L_, "feature_used": bestlag["feature"], "univariate t": bestlag["t_hac"]})
            if meta.loc[L_["mnemonic"], "expected_sign"] == 0:
                meta.loc[L_["mnemonic"], "expected_sign"] = L_["expected_sign"]
        return feats_, rows_

    lit_feats, lit_rows = pick_literature(LITERATURE, "Literature ARDL (classic)")
    lit2_feats, lit2_rows = pick_literature(LITERATURE_RECENT, "Literature ARDL (ECB BEAST 2023)")
    core_feats, core_rows = pick_literature(LITERATURE_CORE, "Theory ARDL (literature core)")
    tables["08_literature_variables"] = pd.DataFrame(lit_rows + lit2_rows + core_rows)
    log(f"        Literature core: {core_feats}")
    # all lags inside each theory window (for theory ridge / random forest)
    core_all_lags = [f"{L_['mnemonic']}|{L_['transform']}|L{l}" for L_ in LITERATURE_CORE for l in L_["lags"]
                     if f"{L_['mnemonic']}|{L_['transform']}|L{l}" in set(sc["feature"])]
    log("Step 5c Hybrid search: literature core + data add-ons ...")
    hyb_feats, hyb_added, Rh = hybrid_addon_search(cfg, mb, core_feats, [L_["theme"] for L_ in LITERATURE_CORE],
                                                   shortlist, y)
    tables["09b_hybrid_addon_search"] = Rh.head(30)
    log(f"        Data add-ons kept: {hyb_added or 'none'}")
    unc_feats = []
    if cfg.get("RUN_UNCONSTRAINED"):
        log("Step 5d Unconstrained data mining (no theory constraints), for reference ...")
        cfg_u = dict(cfg, ALLOWED_GEOGRAPHIES=[], EXCLUDED_THEMES=[], REQUIRE_SIGN_PRIOR=False, ONE_PER_THEME=False,
                     PRIMARY_GEOGRAPHY="__none__", REQUIRED_THEMES=[], TRANSFORMS_LEVEL=["dlog", "yoy"],
                     TRANSFORMS_RATE=["diff", "diff4"], REAL_THEMES=[])
        meta_u = meta.copy()
        meta_u["expected_sign"] = 0
        stat_u = step2_transforms(cfg_u, mb, meta_u)
        _, best_u = step3_screen(cfg_u, mb, meta_u, stat_u, y)
        _, short_u = step4_cluster(cfg_u, mb, best_u, y)
        R_u, _ = step5_combo_search(cfg_u, mb, short_u, y)
        unc_feats = R_u.iloc[0]["features"]
        tables["09d_unconstrained_selection"] = R_u.head(20).drop(columns="combo").assign(
            features=lambda d: d["features"].apply(", ".join))
        log(f"        Unconstrained pick: {unc_feats}")
    chan_feats, chan_tbl = theory_channels_data_measures(cfg, mb, best, y, reps=clus[clus["is_representative"]])
    tables["09c_hybrid_theory_channels"] = chan_tbl
    log(f"        Theory channels, data measures: {chan_feats}")

    # Deposit equation (for the two-equation model)
    dep_model = None
    if yd is not None:
        log("        Deposit equation: screening drivers for deposit growth ...")
        cfg_d = dict(cfg)
        cfg_d["MIN_VARS"] = 1
        cfg_d["REQUIRED_THEMES"] = []
        scd, bestd = step3_screen(cfg_d, mb, meta, stat, yd, label="deposit")
        _, shortd = step4_cluster(cfg_d, mb, bestd, yd)
        Rd, _ = step5_combo_search(cfg_d, mb, shortd.head(15), yd, max_vars=cfg["DEP_MAX_VARS"], label="deposit")
        dep_feats = Rd.iloc[0]["features"]
        tables["09_deposit_equation_search"] = Rd.head(20).drop(columns="combo").assign(features=lambda d: d["features"].apply(", ".join))
        log(f"        Deposit drivers: {dep_feats}")
        dep_model = Model("Deposit equation", dep_feats, target="yd")

    # ---------------- Step 6 ----------------
    models = [
        Model("AR(1) benchmark", [], family="Benchmark", note="Loan growth on its own lag only"),
        Model("Champion (data-driven)", champ_feats, family="Selected",
              note="Constrained exhaustive search, ranked by out-of-sample level error"),
        Model("Elastic Net (post-selection OLS)", en_feats, family="Selected",
              note=f"ElasticNetCV alpha={en_par['alpha']:.2e}, l1_ratio={en_par['l1_ratio']}"),
        Model("Literature ARDL (classic)", lit_feats, family="Literature",
              note="GDP, house prices, long & short rates, inflation (Hofmann 2001; Calza et al. 2001; Guo & Stepanyan 2011)"),
        Model("Literature ECM", lit_feats, ecm=True, family="Literature",
              note="Long-run: real loans ~ real GDP + real house prices + real lending rate"),
        Model("Literature ARDL (ECB BEAST 2023)", lit2_feats, family="Literature",
              note="Loan-demand block of BEAST: GDP, inflation, unemployment change, short rate, term spread"),
    ]
    if dep_model is not None:
        models.append(Model("Champion + deposits (2-eq.)", champ_feats, dep_model=dep_model, family="Selected",
                            note="Deposit growth forecast from its own macro equation, fed into the loan equation"))
    # ---- alternative model families ----
    st_ok = stat[stat["stationary"]]
    pref = {t: i for i, t in enumerate(["dlog", "diff", "yoy", "diff4"])}
    sw_universe = []                                   # one standard stationary form per relevant variable
    for code, g in st_ok.groupby("mnemonic"):
        g = g[g["transform"].isin(pref)]
        if len(g):
            sw_universe.append(f"{code}|{g.sort_values('transform', key=lambda c: c.map(pref)).iloc[0]['transform']}|L0")
    tp_universe = list(best[best["passed"]]["feature"])
    combo_members = [Model(f"combo member {i + 1}", f) for i, f in enumerate(R["features"].head(cfg["N_COMBINE"]))]
    models += [
        Model("Ridge (whole shortlist)", list(shortlist["feature"]), kind="ridge", family="Alternative",
              note="All shortlisted drivers, coefficients shrunk (RidgeCV, time-series CV)"),
        Model("Factor model (Stock-Watson)", [], factor={"universe": sw_universe, "k": cfg["N_FACTORS"]},
              family="Alternative", note=f"{cfg['N_FACTORS']} principal components of all relevant series (diffusion index)"),
        Model("Targeted factors (Bai-Ng)", [], factor={"universe": tp_universe, "k": cfg["N_TARGETED_FACTORS"]},
              family="Alternative", note="Principal components of the screened (targeted) predictors only"),
        Model(f"Forecast combination (top {cfg['N_COMBINE']})", [], kind="combo", members=combo_members,
              family="Alternative", note="Equal-weight average of the best constrained models (Stock & Watson 2004)"),
        Model("ARIMAX (champion drivers)", champ_feats, kind="arimax", ar=False, family="Alternative",
              note="Champion drivers with ARMA(1,1) errors instead of a lagged dependent variable"),
        Model("Quantile regression (median)", champ_feats, kind="qr", quantile=0.5, family="Alternative",
              note="Champion drivers, median regression (robust to outliers; Covas, Rump & Zakrajsek 2014)"),
        Model("Gradient boosting (challenger)", list(shortlist["feature"]), kind="gbm", family="Challenger",
              note="Non-linear benchmark on the whole shortlist; not for production"),
        Model("Random forest (challenger)", list(shortlist["feature"]), kind="rf", family="Challenger",
              note="Non-linear benchmark on the whole shortlist; not for production"),
    ]
    # ---- theory versions of each model type (variables from the literature only) ----
    theory_universe = [f for f in sw_universe if meta.loc[parse_feat(f)[0], "theme"] in THEORY_THEMES]
    m_theory = Model("Theory ARDL (literature core)", core_feats, family="Theory",
                     note="House prices, income, mortgage rate, unemployment; theory lag windows")
    m_lit_classic = next(m for m in models if m.name == "Literature ARDL (classic)")
    m_lit_ecm = next(m for m in models if m.name == "Literature ECM")
    m_beast = next(m for m in models if "BEAST" in m.name)
    champ_m = models[1]
    models += [
        m_theory,
        Model("Theory ridge (core, all lags)", core_all_lags, kind="ridge", family="Theory",
              note="Literature-core variables at every lag in their theory windows, shrunk by ridge"),
        Model("Theory quantile regression", core_feats, kind="qr", family="Theory", note="Literature core, median"),
        Model("Theory ARIMAX", core_feats, kind="arimax", ar=False, family="Theory", note="Literature core, ARMA(1,1) errors"),
        Model("Theory-restricted factors", [], factor={"universe": theory_universe, "k": cfg["N_FACTORS"]},
              family="Theory", note="Principal components of series in literature themes only"),
        Model("Theory random forest", core_all_lags, kind="rf", family="Theory",
              note="Literature-core variables and lags, non-linear"),
        Model("Theory combination (4 literature models)", [], kind="combo", family="Theory",
              members=[Model("t1", m_lit_classic.features), Model("t2", m_lit_ecm.features, ecm=True),
                       Model("t3", m_beast.features), Model("t4", core_feats)],
              note="Equal-weight average: classic ARDL, ECM, BEAST, literature core"),
        # ---- hybrids: balance data and theory ----
        Model("Hybrid: theory core + data add-ons", hyb_feats, family="Hybrid",
              note="Literature core always kept; data may add up to 2 drivers from other themes if they improve OOS accuracy"),
        Model("Hybrid: theory-anchored ridge", list(dict.fromkeys(core_feats + list(shortlist["feature"]))), kind="ridge",
              unpenalized=core_feats, family="Hybrid",
              note="Literature core unpenalised; all data-shortlist drivers shrunk by ridge (differential shrinkage)"),
        *([Model("Unconstrained data mining (no theory)", unc_feats, family="Data (no theory)",
                 note="No sign priors, geography or theme rules - accuracy reference only")] if unc_feats else []),
        Model("Hybrid: theory long run + data short run", champ_feats, ecm=True, family="Hybrid",
              note="Champion short-run drivers plus the literature error-correction term (long-run credit demand)"),
        Model("Hybrid: theory channels, data measures", chan_feats, family="Hybrid",
              note="Theory sets channels and signs; data picks the series/lag per channel; unsupported channels dropped"),
        Model("Hybrid: 50/50 data + theory", [], kind="combo", family="Hybrid",
              members=[Model("d", champ_feats), Model("t", core_feats)],
              note="Equal-weight average of the data champion and the literature-core model"),
        Model("Hybrid: performance-weighted", [], kind="combo", weighting="inv_mse", family="Hybrid",
              members=[Model("d", champ_feats), Model("t", core_feats), Model("e", m_lit_ecm.features, ecm=True)],
              note="Champion, literature core and ECM weighted by recent 4-quarter accuracy (inverse MSE, shrunk to equal)"),
    ]

    all_feats = set(champ_feats) | set(en_feats) | set(lit_feats) | set(lit2_feats) | set(shortlist["feature"])
    all_feats |= set(sw_universe) | set(tp_universe) | {f for m in combo_members for f in m.features}
    all_feats |= set(core_feats) | set(core_all_lags) | set(hyb_feats) | set(chan_feats) | set(unc_feats)
    if dep_model is not None:
        all_feats |= set(dep_model.features)
    panels = {s: make_panel(cfg, macro[s], y, yd, logL, all_feats) for s in macro}
    P = panels[cfg["BASE_SCENARIO"]]
    est0 = int(np.where(P.index == pd.Period(cfg["ESTIMATION_START"], freq="Q"))[0][0])
    end = int(np.where(P.index == pd.Period(cfg["HIST_END"], freq="Q"))[0][0])
    Ph = P.iloc[:end + 1]

    # Engle-Granger cointegration check for the ECM
    from statsmodels.tsa.stattools import coint
    lrdat = Ph[["LR_loan", "LR_gdp", "LR_hpi", "LR_rate"]].iloc[est0:].dropna()
    eg_p = coint(lrdat["LR_loan"], lrdat[["LR_gdp", "LR_hpi", "LR_rate"]])[1]
    log(f"        Engle-Granger cointegration p-value (literature long-run relation): {eg_p:.3f}")

    # ---------------- Step 7 ----------------
    log("Step 7  Rolling-origin backtest ...")
    H = cfg["HORIZON"]
    origins = [i for i in range(len(Ph)) if Ph.index[i] >= pd.Period(cfg["BACKTEST_START"], freq="Q") and i < end]
    M = covid_mask(cfg, Ph.index, origins, H)
    bt_rows, bt_store, coef_store = [], {}, {}
    for m in models:
        E, paths, coefs = backtest(cfg, m, Ph, est0, origins, H)
        bt_store[m.name] = (E, paths)
        coef_store[m.name] = coefs
        Ex = np.where(M, np.nan, E)
        for h in range(H):
            bt_rows.append({"model": m.name, "horizon_q": h + 1,
                            "MAPE_level_all_%": np.nanmean(np.abs(E[:, h])) * 100,
                            "MAPE_level_exCOVID_%": np.nanmean(np.abs(Ex[:, h])) * 100,
                            "bias_exCOVID_%": np.nanmean(Ex[:, h]) * 100,
                            "n_windows": int(np.sum(~np.isnan(Ex[:, h])))})
        log(f"        {m.name:<34s} avg MAPE ex-COVID {np.nanmean(np.abs(Ex)) * 100:5.2f}%   "
            f"h=4 {np.nanmean(np.abs(Ex[:, 3])) * 100:5.2f}%   h=9 {np.nanmean(np.abs(Ex[:, -1])) * 100:5.2f}%")
    bt = pd.DataFrame(bt_rows)
    tables["10_backtest_by_horizon"] = bt
    summ = bt.groupby("model", sort=False).agg(**{"avg MAPE all (%)": ("MAPE_level_all_%", "mean"),
                                                  "avg MAPE ex-COVID (%)": ("MAPE_level_exCOVID_%", "mean"),
                                                  "avg bias ex-COVID (%)": ("bias_exCOVID_%", "mean")})
    summ["MAPE h=1 ex-COVID (%)"] = bt[bt.horizon_q == 1].set_index("model")["MAPE_level_exCOVID_%"]
    summ["MAPE h=4 ex-COVID (%)"] = bt[bt.horizon_q == 4].set_index("model")["MAPE_level_exCOVID_%"]
    summ["MAPE h=9 ex-COVID (%)"] = bt[bt.horizon_q == H].set_index("model")["MAPE_level_exCOVID_%"]
    ar_ref = summ.loc["AR(1) benchmark", "avg MAPE ex-COVID (%)"]
    summ["improvement vs AR (%)"] = (1 - summ["avg MAPE ex-COVID (%)"] / ar_ref) * 100
    summ["inputs"] = [m.inputs() for m in models]
    summ["family"] = [m.family for m in models]
    summ["note"] = [m.note for m in models]
    tables["11_model_comparison"] = summ.reset_index()

    # ---- Data vs theory, model type by model type ----
    PAIRS = [("Small ARDL", "Champion (data-driven)", "Theory ARDL (literature core)"),
             ("Ridge", "Ridge (whole shortlist)", "Theory ridge (core, all lags)"),
             ("Quantile regression", "Quantile regression (median)", "Theory quantile regression"),
             ("ARIMAX", "ARIMAX (champion drivers)", "Theory ARIMAX"),
             ("Factor model", "Factor model (Stock-Watson)", "Theory-restricted factors"),
             ("Random forest", "Random forest (challenger)", "Theory random forest"),
             ("Forecast combination", f"Forecast combination (top {cfg['N_COMBINE']})",
              "Theory combination (4 literature models)")]
    MCOL = "avg MAPE ex-COVID (%)"
    dvt = pd.DataFrame([{"model type": t, "data-driven model": d, "data MAPE (%)": summ.loc[d, MCOL],
                         "theory model": th, "theory MAPE (%)": summ.loc[th, MCOL],
                         "theory minus data (pp)": summ.loc[th, MCOL] - summ.loc[d, MCOL],
                         "data h=9 (%)": summ.loc[d, "MAPE h=9 ex-COVID (%)"],
                         "theory h=9 (%)": summ.loc[th, "MAPE h=9 ex-COVID (%)"]}
                        for t, d, th in PAIRS if d in summ.index and th in summ.index])
    tables["17_data_vs_theory"] = dvt
    hyb = summ[summ["family"].isin(["Hybrid", "Data (no theory)"])][[MCOL, "MAPE h=4 ex-COVID (%)", "MAPE h=9 ex-COVID (%)", "inputs", "note"]]
    tables["17b_hybrid_models"] = hyb.reset_index()
    log("        Data vs theory (avg MAPE ex-COVID):")
    for _, r in dvt.iterrows():
        log(f"          {r['model type']:<22s} data {r['data MAPE (%)']:.2f}%   theory {r['theory MAPE (%)']:.2f}%")

    # ---- Encompassing tests (Fair & Shiller 1990): does each forecast add information? ----
    def cum_paths(name, h):
        out = {}
        for o, fc in bt_store[name][1]:
            if len(fc) >= h:
                out[o] = fc[:h].sum()
        return pd.Series(out)
    enc_rows = []
    covid_a, covid_b = [pd.Period(q, freq="Q") for q in cfg["COVID_WINDOW"]]
    for dname, tname in [("Champion (data-driven)", "Theory ARDL (literature core)"),
                         ("Champion (data-driven)", "Literature ECM")]:
        for h in (1, 4, 8):
            D_, T_ = cum_paths(dname, h), cum_paths(tname, h)
            A_ = pd.Series({o: Ph["y"].loc[o + 1:o + h].sum() for o in D_.index})
            keep = [o for o in D_.index if not ((pd.period_range(o + 1, o + h, freq="Q") >= covid_a) &
                                               (pd.period_range(o + 1, o + h, freq="Q") <= covid_b)).any()]
            dfe = pd.DataFrame({"A": A_[keep], "D": D_[keep], "T": T_[keep]}).dropna()
            r1 = sm.OLS(dfe["A"], sm.add_constant(dfe[["D", "T"]])).fit(cov_type="HAC", cov_kwds={"maxlags": h})
            r2 = sm.OLS(dfe["A"] - dfe["T"], dfe["D"] - dfe["T"]).fit(cov_type="HAC", cov_kwds={"maxlags": h})
            enc_rows.append({"data model": dname, "theory model": tname, "horizon_q": h, "n": len(dfe),
                             "coef on data": r1.params["D"], "p data": r1.pvalues["D"],
                             "coef on theory": r1.params["T"], "p theory": r1.pvalues["T"],
                             "optimal weight on data (0-1 combo)": r2.params.iloc[0],
                             "s.e. of weight": r2.bse.iloc[0]})
    tables["17c_encompassing_tests"] = pd.DataFrame(enc_rows)

    # ---------------- Step 8 ----------------
    log("Step 8  Diagnostics ...")
    signs = meta["expected_sign"].to_dict()
    diag = pd.DataFrame([diagnostics(m, Ph, est0, end, meta, signs) for m in models])
    diag.loc[diag["model"] == "Literature ECM", "note"] = f"Engle-Granger cointegration p = {eg_p:.3f}"
    tables["12_diagnostics"] = diag

    coef_rows = []
    for m in models:
        if m.kind != "ols":
            continue
        m.fit(Ph, end, est0)
        for c in m.res.params.index:
            coef_rows.append({"model": m.name, "term": c,
                              "description": describe_feat(c, meta) if "|" in c else c,
                              "coef": m.res.params[c], "se (HAC)": m.res.bse[c], "t": m.res.tvalues[c],
                              "p": m.res.pvalues[c]})
        if m.ecm:
            for c, v in m.lr_params.items():
                coef_rows.append({"model": m.name + " [long-run]", "term": c, "description": c, "coef": v})
    tables["13_coefficients"] = pd.DataFrame(coef_rows)

    # ---------------- Step 9 ----------------
    log("Step 9  Scenario forecasts ...")
    last_bal = bank[cfg["LOAN_COL"]].iloc[-1]
    nf = len(P) - end - 1
    scen_rows = []
    fc_store = {}
    for m in models:
        m.fit(Ph, end, est0)
        for s, Ps in panels.items():
            fc = m.forecast(Ps, end, nf)
            fc_store[(m.name, s)] = fc
            lvl = last_bal * np.exp(np.cumsum(fc))
            for i, q in enumerate(Ps.index[end + 1:end + 1 + nf]):
                scen_rows.append({"model": m.name, "scenario": s, "date": str(q), "dlog_forecast": fc[i],
                                  "loan_balance_forecast": lvl[i]})
    scen = pd.DataFrame(scen_rows)
    tables["14_scenario_forecasts"] = scen
    piv = scen[scen["date"].str.endswith("Q4")].pivot_table(index=["model", "date"], columns="scenario",
                                                            values="loan_balance_forecast").round(0)
    tables["14b_scenario_yearend_levels"] = piv.reset_index()

    # ---------------- Step 10 ----------------
    log("Step 10 Explainability ...")
    champ = models[1]
    lit = models[3]
    drv = driver_table(champ, Ph, est0, end, meta)
    drv_lit = driver_table(lit, Ph, est0, end, meta)
    tables["15_driver_explanation_champion"] = drv
    tables["15b_driver_explanation_literature"] = drv_lit
    beast = next(m for m in models if "BEAST" in m.name)
    tables["15d_driver_explanation_BEAST"] = driver_table(beast, Ph, est0, end, meta)
    tables["15e_driver_explanation_theory_core"] = driver_table(
        next(m for m in models if m.name == "Theory ARDL (literature core)"), Ph, est0, end, meta)
    tables["15f_driver_explanation_hybrid_ecm"] = driver_table(
        next(m for m in models if m.name == "Hybrid: theory long run + data short run"), Ph, est0, end, meta)
    tables["15h_driver_explanation_hybrid_channels"] = driver_table(
        next(m for m in models if m.name == "Hybrid: theory channels, data measures"), Ph, est0, end, meta)
    pw = next(m for m in models if m.name == "Hybrid: performance-weighted")
    pw.fit(Ph, end, est0)
    tables["15g_performance_weights"] = pd.DataFrame({"member": ["Data champion", "Theory ARDL (literature core)",
                                                                 "Literature ECM"], "weight at 2025Q4": pw.weights})
    lt = []
    for m in models:
        if m.factor:
            m.fit(Ph, end, est0)
            lt.append(m.loadings_table(meta).assign(model=m.name))
    if lt:
        tables["15c_factor_loadings"] = pd.concat(lt)
    tables["08b_combination_members"] = pd.DataFrame(
        {"member": [mm.name for mm in combo_members], "drivers": [", ".join(mm.features) for mm in combo_members]})
    # Bootstrap fan for the champion (baseline and most severe scenario)
    champ.fit(Ph, end, est0)
    fan = {}
    fan_rows = []
    for sname in [cfg["BASE_SCENARIO"], list(cfg["SCENARIO_FILES"])[-1]]:
        sims = simulate_fan(champ, panels[sname], end, nf, cfg["N_SIM"])
        q = np.percentile(last_bal * np.exp(sims), [5, 10, 50, 90, 95], axis=0)
        fan[sname] = q
        for i, dq in enumerate(panels[sname].index[end + 1:end + 1 + nf]):
            fan_rows.append({"scenario": sname, "date": str(dq), "P5": q[0, i], "P10": q[1, i], "P50": q[2, i],
                             "P90": q[3, i], "P95": q[4, i]})
    tables["14c_champion_forecast_bands"] = pd.DataFrame(fan_rows)
    comp, ypath = contributions(champ, Ph, est0, end, fc_store[(champ.name, cfg["BASE_SCENARIO"])], P)

    # ---------------- Charts ----------------
    log("        Writing charts ...")
    # Funnel
    funnel = [("Moody's + constructed variables", n_vars), ("Relevant geography & theme", n_relevant),
              ("With a stationary transform", n_stat_vars),
              ("Pass screen (sig. + right sign)", int(best["passed"].sum())),
              ("Independent clusters", int(clus["cluster"].nunique())), ("Shortlist", len(shortlist)),
              ("Final champion drivers", len(champ_feats))]
    fig, ax = plt.subplots(figsize=(9, 3.6))
    labs = [f[0] for f in funnel][::-1]
    vals = [f[1] for f in funnel][::-1]
    ax.barh(labs, vals, color=PAL[0], height=0.6)
    for i, v in enumerate(vals):
        ax.text(v + max(vals) * 0.01, i, f"{v}", va="center", color=INK, fontsize=10)
    ax.set_title("Variable-selection funnel")
    ax.grid(axis="y", visible=False)
    ax.set_xlim(0, max(vals) * 1.1)
    save(fig, "02_selection_funnel.png")

    # Backtest: ranking of all models + horizon profile of the key ones
    fig, axs = plt.subplots(1, 2, figsize=(14, 5.6), gridspec_kw={"width_ratios": [1, 1.15]})
    rk = summ["avg MAPE ex-COVID (%)"].sort_values()
    cols = [PAL[0] if n == champ.name else ("#b9b8b2" if summ.loc[n, "family"] in ("Benchmark", "Challenger")
            else "#8fb6e8") for n in rk.index]
    axs[0].barh(rk.index[::-1], rk.values[::-1], color=cols[::-1], height=0.65)
    for i, v in enumerate(rk.values[::-1]):
        axs[0].text(v + rk.max() * 0.01, i, f"{v:.2f}%", va="center", fontsize=9, color=INK)
    axs[0].set_title("Average level MAPE, 1–9 quarters (ex-COVID)")
    axs[0].grid(axis="y", visible=False)
    axs[0].set_xlim(0, rk.max() * 1.18)
    key = ["AR(1) benchmark", champ.name, lit.name, f"Forecast combination (top {cfg['N_COMBINE']})",
           "Factor model (Stock-Watson)", "Random forest (challenger)"]
    for i, nm in enumerate([k for k in key if k in summ.index]):
        d = bt[bt.model == nm]
        ls = "--" if summ.loc[nm, "family"] in ("Benchmark", "Challenger") else "-"
        axs[1].plot(d["horizon_q"], d["MAPE_level_exCOVID_%"], color=PAL[i], ls=ls, marker="o", ms=4, label=nm)
    axs[1].set_xlabel("Forecast horizon (quarters ahead)")
    axs[1].set_ylabel("MAPE of loan balance level (%)")
    axs[1].set_title("Error by horizon — key models")
    axs[1].set_ylim(0, None)
    axs[1].legend(fontsize=9)
    fig.tight_layout()
    save(fig, "03_backtest_mape_by_horizon.png")

    # Backtest paths: champion vs literature
    fig, axs = plt.subplots(1, 2, figsize=(13, 4.6), sharey=True)
    lvl_org = np.exp(Ph["logL"])
    for ax, nm, col in [(axs[0], champ.name, PAL[0]), (axs[1], lit.name, PAL[1])]:
        ax.plot(Ph.index.to_timestamp()[est0:], lvl_org.iloc[est0:] / 1000, color=INK, lw=2, label="Actual (organic)")
        for k, (o, fc) in enumerate(bt_store[nm][1]):
            if k % 4:
                continue
            oi = int(np.where(Ph.index == o)[0][0])
            path = lvl_org.iloc[oi] * np.exp(np.cumsum(fc))
            ax.plot(Ph.index[oi + 1:oi + 1 + len(fc)].to_timestamp(), path / 1000, color=col, lw=1.3, alpha=0.9,
                    label="9-quarter forecast paths" if k == 0 else None)
        ax.set_title(nm)
        ax.set_xlim(pd.Timestamp(cfg["BACKTEST_START"][:4] + "-01-01"), None)
        ax.legend(loc="upper left")
    axs[0].set_ylabel("$ billions")
    save(fig, "04_backtest_paths.png")

    # Scenario fan
    fig, axs = plt.subplots(1, 2, figsize=(13, 4.6), sharey=True)
    hx = bank.index.to_timestamp()
    for ax, nm in [(axs[0], champ.name), (axs[1], lit.name)]:
        ax.plot(hx[-24:], bank[cfg["LOAN_COL"]].iloc[-24:] / 1000, color=INK, lw=2, label="Actual")
        for i, s in enumerate(cfg["SCENARIO_FILES"]):
            d = scen[(scen.model == nm) & (scen.scenario == s)]
            xs = pd.PeriodIndex(d["date"], freq="Q").to_timestamp()
            ax.plot(np.r_[hx[-1:], xs], np.r_[last_bal, d["loan_balance_forecast"].values] / 1000,
                    color=[PAL[0], PAL[2], PAL[3], PAL[7]][i], label=s)
        if nm == champ.name:
            for sname, colr in [(cfg["BASE_SCENARIO"], PAL[0]), (list(cfg["SCENARIO_FILES"])[-1], PAL[7])]:
                xs = pd.PeriodIndex(scen[(scen.model == nm) & (scen.scenario == sname)]["date"], freq="Q").to_timestamp()
                ax.fill_between(xs, fan[sname][1] / 1000, fan[sname][3] / 1000, color=colr, alpha=0.13, lw=0,
                                label=f"{sname}: 10–90% band" if sname == cfg["BASE_SCENARIO"] else f"{sname}: 10–90% band")
        ax.set_title(f"Scenario forecasts — {nm}")
        ax.legend(loc="upper left", fontsize=9)
    axs[0].set_ylabel("$ billions")
    save(fig, "05_scenario_forecasts.png")

    # Contributions
    cc = comp.loc[comp.index >= pd.Period("2015Q1", freq="Q")] * 400
    yy = ypath.loc[cc.index] * 400
    fig, ax = plt.subplots(figsize=(13, 5.4))
    xs = np.arange(len(cc))
    pos, neg = np.zeros(len(cc)), np.zeros(len(cc))
    names = list(cc.columns)
    for i, c in enumerate(names):
        v = cc[c].values
        bottom = np.where(v >= 0, pos, neg)
        lab = short_label(c, meta) if "|" in c else c
        color = "#b9b8b2" if c.startswith("COVID") else ("#8fb6e8" if c.startswith("Trend") else PAL[(i) % 8 + 1 if i < 7 else 0])
        ax.bar(xs, v, bottom=bottom, color=color, width=0.8, label=lab, edgecolor=SURF, linewidth=0.6)
        pos = np.where(v >= 0, pos + v, pos)
        neg = np.where(v < 0, neg + v, neg)
    ax.plot(xs, yy.values, color=INK, lw=2, label="Loan growth (actual → baseline forecast)")
    split = int(np.where(cc.index == pd.Period(cfg["HIST_END"], freq="Q"))[0][0]) + 0.5
    ax.axvline(split, color=INK2, lw=1, ls=":")
    ax.text(split + 0.3, ax.get_ylim()[1] * 0.92, "forecast →", color=INK2, fontsize=9)
    ticks = [i for i, q in enumerate(cc.index) if q.quarter == 1]
    ax.set_xticks(ticks)
    ax.set_xticklabels([str(cc.index[i].year) for i in ticks])
    ax.axhline(0, color=INK2, lw=0.8)
    ax.set_ylabel("pp, annualised")
    ax.set_title("What drives loan growth? Dynamic contribution of each driver (champion model)")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.08), ncol=3, fontsize=9)
    save(fig, "06_driver_contributions.png")
    tables["16_contributions_champion"] = (comp * 400).reset_index().rename(columns={"index": "date"}).astype({"date": str})

    # Coefficient stability (champion)
    cs = coef_store[champ.name]
    terms = [c for c in champ.params.index if c not in ("const",) and c not in cfg["DUMMIES"]]
    fig, axs = plt.subplots(1, len(terms), figsize=(3.4 * len(terms), 3.4))
    axs = np.atleast_1d(axs)
    xo = pd.PeriodIndex(cs.index, freq="Q").to_timestamp()
    for ax, tname in zip(axs, terms):
        b, s = cs[tname + "|coef"], cs[tname + "|se"]
        ax.fill_between(xo, b - 2 * s, b + 2 * s, color=PAL[0], alpha=0.18, lw=0)
        ax.plot(xo, b, color=PAL[0])
        ax.axhline(0, color=INK2, lw=0.8)
        ax.set_title(short_label(tname, meta, 26) if "|" in tname else "Loan growth lag 1", fontsize=9)
        ax.tick_params(axis="x", labelsize=8, rotation=45)
    fig.suptitle("Coefficient stability across backtest origins (±2 s.e.)", x=0.01, ha="left", fontsize=12,
                 fontweight="bold", color=INK)
    fig.tight_layout()
    save(fig, "07_coefficient_stability.png")

    # Data vs theory vs hybrid chart
    fig, axs = plt.subplots(1, 2, figsize=(14, 5.4), gridspec_kw={"width_ratios": [1.5, 1]})
    yy_ = np.arange(len(dvt))
    axs[0].barh(yy_ + 0.2, dvt["data MAPE (%)"], height=0.38, color=PAL[0], label="Data-driven variables")
    axs[0].barh(yy_ - 0.2, dvt["theory MAPE (%)"], height=0.38, color=PAL[1], label="Literature (theory) variables")
    for i, r in dvt.iterrows():
        axs[0].text(r["data MAPE (%)"] + 0.01, i + 0.2, f"{r['data MAPE (%)']:.2f}%", va="center", fontsize=8.5, color=INK)
        axs[0].text(r["theory MAPE (%)"] + 0.01, i - 0.2, f"{r['theory MAPE (%)']:.2f}%", va="center", fontsize=8.5, color=INK)
    axs[0].set_yticks(yy_)
    axs[0].set_yticklabels(dvt["model type"])
    axs[0].invert_yaxis()
    axs[0].grid(axis="y", visible=False)
    axs[0].set_xlim(0, max(dvt["data MAPE (%)"].max(), dvt["theory MAPE (%)"].max()) * 1.2)
    axs[0].set_title("Same model type, data vs literature variables (avg MAPE)")
    axs[0].legend(loc="lower right", fontsize=9)
    spectrum = ["Unconstrained data mining (no theory)", champ.name, "Hybrid: 50/50 data + theory",
                "Hybrid: performance-weighted", "Hybrid: theory long run + data short run",
                "Hybrid: theory channels, data measures", "Theory ARDL (literature core)", "Literature ARDL (classic)"]
    spectrum = [n for n in spectrum if n in summ.index]
    hb = summ.loc[spectrum, MCOL]
    fam_col = {"Data (no theory)": "#b9b8b2", "Selected": PAL[0], "Hybrid": PAL[2], "Theory": PAL[1], "Literature": PAL[1]}
    axs[1].barh(range(len(hb)), hb.values, color=[fam_col.get(summ.loc[n, "family"], PAL[0]) for n in hb.index], height=0.6)
    for i, v in enumerate(hb.values):
        axs[1].text(v + 0.01, i, f"{v:.2f}%", va="center", fontsize=8.5, color=INK)
    axs[1].set_yticks(range(len(hb)))
    axs[1].set_yticklabels([n.replace("Hybrid: ", "H: ") for n in hb.index], fontsize=9)
    axs[1].invert_yaxis()
    axs[1].grid(axis="y", visible=False)
    axs[1].set_xlim(0, hb.max() * 1.25)
    axs[1].set_ylabel("← more theory-driven          more data-driven →", fontsize=9)
    axs[1].set_title("From pure data to pure theory (green = hybrids)")
    fig.tight_layout()
    save(fig, "08_data_vs_theory.png")

    # ---------------- Step 11: outputs ----------------
    log("Step 11 Writing workbook and summary ...")
    xl = os.path.join(cfg["OUT_DIR"], "model_results.xlsx")
    with pd.ExcelWriter(xl, engine="openpyxl") as w:
        order = ["11_model_comparison", "15_driver_explanation_champion", "15b_driver_explanation_literature",
                 "12_diagnostics", "13_coefficients", "14b_scenario_yearend_levels"]
        for k in order + [k for k in tables if k not in order]:
            df = tables[k]
            df.to_excel(w, sheet_name=k[:31], index=False)
            ws = w.sheets[k[:31]]
            for col in ws.columns:
                width = min(60, max(10, max(len(str(c.value)) if c.value is not None else 0 for c in col[:200]) + 2))
                ws.column_dimensions[col[0].column_letter].width = width
    for k, df in tables.items():
        df.to_csv(os.path.join(cfg["OUT_DIR"], f"{k}.csv"), index=False)

    # Markdown summary
    s = summ.copy()
    lines = ["# Ontario loan balance forecast — results summary", "",
             f"Target: organic q/q log change of `{cfg['LOAN_COL']}` (inorganic events removed). "
             f"Estimation {cfg['ESTIMATION_START']}–{cfg['HIST_END']}; backtest origins {cfg['BACKTEST_START']} onward, "
             f"1–{H} quarters ahead, macro paths at actual values.", "",
             "## Selection funnel", ""] + [f"- {a}: **{b}**" for a, b in funnel] + [
             "", "## Champion drivers", ""]
    for _, r in drv.iterrows():
        lines.append(f"- **{r['description']}** — coef {r['coef']:.4f}, t = {r['t (HAC)']:.2f}. {r['plain-language reading']}")
    lines += ["", "## Model comparison (average level MAPE over 1–9 quarters, COVID windows excluded)", "",
              "| Model | Inputs | Avg MAPE ex-COVID | h=4 | h=9 | vs AR |", "|---|---|---|---|---|---|"]
    for nm, r in s.iterrows():
        lines.append(f"| {nm} | {r['inputs']} | {r['avg MAPE ex-COVID (%)']:.2f}% | {r['MAPE h=4 ex-COVID (%)']:.2f}% | "
                     f"{r['MAPE h=9 ex-COVID (%)']:.2f}% | {r['improvement vs AR (%)']:+.0f}% |")
    lines += ["", "## Diagnostics", "", diag.drop(columns=[c for c in ["note"] if c in diag]).to_markdown(index=False)
              if hasattr(diag, "to_markdown") else diag.to_string(index=False),
              "", f"Engle-Granger cointegration p-value for the literature long-run relation: {eg_p:.3f}", "",
              "## Year-end balance by scenario ($ millions)", "", piv.to_string(), ""]
    with open(os.path.join(cfg["OUT_DIR"], "results_summary.md"), "w") as f:
        f.write("\n".join(lines))
    log(f"Done. Outputs in {cfg['OUT_DIR']}")
    return tables


if __name__ == "__main__":
    main()
