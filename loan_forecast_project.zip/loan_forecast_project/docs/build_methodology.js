// Builds Methodology_and_Literature_Review.docx
const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, Table, TableRow, TableCell,
  WidthType, ShadingType, BorderStyle, ImageRun, TableOfContents, PageBreak, Footer, PageNumber,
  LevelFormat, ExternalHyperlink,
} = require("docx");

const OUT = path.join(__dirname, "..", "outputs");
const W = 9360; // content width (DXA), Letter with 1" margins
const FONT = "Calibri";
const C_HEAD = "1F3B5C", C_MUTED = "52514E", C_FILL = "E8EEF6", C_BORDER = "C9CED6";

// ---------- helpers ----------
function mathRuns(text, base = {}) {
  // _{..} or _x -> subscript, ^{..} or ^x -> superscript
  const out = [];
  const re = /([_^])(\{[^}]*\}|[^\s{}])/g;
  let last = 0, m;
  const f = { font: "Cambria Math", ...base };
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) out.push(new TextRun({ text: text.slice(last, m.index), ...f }));
    let v = m[2]; if (v.startsWith("{")) v = v.slice(1, -1);
    out.push(new TextRun({ text: v, ...(m[1] === "_" ? { subScript: true } : { superScript: true }), ...f }));
    last = m.index + m[0].length;
  }
  if (last < text.length) out.push(new TextRun({ text: text.slice(last), ...f }));
  return out;
}
function runs(text, base = {}) {
  // **bold** and $math$ inline markup
  const out = [];
  const re = /(\*\*[^*]+\*\*|\$[^$]+\$)/g;
  let last = 0, m;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) out.push(new TextRun({ text: text.slice(last, m.index), ...base }));
    const t = m[0];
    if (t.startsWith("**")) out.push(new TextRun({ text: t.slice(2, -2), bold: true, ...base }));
    else out.push(...mathRuns(t.slice(1, -1), base));
    last = m.index + t.length;
  }
  if (last < text.length) out.push(new TextRun({ text: text.slice(last), ...base }));
  return out;
}
const P = (t, o = {}) => new Paragraph({ children: runs(t), spacing: { after: 120, line: 276 }, ...o });
const H1 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun(t)], pageBreakBefore: true });
const H1n = (t) => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun(t)] });
const H2 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun(t)] });
const H3 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_3, children: [new TextRun(t)] });
const B = (t, lvl = 0) => new Paragraph({ numbering: { reference: "bul", level: lvl }, children: runs(t), spacing: { after: 60, line: 276 } });
let NUM_INST = 1;
const NEWLIST = () => { NUM_INST += 1; };
const N = (t) => new Paragraph({ numbering: { reference: "num", level: 0, instance: NUM_INST }, children: runs(t), spacing: { after: 60, line: 276 } });
const EQ = (t) => new Paragraph({
  children: mathRuns(t, { size: 23 }),
  alignment: AlignmentType.CENTER, spacing: { before: 80, after: 140 },
});
const NOTE = (t) => new Paragraph({
  children: runs(t, { color: C_MUTED, size: 19 }), spacing: { after: 140 },
  border: { left: { style: BorderStyle.SINGLE, size: 12, color: "2A78D6", space: 8 } }, indent: { left: 200 },
});
function FIG(file, caption, widthPx = 620) {
  const p = path.join(OUT, file);
  const buf = fs.readFileSync(p);
  const w = buf.readUInt32BE(16), h = buf.readUInt32BE(20);
  return [
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 120, after: 60 },
      children: [new ImageRun({ type: "png", data: buf, transformation: { width: widthPx, height: Math.round(widthPx * h / w) },
        altText: { title: caption, description: caption, name: file } })] }),
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 },
      children: [new TextRun({ text: caption, italics: true, size: 18, color: C_MUTED })] }),
  ];
}
const border = { style: BorderStyle.SINGLE, size: 4, color: C_BORDER };
const borders = { top: border, bottom: border, left: border, right: border };
function TABLE(header, rows, widths, opts = {}) {
  const total = widths.reduce((a, b) => a + b, 0);
  const cell = (txt, i, isHead) => new TableCell({
    borders, width: { size: widths[i], type: WidthType.DXA },
    shading: isHead ? { fill: C_FILL, type: ShadingType.CLEAR, color: "auto" } : undefined,
    margins: { top: 60, bottom: 60, left: 100, right: 100 },
    children: String(txt).split("\n").map((line) => new Paragraph({
      children: runs(line, { size: opts.size || 18, bold: isHead }), spacing: { after: 0 } })),
  });
  return new Table({
    width: { size: total, type: WidthType.DXA }, columnWidths: widths,
    rows: [new TableRow({ tableHeader: true, children: header.map((h, i) => cell(h, i, true)) }),
      ...rows.map((r) => new TableRow({ children: r.map((c, i) => cell(c, i, false)) }))],
  });
}
const SP = () => new Paragraph({ children: [], spacing: { after: 80 } });

// ---------- content ----------
const c = [];

// Title page
c.push(new Paragraph({ spacing: { before: 2400, after: 200 }, children: [new TextRun({ text: "Ontario Loan Balance Forecasting Model", bold: true, size: 48, color: C_HEAD })] }));
c.push(new Paragraph({ spacing: { after: 600 }, children: [new TextRun({ text: "Methodology and Literature Review", size: 32, color: C_MUTED })] }));
c.push(P("**Model purpose:** quarterly forecast and scenario projection of the Ontario loan balance, driven by Moody's Analytics Canadian macroeconomic scenarios and internal financials."));
c.push(P("**Version:** 1.0 (development draft), October 2026"));
c.push(P("**Status:** methodology complete; results in Section 9 are produced on **simulated data** with the same structure as the production inputs and must be re-run on actual bank and Moody's data before use."));
c.push(P("**Code:** loan_forecast_pipeline.py (pipeline), simulate_data.py (test data). All tables and charts referenced here are generated in the outputs folder."));
c.push(new Paragraph({ children: [new PageBreak()] }));
c.push(new Paragraph({ children: [new TextRun({ text: "Contents", bold: true, size: 28, color: C_HEAD })], spacing: { after: 200 } }));
c.push(new TableOfContents("Contents", { hyperlink: true, headingStyleRange: "1-2" }));

// 1 Executive summary
c.push(H1("1. Executive summary"));
c.push(P("The goal is a loan-balance forecasting model that is **easy to explain** and **forecasts well**, built from a database of about 400 Moody's Canadian macroeconomic variables plus internal data such as deposits. The model has to produce forecasts under Moody's baseline and alternative scenarios, so every driver must be a variable for which Moody's publishes a scenario path."));
c.push(P("The approach follows the practice of central-bank and supervisory models reviewed in Section 3. The target is the organic quarter-on-quarter log change of the loan balance. Candidate drivers are transformed into economically meaningful, stationary forms, screened for statistical significance and the expected economic sign, de-duplicated by correlation clustering, and then searched exhaustively for small (2–4 driver) specifications. Those specifications compete on **out-of-sample** forecast accuracy of the balance level over 1–9 quarters. A parsimony rule picks the simplest model whose error is within 5% of the best."));
c.push(P("Twenty-nine models are compared in three families. **Data-driven** models choose drivers from the Moody's database: an ARDL champion, Elastic Net, ridge, factor models, a forecast combination, ARIMAX, quantile regression, machine-learning challengers and an unconstrained reference. **Theory** models use only variables named in the literature: classic ARDL and ECM, the ECB's 2023 BEAST loan-demand block, and a \"literature core\" estimated with every model type. **Hybrid** models combine the two in six different ways."));
c.push(P("**Key results on simulated data (Section 9):**"));
c.push(B("The selection funnel reduces 406 candidate series to **2 drivers**: house-price growth and Ontario disposable-income growth, plus loan-growth momentum. Both are among the drivers used to generate the test data, so the procedure recovers true signal."));
c.push(B("The champion cuts the average level error versus the AR benchmark by **59%** (0.61% vs 1.50% MAPE over 1–9 quarters; 1.04% at 9 quarters)."));
c.push(B("An equal-weight **forecast combination** of the 10 best constrained models is the most accurate model (0.55%), consistent with Stock & Watson (2004)."));
c.push(B("The classic literature models (Hofmann 2001; Calza et al. 2001) forecast well (0.84–0.90%), but their interest-rate coefficient takes the wrong sign once GDP and house prices are included. The recent ECB BEAST loan-demand specification (2023) has no house-price channel and does only slightly better than the benchmark (1.39%). This is consistent with Bank of Canada evidence that housing is central for Canadian household credit, but it partly reflects how the test data were built."));
c.push(B("Factor and machine-learning models underperform the small explainable models at every horizon beyond one quarter, which supports the design choice."));
c.push(B("**Data versus theory:** with the same model type, data-chosen variables beat literature variables in 6 of 7 types (by 0.03–0.17 pp). The literature core's house-price and income terms are strong, but its mortgage-rate and unemployment terms are insignificant, so carrying them adds noise. Theory wins only for factor models, where restricting the series to literature themes removes irrelevant ones."));
c.push(B("**Theory still adds information.** Encompassing tests show the literature ECM keeps a significant weight of about 30% at the 8-quarter horizon. In the hybrid that adds the literature error-correction term to the champion, that term is significant (λ = −0.071, about 7% of the gap to the long-run level closing each quarter), and severe-scenario losses are larger and more persistent, consistent with Bank of Canada evidence of slow mortgage-debt adjustment."));
c.push(B("**Unconstrained data mining** (no theory rules) scores slightly better in the backtest (0.55%) but selects US and Windsor house prices, Manitoba GDP and Nova Scotia income. That is the cost theory avoids: 0.06 pp of backtest accuracy buys drivers that can be explained and defended."));
c.push(P("**Recommendation (balance of data and theory):** use theory as **constraints and structure**, and data for **measurement and selection**. In practice:"));
c.push(B("**Primary model:** the champion, a theory-constrained data model with sign priors, relevant geographies and one driver per channel."));
c.push(B("**Scenarios and stress testing:** the hybrid with the literature error-correction term (theory long run, data short run). It has the same 9-quarter accuracy as the champion and more realistic persistence under stress."));
c.push(B("**Challenger:** the performance-weighted combination of data and theory models, alongside the data forecast combination."));
c.push(P("**Next steps:** Re-run the full selection on the actual data. Decide with the business and model-risk teams whether an interest-rate driver must be forced in for stress-testing sensitivity (configuration option REQUIRED_THEMES)."));

// 2 Scope
c.push(H1("2. Scope, intended use and requirements"));
c.push(TABLE(["Item", "Description"], [
  ["Portfolio", "Loan balance of the Ontario section (end-of-quarter balance, $ millions)."],
  ["Frequency / horizon", "Quarterly. Backtest horizon 1–9 quarters (standard stress-test horizon); scenario projection to the end of the Moody's forecast (5 years)."],
  ["Uses", "Business planning and budgeting; scenario analysis under Moody's baseline, upside (S1), downside (S3) and severe (S4) scenarios; input to stress testing, capital and liquidity planning."],
  ["Inputs", "Bank loan and deposit balances; inorganic events (acquisitions, portfolio sales); Moody's Analytics Canada national, provincial and CMA scenario data (history plus forecast)."],
  ["Requirements", "(1) Drivers must have Moody's scenario paths. (2) Coefficients must have economically sensible signs. (3) No more than about 4–6 drivers for explainability. (4) Better out-of-sample accuracy than a time-series benchmark. (5) Stable coefficients and clean residual diagnostics. (6) Directionally sensible, monotone scenario responses."],
], [2200, 7160]));

// 3 Literature
c.push(H1("3. Literature review"));
c.push(P("The review covers five strands:"));
c.push(B("Theory of why bank credit moves with the economy."));
c.push(B("Empirical credit-demand models."));
c.push(B("Canadian evidence, with emphasis on the Bank of Canada."));
c.push(B("How central banks and supervisors project balance sheets in stress tests."));
c.push(B("Methods for forecasting with many predictors."));
c.push(B("Recent developments, 2019–2026: dynamic balance sheets in stress tests, Canadian mortgage-renewal research, big-data and machine-learning forecasting, and model-risk regulation."));
c.push(P("The foundational studies (Sections 3.1–3.5) still define the standard specification. Section 3.6 reviews the recent work that updates it, and Section 3.8 draws out the design implications."));

c.push(H2("3.1 Why credit moves with the cycle: theory"));
c.push(P("Loan volumes are an equilibrium of **credit demand** (households and firms borrowing to finance consumption, housing and investment) and **credit supply** (banks' willingness and capacity to lend). On the demand side, borrowing rises with income and activity and falls with the cost of credit."));
c.push(P("On the supply side, the bank lending channel (Bernanke & Blinder, 1988; Kashyap & Stein, 2000) and the broader credit channel of monetary policy (Bernanke & Gertler, 1995) imply that policy rates and bank funding conditions shift loan supply. Collateral models (Kiyotaki & Moore, 1997) explain why **asset prices, especially house prices, amplify credit cycles**: higher collateral values relax borrowing constraints, which feeds back into asset prices."));
c.push(P("These mechanisms give the expected signs used in this project:"));
c.push(B("Activity and income: positive."));
c.push(B("House prices: positive."));
c.push(B("Interest rates: negative."));
c.push(B("Unemployment and credit stress: negative."));

c.push(H2("3.2 Empirical credit-demand models"));
c.push(P("**Calza, Gartner & Sousa (2001; Applied Economics 2003)** model euro-area loans to the private sector with a Johansen cointegrated VAR. One long-run relation links real loans positively to real GDP and negatively to short- and long-term real interest rates. Short-run dynamics follow a vector error-correction model whose parameters are stable over 1980–1999. **Calza, Manrique & Sousa (2003, ECB WP 202)** extend this with a composite bank lending rate."));
c.push(P("**Hofmann (2001, BIS WP 108; 2004, International Finance)** studies 16 industrialised countries. Standard credit-demand variables alone do not cointegrate with credit. Once real property prices are added, a long-run relation emerges linking real credit positively to real GDP and property prices and negatively to the real interest rate, with significant two-way dynamics between credit and property prices."));
c.push(P("**Guo & Stepanyan (2011, IMF WP 11/51)** study a broad panel of emerging markets and find that:"));
c.push(B("Domestic deposit funding and foreign funding both raise credit growth."));
c.push(B("Stronger GDP growth raises credit growth."));
c.push(B("Inflation raises nominal credit growth but lowers real credit growth."));
c.push(P("This motivates the deposit-augmented two-equation model in this project. For Canada specifically, **Duttagupta & Barrera (2010, IMF WP 10/5)** use a Bayesian VAR and show that financial conditions, including lending standards, explain about one-third of the variability of Canadian real GDP growth. Credit and the macroeconomy are therefore jointly determined."));

c.push(H2("3.3 Canadian evidence: Bank of Canada and IMF"));
c.push(P("**Muellbauer, St-Amant & Williams (2015, BoC Staff Working Paper 2015-40)** jointly estimate error-correction equations for consumption, house prices and mortgage debt (1982–2015). They use a latent credit-conditions index, interest rates, income, wealth components, housing supply and demographics. Three findings matter here:"));
c.push(B("Easier credit conditions raise house prices and debt."));
c.push(B("Mortgage debt and house prices adjust to their long-run levels over about **five years**, which the authors attribute to Canada's mostly 5-year fixed-rate mortgages."));
c.push(B("The rise in house prices since the late 1990s is explained mainly by income growth, supply constraints, lower mortgage rates and easier credit."));
c.push(P("This supports an error-correction term and multi-quarter lags for rates and house prices."));
c.push(P("**Bounajm & McWhirter (2024, BoC Staff Analytical Note 2024-1)** describe how mortgage debt and payments are modelled with error-correction equations inside the Bank's LENS semi-structural macro model. They use nominal residential investment, real effective rates on new mortgages, policy and risk-free rates, and the term and type composition of mortgages from regulatory A4 filings. They stress the slow pass-through of rate changes because of renewal timing."));
c.push(P("Other Bank of Canada work fills in specific mechanisms:"));
c.push(B("**Christensen, Corrigan, Mendicino & Nishiyama (2009, BoC SWP 2009-26):** an estimated DSGE model in which housing collateral links consumption and house prices in Canada."));
c.push(B("**Bailliu, Kartashova & Meh (2012, Bank of Canada Review):** attribute the rise in household borrowing to rising house prices, low interest rates and financial innovation, especially home-equity extraction."));
c.push(B("**Al-Mqbali, Bilyk, Caputo & Younker (2019, BoC SAN 2019-14):** use new regulatory data to show that growth in combined mortgage-HELOC products came from the amortizing mortgage component."));
c.push(B("**Hartley & Paixão (2024, BoC SAN 2024-25):** find that extending the mortgage stress test to low-ratio mortgages in 2018 reduced both credit and house-price growth. Regulatory breaks of this kind can shift the loan-growth relationship."));
c.push(B("**Krznar & Morsink (2014, IMF WP 14/83):** associate the macroprudential tightenings after 2010 with slower mortgage credit and house-price growth."));
c.push(B("**Pugh, Wang & Webley (2026, BoC Staff Analytical Paper 2026-12):** relate mortgage arrears to labour-market conditions, interest rates, house prices and inflation, and build a predictive model for stress analysis."));

c.push(H2("3.4 Stress-testing practice: how balance sheets are projected"));
c.push(P("Supervisory practice varies more than one might expect:"));
c.push(B("The **Federal Reserve's** supervisory stress test does not publish a loan-growth equation. Its 2017 methodology projected balances from historical patterns with assumptions limiting credit contraction; its **2025 methodology** assumes firms maintain their current level of assets, including loans, over the nine-quarter horizon."));
c.push(B("The NY Fed **CLASS** model (Hirtle, Kovner, Vickery & Bhanot, 2014/2015) assumes a fixed 1.25% quarterly asset growth rate. Its income and loss ratios use the simple form $ratio_t = α + β·ratio_{t−1} + γ·macro_t$. The macro variables include the unemployment rate, real GDP, house prices, Treasury yields, BBB yields and spreads, and equity prices."));
c.push(B("The **IMF's 2025 FSAP stress test for Canada** uses a static balance sheet and models credit risk with Bayesian model averaging."));
c.push(B("The **Bank of Canada's MFRAF** (Fique, 2017) focuses on solvency–liquidity feedback and fire-sale effects for systemically important banks. **HRAM** (Peterson & Roberts, 2016) stress-tests household balance sheets at the micro level."));
c.push(B("**Hipp & Ojea Ferreiro (2026, BoC SWP 2026-26)** model banks' portfolio choices under regulatory constraints. Lending is stable while capital buffers are comfortable and contracts sharply near the thresholds, a non-linearity that linear loan-growth models miss."));
c.push(P("Two econometric approaches from this literature are adopted directly:"));
c.push(B("**Covas, Rump & Zakrajšek (2013, FEDS 2013-55)** use fixed-effects quantile autoregressions with scenario macro variables and show that linear models understate losses in the tails. This motivates the quantile-regression model."));
c.push(B("**Kapinos & Mitnik (2016, Journal of Financial Services Research)** propose a top-down stress test that expands the CCAR macro variables with lags of 0–4 quarters and polynomial terms, selects among them with LASSO, and summarises the selected set with principal components. This project's transform-lag-select pipeline follows the same logic with stronger explainability constraints."));

c.push(H2("3.5 Forecasting with many predictors"));
c.push(B("**Factor models:** Stock & Watson (2002, JBES) show that a few principal-component factors (diffusion indexes) extracted from a large panel forecast macro series well. **Bai & Ng (2008, Journal of Econometrics)** improve on this by extracting factors only from **targeted predictors** pre-selected for their relevance to the target. At the Bank of Canada, Cheung & Demers (2007, SWP 2007-8) find that factor models beat benchmarks for Canadian GDP and core inflation up to 8 quarters ahead. Chernis & Sekkel (2017, SWP 2017-2) build a dynamic factor model for nowcasting Canadian GDP."));
c.push(B("**Shrinkage:** LASSO (Tibshirani, 1996), ridge (Hoerl & Kennard, 1970) and the Elastic Net (Zou & Hastie, 2005) handle many correlated predictors."));
c.push(B("**Combination:** Stock & Watson (2004, Journal of Forecasting) document that simple equal-weight combinations of many forecasts are hard to beat, which echoes Bates & Granger (1969)."));
c.push(B("**Machine learning:** random forests (Breiman, 2001) and gradient boosting (Friedman, 2001) capture non-linearity. On small macro samples, however, statistical models often match or beat ML methods (Makridakis, Spiliotis & Assimakopoulos, 2018)."));
c.push(B("**Deep learning:** Transformer architectures (Vaswani et al., 2017) need far more observations than the roughly 95 quarterly data points available here and offer little explainability, so they are not pursued."));

c.push(H2("3.6 Recent developments (2019–2026)"));
c.push(H3("Dynamic balance sheets in stress testing"));
c.push(P("The most relevant recent model is the ECB's **BEAST** (Budnik et al., 2023, ECB Working Paper 2855), a semi-structural stress-test model in which loan volumes are projected dynamically rather than held fixed. Loan growth is decomposed into **demand** and **supply**:"));
c.push(B("**Demand** is estimated by panel regression on real GDP growth and inflation (both positive), the change in unemployment, the short-term rate, the long–short term spread, the effective rate on new loans and lagged loan growth."));
c.push(B("**Supply** depends on bank capital surpluses or shortfalls, the leverage ratio, non-performing loans, profitability and funding costs. It is strongly non-linear: banks with a CET1 shortfall cut lending sharply."));
c.push(P("By contrast, the Fed's 2025 methodology and the IMF's 2025 Canada FSAP both keep a static balance sheet. Hipp & Ojea Ferreiro (2026, BoC SWP 2026-26) show for Canada that lending responds non-linearly near regulatory capital thresholds. A macro-driven loan model like this one is therefore a **demand-side** model; supply constraints in severe scenarios need a separate overlay."));
c.push(H3("Canadian mortgage and household credit, 2023–2026"));
c.push(B("**Bounajm & McWhirter (2024)** build mortgage debt and payments into the Bank of Canada's LENS model as error-correction equations with term- and type-level detail."));
c.push(B("**Godbout, Su & Xu (2025, BoC SAN 2025-21)** estimate that about 60% of mortgage holders renewing in 2025–26 face higher payments, with 5-year fixed borrowers seeing increases of roughly 15–20%. This lagged pass-through supports long rate lags and a payment-to-income variable."));
c.push(B("**Hartley & Paixão (2024)** find that the 2018 extension of the mortgage stress test reduced credit and house-price growth, a policy break the model must allow for."));
c.push(B("**MacGee & Yao (2026, BoC SWP 2026-1)** show that, with fixed-amortization mortgages, higher trend inflation front-loads real payments and lowers debt-to-income. Inflation's effect on mortgage credit is therefore not neutral, which is why it is included without a forced sign in the classic literature model."));
c.push(B("**Pugh, Wang & Webley (2026)** model mortgage arrears on labour-market conditions, rates, house prices and inflation, the same macro channels used here."));
c.push(H3("Big data and machine learning in macro forecasting"));
c.push(B("**Giannone, Lenza & Primiceri (2021, Econometrica)** show that with many predictors the posterior rarely concentrates on one sparse model: the \"illusion of sparsity\". This is a direct caution against relying on a single 2-driver model, and it motivates running the forecast combination of the top models alongside the champion."));
c.push(B("**Goulet Coulombe, Leroux, Stevanovic & Surprenant (2022, Journal of Applied Econometrics)** find that non-linearity is the main gain from machine learning, concentrated in periods of high uncertainty, financial stress and housing busts, and that factor models remain the best form of regularisation. This supports keeping a non-linear challenger, especially for severe scenarios."));
c.push(B("**Fortin-Gagnon, Leroux, Stevanovic & Surprenant (2022, Canadian Journal of Economics)** build a large Canadian and provincial macro database and show its factors forecast Canadian activity well. It is a public cross-check for the Moody's factor model."));
c.push(B("**Bluwstein, Buckmann, Joseph, Kapadia & Simsek (2023, Journal of International Economics)** use machine learning with Shapley-value explanations and find that credit growth and the yield-curve slope are the dominant predictors of financial crises. This motivates the term-spread variable and shows how ML outputs can be explained."));
c.push(H3("Model-risk regulation"));
c.push(P("OSFI's revised **Guideline E-23 on Model Risk Management** (published September 2025, effective May 2027) covers statistical, judgmental and AI/ML models. It sets expectations on explainability, validation and monitoring that shape the choices in Sections 6–10."));

c.push(H2("3.7 Summary of the reviewed models"));
c.push(TABLE(["Study", "Dependent variable", "Main drivers", "Method", "Used here as"], [
  ["Calza, Gartner & Sousa (2001/2003), ECB", "Real private-sector loans", "Real GDP (+), short and long real rates (−)", "Cointegrated VAR / VECM", "Literature ARDL and ECM"],
  ["Hofmann (2001, 2004), BIS", "Real private credit", "Real GDP (+), real property prices (+), real rate (−)", "Cointegrated VAR", "Literature ECM long run"],
  ["Guo & Stepanyan (2011), IMF", "Bank credit growth", "GDP growth (+), deposits/funding (+), inflation", "Panel regression", "Two-equation deposit model"],
  ["Muellbauer, St-Amant & Williams (2015), BoC", "Mortgage debt, house prices, consumption", "Credit conditions, rates, income, wealth, demographics", "Equation-system ECM (FIML)", "ECM design, lag lengths"],
  ["Bounajm & McWhirter (2024), BoC", "Mortgage debt and payments", "Residential investment, effective mortgage rates, term mix", "ECM in LENS", "Rate pass-through, lags"],
  ["Hirtle et al. (2014/15), NY Fed CLASS", "PPNR and loss ratios; assets grow at fixed rate", "Unemployment, GDP, house prices, yields, spreads, equities", "AR(1) + macro", "Benchmark form (AR + macro)"],
  ["Covas, Rump & Zakrajšek (2013), Fed", "Net charge-offs, PPNR", "Scenario macro variables", "Panel quantile AR", "Quantile regression model"],
  ["Kapinos & Mitnik (2016), FDIC", "Bank outcomes under stress", "CCAR variables with lags 0–4 and polynomials", "LASSO + PCA", "Transform-lag-select pipeline"],
  ["Stock & Watson (2002); Bai & Ng (2008)", "Macro series", "Factors from large panels / targeted predictors", "PCA factor regressions", "Factor models"],
  ["Stock & Watson (2004)", "Output growth", "Many single-predictor models", "Forecast combination", "Combination model"],
  ["IMF FSAP Canada (2025); BoC MFRAF (2017); Fed (2025)", "Bank solvency", "Scenario macro paths to PD/LGD", "Static balance sheet", "Context: balance sheet held static"],
  ["Budnik et al. (2023), ECB BEAST", "Loan volumes (demand and supply)", "GDP, inflation, Δunemployment, short rate, term spread, lending rate; bank capital", "Panel regressions in a semi-structural model", "Recent literature ARDL"],
  ["Godbout, Su & Xu (2025); Pugh, Wang & Webley (2026), BoC", "Mortgage payments at renewal; arrears", "Rates by term, labour market, house prices, inflation", "Loan-level simulation; regression", "Rate lags, payment-to-income"],
  ["Giannone, Lenza & Primiceri (2021)", "Macro, micro and finance targets", "Many predictors", "Bayesian spike-and-slab", "Rationale for combination"],
  ["Goulet Coulombe et al. (2022)", "Canadian/US macro series", "Large panels", "ML vs factor models", "Non-linear challengers"],
], [2000, 1700, 2260, 1500, 1900], { size: 16 }));

c.push(H2("3.8 Implications for this model"));
c.push(N("**Model the growth rate, with persistence.** CLASS-style AR(1) + macro equations are standard and transparent; the lagged dependent variable captures adjustment dynamics."));
c.push(N("**Expect house prices, income/activity and interest rates.** These are the core long-run determinants in Hofmann and Calza et al., and the dominant Canadian channels according to Bank of Canada work. Use them as sign priors and as the literature model."));
c.push(N("**Allow long lags and an error-correction term.** Canadian mortgage debt adjusts slowly (about five years), and rate pass-through is delayed by renewals."));
c.push(N("**Control for regime and regulatory breaks.** Examples are the COVID quarters, the B-20 changes and inorganic events."));
c.push(N("**Use selection and shrinkage, then summarise.** Use LASSO/Elastic Net and PCA with many lagged transforms (Kapinos & Mitnik), but keep the final model small for explainability."));
c.push(N("**Benchmark against factor models and combinations,** which are strong in the forecasting literature, and against non-linear and quantile approaches for tail behaviour."));
c.push(N("**Do not trust a single sparse model on its own.** Following Giannone et al. (2021), run the combination of the best explainable models as a standing challenger."));
c.push(N("**Treat the model as demand-side.** Following BEAST (2023) and Hipp & Ojea Ferreiro (2026), add an expert or capital-constraint overlay for credit supply in severe scenarios."));

// 4 Data
c.push(H1("4. Data"));
c.push(H2("4.1 Target variable"));
c.push(P("Let $L_t$ be the end-of-quarter loan balance. Balances are non-stationary (ADF p = 0.98; KPSS rejects stationarity), while the log difference is stationary (ADF p < 0.001; KPSS p = 0.10). The target is the **organic** quarterly log change. For a quarter with an inorganic event of size $A_t$ (an acquired portfolio, or a sale with negative $A_t$), the event is removed so it is not mistaken for economically driven growth:"));
c.push(EQ("y_t = ln[(L_t − A_t) / L_{t−1}]"));
c.push(P("An organic level index is rebuilt as $ln L̃_t = ln L_0 + Σ y_s$. It is used for the error-correction term and for measuring backtest errors. Monthly data are converted to quarter-end."));
c.push(...FIG("01_target.png", "Figure 1. Loan balance (reported and organic) and the stationary modelling target.", 520));
c.push(H2("4.2 Macroeconomic data"));
c.push(P("Moody's Analytics delivers about 400 Canadian series: national, provincial and CMA-level output, labour, income, housing, prices, rates, credit, financial markets and US variables. Each scenario file contains history plus the scenario path."));
c.push(P("A metadata file records, for each mnemonic, its description, geography, **economic theme**, base transformation (log-based for levels, difference-based for rates) and **expected sign** on loan growth (+1, −1, or 0 for no prior). The metadata is where expert judgement enters the model, and it must be reviewed by the business before running."));
c.push(P("A **relevance filter** keeps variables whose geography is Ontario (including Ontario CMAs) or Canada. It also excludes industry-level detail and miscellaneous survey series for a total retail/mortgage book."));
c.push(H2("4.3 Constructed variables"));
c.push(P("Six variables suggested by the literature are constructed from Moody's series before transformation:"));
c.push(TABLE(["Mnemonic", "Definition", "Rationale", "Sign"], [
  ["XRMORTREAL.IC", "5-year mortgage rate − Ontario CPI y/y inflation", "Real cost of borrowing (Hofmann; Calza et al.)", "−"],
  ["XMORTSPRD.IC", "5-year mortgage rate − 5-year GoC yield", "Credit-supply tightness / bank margins", "−"],
  ["XTERM.IC", "10-year GoC yield − overnight rate", "Yield curve; bank lending incentives", "none"],
  ["XHPIREAL.ION", "Ontario HPI / CPI", "Real collateral value (Hofmann)", "+"],
  ["XYPDPC.ION", "Real disposable income per capita, Ontario", "Debt-servicing capacity", "+"],
  ["XPTI.ION", "Annuity payment on HPI at the 5-year rate (25-year amortisation) / income", "Affordability, the mortgage stress-test channel", "−"],
], [1700, 3200, 3360, 1100]));
c.push(H2("4.4 Internal data and special periods"));
c.push(P("Deposits enter only the two-equation model. They are internal and have no Moody's scenario path, so they must themselves be forecast from macro drivers. Each COVID quarter from 2020Q1 to 2021Q2 gets its own dummy. This removes the influence of payment deferrals and government transfers on the coefficients and on variable selection, and these quarters are also excluded from the headline backtest metrics."));

// 5 Transformations
c.push(H1("5. Variable transformations"));
c.push(P("Each variable is tried in several economically interpretable forms. All rolling windows are **one-sided** (past data only), so no transform uses future information. Each form is tested for stationarity with an Augmented Dickey-Fuller test (p < 0.05), and each stationary form is tried with lags of 0–4 quarters."));
c.push(TABLE(["Code", "Applies to", "Formula", "Interpretation"], [
  ["dlog", "levels", "$ln x_t − ln x_{t−1}$", "q/q growth"],
  ["yoy", "levels", "$ln x_t − ln x_{t−4}$", "y/y growth (smoother)"],
  ["dlog2", "levels", "$ln x_t − ln x_{t−2}$", "2-quarter growth"],
  ["acc", "levels", "$(ln x_t − ln x_{t−4}) − (ln x_{t−4} − ln x_{t−8})$", "acceleration: change in annual growth"],
  ["gap", "levels", "$ln x_t − mean(ln x_{t−11..t})$", "deviation from 3-year trailing average (cyclical position)"],
  ["rdlog / ryoy", "nominal income, housing, consumption, credit", "growth of $x_t / CPI_t$", "real (inflation-adjusted) growth"],
  ["diff", "rates", "$r_t − r_{t−1}$", "q/q change (pp)"],
  ["diff2 / diff4", "rates", "$r_t − r_{t−2}$ / $r_t − r_{t−4}$", "2-quarter / annual change"],
  ["lvl", "rates", "$r_t$", "level, kept only if stationary"],
  ["rgap", "rates", "$r_t − mean(r_{t−11..t})$", "rate relative to its recent norm"],
], [1300, 2100, 3260, 2700]));
c.push(P("On the simulated data, 175 relevant variables generate about 3,000 stationary transformed-and-lagged candidate features. Section 9 reports which forms are selected: q/q growth and acceleration are chosen most often."));

// 6 Selection
c.push(H1("6. Variable selection"));
c.push(H2("6.1 Univariate screen"));
c.push(P("For every candidate feature x (variable × transform × lag), a partial regression controls for loan-growth persistence and the COVID dummies:"));
c.push(EQ("y_t = α + ρ·y_{t−1} + Σ_q γ_q·D_{q,t} + β·x_t + ε_t"));
c.push(P("Inference uses Newey-West (HAC) standard errors with 4 lags (Newey & West, 1987). A feature passes if **p < 0.05 and sign(β) equals the expected sign**. Variables with no sign prior are excluded by default, because a driver whose direction cannot be explained should not be in the model. For each variable, the best passing transform and lag (highest |t|) is kept."));
c.push(H2("6.2 Redundancy removal"));
c.push(P("Many Moody's series carry the same information (for example, house prices for each Ontario CMA). Passing variables are clustered hierarchically (average linkage) on the distance 1 − |ρ|, cutting at |ρ| = 0.75. One representative is kept per cluster: the strongest member, except that an **Ontario-level** series is preferred when its |t| is at least 75% of the best member's, because Ontario series are easier to explain for an Ontario book. The 25 strongest representatives form the shortlist."));
c.push(H2("6.3 Constrained exhaustive search"));
c.push(P("Every combination of 2–4 shortlisted drivers (15,250 on the simulated data) is estimated with the specification in Section 7.2 and must satisfy all of the following:"));
c.push(B("All drivers significant (|t| > 1.96)."));
c.push(B("All signs as expected."));
c.push(B("Maximum variance inflation factor below 5."));
c.push(B("At most one driver per economic theme, which guarantees the model tells a multi-channel story rather than, say, two housing variables."));
c.push(B("Optionally, required themes (for example, an interest-rate driver for stress-test sensitivity)."));
c.push(P("The 300 best combinations by BIC go to an **out-of-sample race** (Section 8), ranked by average level MAPE over 1–9 quarters. A **parsimony rule** then selects the specification with the fewest drivers (and, on ties, the highest minimum |t|) among those whose error is within 5% of the best. This is analogous to the one-standard-error rule, and it guards against a combination winning the race by luck."));
c.push(H2("6.4 Elastic Net (alternative selection)"));
c.push(P("An Elastic Net (Zou & Hastie, 2005) is fitted on the standardised shortlist with time-series cross-validation (5 expanding folds), and the penalty and L1 ratio are chosen by CV. The largest non-zero predictors (up to 6) are then re-estimated by OLS (post-selection OLS), so the coefficients are unbiased and interpretable."));

// 7 Models
c.push(H1("7. Model specifications"));
c.push(P("All models forecast $y_t$. Multi-step forecasts are **iterated**: the lagged target uses its own forecast, and macro drivers come from the Moody's scenario. The balance is recovered as $L̂_{T+h} = L_T · exp(Σ_{s=1..h} ŷ_{T+s})$. COVID dummies are set to zero in forecasts."));
c.push(H2("7.1 Benchmark: AR(1)"));
c.push(EQ("y_t = α + ρ·y_{t−1} + Σ γ_q·D_{q,t} + ε_t"));
c.push(H2("7.2 Champion: ARDL with selected drivers"));
c.push(EQ("y_t = α + ρ·y_{t−1} + Σ_{j=1..k} β_j·x_{j,t−ℓ_j} + Σ γ_q·D_{q,t} + ε_t,   k ≤ 4"));
c.push(P("Estimated by OLS with HAC standard errors. The long-run effect of driver j is $β_j / (1 − ρ)$. The same form underlies CLASS and most supervisory satellite models."));
c.push(H2("7.3 Elastic Net and Ridge models"));
c.push(P("The Elastic Net model is post-selection OLS on the Elastic Net's chosen drivers. The Ridge model keeps all 25 shortlisted drivers plus the lagged target, with an L2 penalty chosen by time-series CV. It tests whether shrinkage on many drivers beats selection."));
c.push(H2("7.4 Literature ARDL"));
c.push(P("This model uses the drivers named in the literature: Ontario real GDP growth, Ontario house-price growth, the change in the 5-year mortgage rate, the change in the overnight rate (Calza et al.; Hofmann) and Ontario CPI inflation (Guo & Stepanyan). Each driver's lag is chosen by the screen, and signs are reported but not imposed."));
c.push(H3("Recent specification: ECB BEAST loan demand"));
c.push(P("A second literature ARDL uses the loan-demand drivers of Budnik et al. (2023): Ontario real GDP growth and CPI inflation (expected +), the change in Ontario unemployment, the change in the overnight rate and the change in the 10-year-minus-overnight term spread (expected −). Lags are chosen in the same way. Bank-specific supply variables are outside the scope of a macro-only model."));
c.push(H2("7.5 Literature error-correction model"));
c.push(P("**Long run** (Engle & Granger, 1987, first step), in the spirit of Hofmann (2001) and Calza et al. (2001):"));
c.push(EQ("ln(L̃_t / P_t) = θ_0 + θ_1·ln GDP^{real}_t + θ_2·ln(HPI_t / P_t) + θ_3·(i^{mort}_t − π_t) + u_t"));
c.push(P("**Short run:**"));
c.push(EQ("y_t = α + ρ·y_{t−1} + λ·u_{t−1} + Σ β_j·Δx_{j,t−ℓ_j} + Σ γ_q·D_{q,t} + ε_t,   λ < 0"));
c.push(P("Cointegration is tested with the Engle-Granger test. In forecasting, $u_t$ is updated each step with the forecast loan level and the scenario macro path. The ARDL bounds test of Pesaran, Shin & Smith (2001) is a robust alternative when the order of integration is uncertain."));
c.push(H2("7.6 Champion + deposits (two-equation system)"));
c.push(P("Following Guo & Stepanyan (2011), deposit funding may support lending. Deposit growth $y^D_t$ gets its own macro equation, selected with the same pipeline (up to 3 drivers). The loan equation adds $y^D_{t−1}$. In forecasting, deposits are projected first and then fed into the loan equation."));
c.push(H2("7.7 Factor models"));
c.push(P("**Stock-Watson diffusion index:** the first K = 3 principal components $F_t$ of all relevant standardised series (one standard stationary form each) are added to an AR(1) as $F_t$ and $F_{t−1}$. **Bai-Ng targeted factors:** the first K = 2 principal components of only the screened predictors. Factors and loadings are **re-estimated at every backtest origin** using data up to that origin. Scenario factor paths are obtained by projecting the scenario data onto the loadings. Loadings tables make the factors interpretable."));
c.push(H2("7.8 Forecast combination"));
c.push(EQ("ŷ^{comb}_{T+h} = (1/M) Σ_{m=1..M} ŷ^{(m)}_{T+h},   M = 10"));
c.push(P("The members are the 10 best constrained specifications from Section 6.3, so every member is itself explainable. Equal weights avoid estimating weights, which is a known source of instability (Stock & Watson, 2004)."));
c.push(H2("7.9 ARIMAX"));
c.push(P("The champion's drivers are kept, but the dynamics come from ARMA(1,1) errors instead of a lagged dependent variable: $y_t = α + Σ β_j x_{j,t−ℓ_j} + u_t$, with $u_t = φ u_{t−1} + e_t + θ e_{t−1}$. Estimated by maximum likelihood in state-space form."));
c.push(H2("7.10 Quantile regression"));
c.push(P("The champion specification is estimated at the conditional median (Koenker & Bassett, 1978), which is robust to outliers. Other quantiles (for example, the 10th percentile) can be used for downside stress views (Covas, Rump & Zakrajšek, 2013)."));
c.push(H2("7.11 Machine-learning challengers"));
c.push(P("Gradient boosting (300 depth-2 trees, learning rate 0.03) and a random forest (200 trees, minimum leaf size 3) are fitted on the lagged target plus the 25 shortlisted drivers and iterated recursively. They test for non-linearity the linear models miss. They are not proposed for production, because they cannot be explained to the standard required and they extrapolate poorly outside the historical range, which matters most in severe scenarios."));

// 8 Validation
c.push(H2("7.12 Theory versions of each model type"));
c.push(P("To compare data and theory on equal terms, each model type is also estimated on literature variables only. The **literature core** distils the review into the four channels most consistently supported for Canadian household and mortgage credit. Lags are restricted to theory-based windows (rates act slowly because of 5-year renewals), and within each window the lag with the expected sign and the highest |t| is used:"));
c.push(TABLE(["Channel", "Moody's variable", "Lags", "Sign", "Main sources"], [
  ["House prices (collateral)", "Ontario HPI, q/q growth", "0–2", "+", "Hofmann (2001, 2004); Muellbauer et al. (2015); Bailliu et al. (2012)"],
  ["Household income", "Ontario disposable income, q/q growth", "0–2", "+", "Muellbauer et al. (2015); Calza et al. (2001); Guo & Stepanyan (2011)"],
  ["Cost of credit", "5-year mortgage rate, q/q change", "1–4", "−", "Calza et al. (2001); Bounajm & McWhirter (2024); Godbout, Su & Xu (2025)"],
  ["Labour market", "Ontario unemployment rate, q/q change", "0–2", "−", "Budnik et al. (2023); Hirtle et al. (CLASS); Pugh, Wang & Webley (2026)"],
], [1900, 2300, 700, 600, 3860]));
c.push(P("The theory versions are: an ARDL on the core; ridge on all core lags; median quantile regression; ARIMAX; factors extracted only from series in literature themes (housing, income, rates, labour, affordability, credit spreads); a random forest on core lags; and an equal-weight combination of the four literature models (classic ARDL, ECM, BEAST, core)."));
c.push(NOTE("Transparency note: the simulated loan data were generated from the same four channels, because the simulation itself was designed from this literature. On simulated data the theory core is therefore not disadvantaged by missing the true drivers; it is the comparison on actual data that will be decisive."));
c.push(H2("7.13 Hybrid data–theory models"));
NEWLIST();
c.push(P("Six hybrids are tested. They span the main ways of combining theory and data used in applied macro-finance:"));
c.push(N("**Theory core + data add-ons.** The literature core is always kept. The data may add up to two drivers from channels the core does not cover, if they are significant, correctly signed and improve out-of-sample error (parsimony rule as in 6.3)."));
c.push(N("**Theory-anchored ridge** (differential shrinkage, in the spirit of Theil & Goldberger's mixed estimation): core coefficients are left unpenalised while all 25 data-shortlist drivers are shrunk."));
c.push(EQ("min_β Σ_t (y_t − x_t'β)^2 + λ Σ_{j ∉ core} β_j^2"));
c.push(N("**Theory long run + data short run** (the LSE / Hendry tradition): the champion's data-chosen short-run drivers plus the literature error-correction term."));
c.push(EQ("y_t = α + ρ·y_{t−1} + λ·u_{t−1} + Σ_{j ∈ champion} β_j·x_{j,t−ℓ_j} + Σ γ_q·D_{q,t} + ε_t"));
c.push(N("**Theory channels, data measures.** Theory fixes the four channels and their signs. The data picks the best-measured series, transform and lag within each channel from the de-duplicated cluster representatives. Channels the data cannot support jointly (|t| < 1) are dropped."));
c.push(N("**50/50 combination** of the data champion and the literature core."));
c.push(N("**Performance-weighted combination** of the champion, the literature core and the ECM. Weights are set at each origin from each member's 4-quarter errors over the previous six years, using only information available at the time (Bates & Granger, 1969), and shrunk halfway toward equal weights because estimated weights are noisy (Smith & Wallis, 2009):"));
c.push(EQ("w_m = ½·(MSE_m^{−1} / Σ_k MSE_k^{−1}) + ½·(1/M)"));
c.push(P("An **unconstrained data-mining** model is run as a reference point. It repeats the selection with no sign priors, no geography or theme filter and no one-per-theme rule, to measure what the theory constraints cost in backtest accuracy and what they buy in explainability."));

c.push(H1("8. Validation framework"));
c.push(H2("8.1 Rolling-origin backtest"));
c.push(P("For each origin T from 2010Q4 to 2025Q3 (expanding window), each model is re-estimated on data up to T, including re-selection of factors, and forecasts are iterated h = 1..9 quarters ahead using the **realised** macro values. This conditional, perfect-foresight-on-macro design isolates model error from scenario error, as is standard for scenario models. The error on the balance level is:"));
c.push(EQ("APE_{T,h} = | exp( Σ_{s=1..h} ŷ_{T+s} − Σ_{s=1..h} y_{T+s} ) − 1 |"));
c.push(P("This is the percentage error of the forecast organic balance. Headline metrics average the APE over origins and horizons, **excluding windows whose target dates fall in 2020Q1–2021Q2**; full-sample metrics are also reported. Mean signed error (bias) is reported too. Models can be compared formally with Diebold-Mariano tests (Diebold & Mariano, 1995)."));
c.push(H2("8.2 Statistical diagnostics (champion and other OLS models)"));
c.push(TABLE(["Test", "Purpose", "Threshold"], [
  ["HAC t-statistics", "Driver significance under autocorrelation and heteroskedasticity", "|t| > 1.96"],
  ["Sign check", "Economic plausibility", "All signs as expected"],
  ["Variance inflation factor", "Multicollinearity", "< 5"],
  ["Ljung-Box (4, 8 lags)", "Residual autocorrelation", "p > 0.05"],
  ["Breusch-Pagan", "Heteroskedasticity", "p > 0.05 (else rely on HAC)"],
  ["Jarque-Bera", "Residual normality (relevant for bootstrap/intervals)", "p > 0.05"],
  ["CUSUM (Brown, Durbin & Evans, 1975)", "Parameter stability", "p > 0.05"],
  ["Recursive coefficients", "Stability across backtest origins", "No sign changes; inside ±2 s.e. band"],
  ["Engle-Granger (ECM only)", "Cointegration of the long-run relation", "p < 0.05"],
], [3000, 4160, 2200]));
c.push(H2("8.3 Encompassing tests"));
c.push(P("To ask whether theory adds information beyond the data model, h-quarter cumulative actual growth A is regressed on the two models' backtest forecasts (Chong & Hendry, 1986; Fair & Shiller, 1990), with HAC standard errors. A significant coefficient means that model carries information the other lacks. The implied optimal combination weight on the data model is estimated from (A − T) = w·(D − T)."));
c.push(EQ("A_{T,h} = a + b_D·D̂_{T,h} + b_T·T̂_{T,h} + e_{T,h}"));
c.push(H2("8.4 Scenario reasonableness"));
c.push(P("Under every model, scenario paths must be ordered severe ≤ downside ≤ baseline ≤ upside. Responses must be of plausible magnitude relative to history, for example the 2008–09 and 2022–23 episodes. A residual-bootstrap fan (1,000 paths) gives 10–90% bands for the champion."));

// 9 Results
c.push(H1("9. Results (simulated data)"));
c.push(NOTE("All figures in this section are from simulated data generated by simulate_data.py. The loan data were generated from house-price growth, income growth, the change in the mortgage rate and the change in the unemployment rate, plus COVID effects and an acquisition in 2014Q3. This makes it possible to check that the procedure recovers true drivers. Re-run on actual data before drawing business conclusions."));
c.push(H2("9.1 Selection funnel"));
c.push(...FIG("02_selection_funnel.png", "Figure 2. From 406 candidate series to the champion's drivers.", 520));
c.push(H2("9.2 Champion model"));
c.push(TABLE(["Term", "Coefficient", "HAC s.e.", "t", "Reading"], [
  ["Constant", "0.0043", "0.0006", "7.04", "Implies steady-state organic growth of about 2.2% a year before driver effects"],
  ["Loan growth, lag 1", "0.207", "0.062", "3.35", "21% of last quarter's growth carries over"],
  ["Toronto single-detached house prices, q/q growth, lag 1", "0.121", "0.012", "9.73", "+1% house-price growth → +0.12 pp loan growth next quarter (long run +0.15 pp)"],
  ["Ontario disposable income, q/q growth, lag 1", "0.277", "0.050", "5.55", "+1% income growth → +0.28 pp next quarter (long run +0.35 pp)"],
], [2900, 1100, 1000, 700, 3660]));
c.push(P("Diagnostics:"));
c.push(B("Adjusted R² = 0.675; maximum VIF = 1.2."));
c.push(B("Ljung-Box p = 0.23 (4 lags) and 0.55 (8 lags); Breusch-Pagan p = 0.57; Jarque-Bera p = 0.96; CUSUM p = 0.28."));
c.push(B("Coefficients are stable across all backtest origins (Figure 6)."));
c.push(P("The house-price and income channels are both drivers used to generate the data. The mortgage-rate and unemployment effects were too weak to be detected in this sample, which is also a typical finding in real data and the reason the REQUIRED_THEMES option exists. Forcing an interest-rate driver raises average error by about 0.1 pp."));
c.push(H2("9.3 Model comparison"));
c.push(TABLE(["Model", "Inputs", "Avg MAPE", "h=1", "h=4", "h=9", "vs AR"], [
  ["Forecast combination (top 10)", "10 models, 11 drivers", "0.55%", "0.22%", "0.46%", "0.90%", "−64%"],
  ["**Champion (data-driven)**", "2 drivers", "**0.61%**", "0.23%", "0.50%", "1.04%", "−59%"],
  ["Elastic Net (post-selection OLS)", "6 drivers", "0.63%", "0.24%", "0.57%", "0.93%", "−58%"],
  ["Champion + deposits (2-eq.)", "2 drivers + deposits", "0.64%", "0.24%", "0.51%", "1.08%", "−58%"],
  ["ARIMAX (champion drivers)", "2 drivers", "0.64%", "0.28%", "0.54%", "1.05%", "−57%"],
  ["Quantile regression (median)", "2 drivers", "0.72%", "0.26%", "0.61%", "1.23%", "−52%"],
  ["Literature ARDL (classic)", "5 drivers", "0.84%", "0.25%", "0.79%", "1.30%", "−44%"],
  ["Ridge (whole shortlist)", "25 drivers", "0.84%", "0.27%", "0.69%", "1.43%", "−44%"],
  ["Literature ECM", "5 drivers + ECM", "0.90%", "0.29%", "0.85%", "1.31%", "−40%"],
  ["Random forest", "25 drivers", "0.95%", "0.28%", "0.79%", "1.63%", "−36%"],
  ["Factor model (Stock-Watson)", "3 factors / 173 series", "1.03%", "0.27%", "0.84%", "1.78%", "−31%"],
  ["Gradient boosting", "25 drivers", "1.04%", "0.28%", "0.83%", "1.87%", "−30%"],
  ["Targeted factors (Bai-Ng)", "2 factors / 101 series", "1.12%", "0.31%", "0.88%", "1.98%", "−25%"],
  ["Literature ARDL (ECB BEAST 2023)", "5 drivers", "1.39%", "0.35%", "1.30%", "2.20%", "−7%"],
  ["AR(1) benchmark", "none", "1.50%", "0.34%", "1.30%", "2.50%", "—"],
], [2800, 1860, 1000, 900, 900, 900, 1000], { size: 17 }));
c.push(NOTE("MAPE = mean absolute % error of the balance level over origins 2010Q4–2025Q3, excluding COVID windows. Avg averages horizons 1–9."));
c.push(...FIG("03_backtest_mape_by_horizon.png", "Figure 3. Backtest ranking (left) and error by horizon for key models (right).", 620));
NEWLIST();
c.push(P("Four observations stand out:"));
c.push(N("Small, explainable models dominate. Ridge, factor and ML models, which use many more inputs, are less accurate at every horizon beyond one quarter."));
c.push(N("The forecast combination is the most accurate and has the smallest bias. It averages ten explainable models with 11 distinct drivers, so it remains interpretable."));
c.push(N("The literature models are respectable. However, the mortgage-rate coefficient in the ARDL takes the wrong sign once GDP and house prices are included, and the long-run real-rate coefficient in the ECM is close to zero ($θ_3$ = 0.001). This illustrates why sign constraints are imposed in the data-driven search."));
c.push(N("The recent BEAST loan-demand specification is weak here (1.39%). Only the overnight-rate change is significant, and the scenarios barely move it: in S4, falling policy rates offset the activity shock. Its missing house-price channel is the likely reason. On real data, re-test it before drawing conclusions, since the simulated loans were generated with a house-price driver."));
c.push(N("Adding deposits does not improve accuracy, so the single-equation champion is preferred unless the deposit linkage is needed for balance-sheet planning."));
c.push(...FIG("04_backtest_paths.png", "Figure 4. Rolling 9-quarter forecast paths against the actual organic balance.", 620));
c.push(H2("9.4 Scenario projections"));
c.push(TABLE(["Model / year-end", "Baseline", "S1 Upside", "S3 Downside", "S4 Severe"], [
  ["Champion 2027Q4", "169,194", "170,924", "165,910", "161,585"],
  ["Champion 2030Q4", "190,228", "193,768", "186,487", "181,687"],
  ["Forecast combination 2027Q4", "168,828", "170,439", "165,684", "161,606"],
  ["Literature ECM 2027Q4", "166,858", "169,506", "161,467", "154,825"],
], [3360, 1500, 1500, 1500, 1500]));
c.push(P("Figures are in millions of dollars; the last actual balance (2025Q4) is about 156.5 billion dollars. Every model orders the scenarios correctly. The champion's 10–90% bootstrap band in 2027Q4 is 166.9–171.5 billion dollars under the baseline and 159.4–163.8 billion under S4. The ECM is the most scenario-sensitive because the error-correction term transmits the persistent level shortfall in GDP and house prices. This is consistent with Bank of Canada evidence of slow, multi-year adjustment of mortgage debt, and it argues for the ECM as a long-horizon cross-check."));
c.push(...FIG("05_scenario_forecasts.png", "Figure 5. Scenario forecasts; champion with residual-bootstrap 10–90% bands.", 620));
c.push(H2("9.5 Explainability"));
c.push(P("Loan growth is decomposed exactly into driver contributions by filtering each term through the AR dynamics: $c_{j,t} = ρ·c_{j,t−1} + β_j·(x_{j,t} − x̄_j)$. The decomposition attributes both the 2017–18 and 2022–23 slowdowns and the 2020–21 surge mainly to house prices, with income adding to growth in 2021 and 2025."));
c.push(...FIG("06_driver_contributions.png", "Figure 6a. Dynamic contributions to loan growth (annualised pp), history and baseline forecast.", 620));
c.push(...FIG("07_coefficient_stability.png", "Figure 6b. Champion coefficients re-estimated at each backtest origin (±2 s.e.).", 600));

// 10 Limitations
c.push(H2("9.6 Data versus theory, and hybrid models"));
c.push(P("**Same model type, different variables.** Average level MAPE over 1–9 quarters, excluding COVID windows:"));
c.push(TABLE(["Model type", "Data variables", "Theory variables", "Difference", "Data h=9", "Theory h=9"], [
  ["Small ARDL", "0.61%", "0.77%", "+0.16", "1.04%", "1.32%"],
  ["Ridge", "0.84%", "0.91%", "+0.07", "1.43%", "1.61%"],
  ["Quantile regression", "0.72%", "0.75%", "+0.03", "1.23%", "1.22%"],
  ["ARIMAX", "0.64%", "0.81%", "+0.17", "1.05%", "1.40%"],
  ["Factor model", "1.03%", "0.94%", "−0.09", "1.78%", "1.52%"],
  ["Random forest", "0.96%", "1.05%", "+0.09", "1.63%", "1.73%"],
  ["Forecast combination", "0.55%", "0.66%", "+0.11", "0.90%", "1.03%"],
], [2160, 1400, 1500, 1300, 1500, 1500]));
c.push(P("Data-chosen variables win in six of seven types. The literature core recovers the two dominant channels (house prices t = 8.4, income t = 5.2), but its mortgage-rate and unemployment terms are insignificant (p = 0.73 and 0.75), and estimating them adds noise to multi-step forecasts. Theory helps the factor model, because restricting the panel to literature themes removes series that only add noise to the factors."));
c.push(P("**From pure data to pure theory:**"));
c.push(TABLE(["Model", "Avg MAPE", "h=1", "h=4", "h=9", "Bias", "Explainability"], [
  ["Unconstrained data mining (no theory)", "0.55%", "0.21%", "0.52%", "0.84%", "−0.42%", "Poor: US and Windsor HPI, Manitoba GDP, Nova Scotia income"],
  ["**Champion** (theory-constrained data)", "**0.61%**", "0.23%", "0.50%", "1.04%", "−0.43%", "Good: Toronto HPI, Ontario income"],
  ["Hybrid: performance-weighted", "0.67%", "0.23%", "0.61%", "1.05%", "−0.46%", "Good (3 explainable members)"],
  ["Hybrid: 50/50 data + theory", "0.68%", "0.23%", "0.56%", "1.18%", "−0.49%", "Good"],
  ["Hybrid: theory long run + data short run", "0.73%", "0.25%", "0.72%", "1.04%", "**−0.30%**", "Very good: adds long-run anchor"],
  ["Hybrid: theory core + data add-ons", "0.77%", "0.23%", "0.65%", "1.32%", "−0.54%", "Very good (no add-on passed: equals core)"],
  ["Hybrid: theory-anchored ridge", "0.79%", "0.23%", "0.67%", "1.36%", "−0.57%", "Moderate (28 shrunk drivers)"],
  ["Hybrid: theory channels, data measures", "0.86%", "0.29%", "0.71%", "1.44%", "−0.58%", "Very good (4 channels)"],
  ["Theory ARDL (literature core)", "0.77%", "0.23%", "0.65%", "1.32%", "−0.54%", "Very good, but 2 insignificant drivers"],
  ["Theory combination (4 literature models)", "0.66%", "0.24%", "0.60%", "1.03%", "−0.45%", "Good"],
], [2700, 900, 700, 700, 700, 800, 2860], { size: 16 }));
c.push(...FIG("08_data_vs_theory.png", "Figure 7. Data versus literature variables by model type (left); the spectrum from pure data to pure theory (right).", 620));
c.push(P("**Encompassing tests** (backtest windows excluding COVID):"));
c.push(TABLE(["Comparison", "Horizon", "Coef. on data (p)", "Coef. on theory (p)", "Optimal weight on data (s.e.)"], [
  ["Champion vs literature core", "1Q", "0.05 (0.84)", "0.83 (0.00)", "0.29 (0.25)"],
  ["Champion vs literature core", "4Q", "1.30 (0.00)", "−0.29 (0.23)", "1.46 (0.33)"],
  ["Champion vs literature core", "8Q", "1.63 (0.00)", "−0.39 (0.19)", "1.43 (0.52)"],
  ["Champion vs literature ECM", "1Q", "0.68 (0.00)", "0.19 (0.26)", "0.91 (0.16)"],
  ["Champion vs literature ECM", "4Q", "1.10 (0.00)", "−0.09 (0.73)", "1.11 (0.19)"],
  ["Champion vs literature ECM", "8Q", "1.01 (0.00)", "0.10 (0.41)", "0.70 (0.15)"],
], [2900, 900, 1800, 1800, 1960]));
c.push(P("Three readings follow:"));
c.push(B("At one quarter the literature core carries the information."));
c.push(B("At 4–8 quarters the data champion encompasses the literature core."));
c.push(B("The ECM is the exception: at eight quarters the optimal weight on theory is about 0.30 and significantly different from zero, so the theory-based long-run relation adds information exactly where the champion is weakest."));
c.push(P("This is consistent with the **theory long run + data short run** hybrid. Its error-correction coefficient is significant (λ = −0.071, t = −2.07), which implies a half-life of a gap to the long-run level of about 9–10 quarters, in line with the roughly five-year adjustment Muellbauer et al. (2015) estimate for Canadian mortgage debt. This hybrid matches the champion at 9 quarters (1.04%) with the smallest bias of any model (−0.30%), and gives a more severe and persistent S4 path (156.9 vs 161.6 billion dollars in 2027Q4)."));
c.push(P("**Recommended balance:**"));
c.push(B("Use theory as **constraints and structure**: channels, signs, geography and the long-run relation."));
c.push(B("Use data for **measurement and selection**: which series, transform and lag; whether a channel is identified at all."));
c.push(B("Combine forecasts where each source is strong: data at short and medium horizons, theory at long horizons and in stress."));
c.push(P("Concretely: the champion for planning; the ECM hybrid for scenarios and stress; and the performance-weighted combination as the standing challenger. Avoid both extremes: unconstrained mining, which picks spurious proxies, and forcing all theory channels when the data cannot identify them."));

c.push(H1("10. Limitations, model risk and governance"));
c.push(B("**Conditional accuracy only.** Backtests use realised macro data. Live forecast error also includes Moody's scenario error, so the reported MAPEs are lower bounds."));
c.push(B("**Small sample.** About 95 quarterly observations with thousands of candidate features creates a multiple-testing risk. Mitigations: sign priors, clustering, theme constraints, out-of-sample ranking, the parsimony rule and the combination challenger."));
c.push(B("**Structural breaks.** Mortgage rules (B-20, 2016/2018 stress tests), product mix (HELOCs), the 2022–23 rate shock and the 2025–26 renewal wave (Godbout, Su & Xu, 2025) can shift coefficients. Monitor recursive coefficients and CUSUM, and consider break dummies when justified."));
c.push(B("**Linearity.** Supply-side contractions near capital thresholds (Hipp & Ojea Ferreiro, 2026) and non-linear loss behaviour (Covas et al.) are not captured. Quantile models and expert overlays are the mitigants in severe scenarios."));
c.push(B("**Rate sensitivity.** If the data cannot identify an interest-rate effect, the model will not respond to rate shocks. Decide whether to force a rate driver (REQUIRED_THEMES) based on the use case."));
c.push(B("**Why not deep learning or Transformers.** With about 95 observations, such models would overfit, extrapolate poorly in stress, and fail explainability requirements under OSFI Guideline E-23 (effective May 2027)."));
c.push(H2("Ongoing monitoring"));
c.push(B("Track quarterly actual-versus-forecast error against the backtest distribution. Trigger a review if errors exceed the 90th percentile for two consecutive quarters."));
c.push(B("Re-estimate coefficients each quarter, and re-run the full selection annually or after a structural event."));
c.push(B("Run the champion and the combination challenger in parallel, and investigate divergences of more than 1%."));

// 11 References
c.push(H1("References"));
const refs = [
  ["Al-Mqbali, L., Bilyk, O., Caputo, S., & Younker, J. (2019). Reassessing the Growth of HELOCs in Canada Using New Regulatory Data. Bank of Canada Staff Analytical Note 2019-14.", "https://econpapers.repec.org/paper/bcabocsan/19-14.htm"],
  ["Bai, J., & Ng, S. (2008). Forecasting economic time series using targeted predictors. Journal of Econometrics, 146(2), 304–317.", "https://ideas.repec.org/a/eee/econom/v146y2008i2p304-317.html"],
  ["Bailliu, J., Kartashova, K., & Meh, C. (2012). Household Borrowing and Spending in Canada. Bank of Canada Review, Winter 2011–2012, 16–29.", "https://www.bankofcanada.ca/wp-content/uploads/2012/02/boc-review-winter11-12-bailliu.pdf"],
  ["Bates, J. M., & Granger, C. W. J. (1969). The combination of forecasts. Operational Research Quarterly, 20(4), 451–468.", null],
  ["Bernanke, B. S., & Blinder, A. S. (1988). Credit, money, and aggregate demand. American Economic Review, 78(2), 435–439.", null],
  ["Bernanke, B. S., & Gertler, M. (1995). Inside the black box: The credit channel of monetary policy transmission. Journal of Economic Perspectives, 9(4), 27–48.", null],
  ["Bounajm, F., & McWhirter, A. (2024). Modelling Canadian mortgage debt and payments in a semi-structural model. Bank of Canada Staff Analytical Note 2024-1.", "https://www.bankofcanada.ca/wp-content/uploads/2024/01/san2024-1.pdf"],
  ["Bluwstein, K., Buckmann, M., Joseph, A., Kapadia, S., & Şimşek, Ö. (2023). Credit growth, the yield curve and financial crisis prediction: Evidence from a machine learning approach. Journal of International Economics.", "https://academicnewsletter.sufe.edu.cn/info/297158"],
  ["Breiman, L. (2001). Random forests. Machine Learning, 45, 5–32.", null],
  ["Brown, R. L., Durbin, J., & Evans, J. M. (1975). Techniques for testing the constancy of regression relationships over time. Journal of the Royal Statistical Society B, 37(2), 149–192.", null],
  ["Budnik, K., et al. (2023). BEAST: A model for the assessment of system-wide risks and macroprudential policies. ECB Working Paper 2855.", "https://www.ecb.europa.eu/pub/pdf/scpwps/ecb.wp2855~1d1d269af4.en.pdf"],
  ["Calza, A., Gartner, C., & Sousa, J. (2001). Modelling the demand for loans to the private sector in the euro area. ECB Working Paper 55; Applied Economics (2003), 35, 107–117.", "https://ecb.europa.eu/pub/pdf/scpwps/ecbwp055.pdf"],
  ["Calza, A., Manrique, M., & Sousa, J. (2003). Aggregate loans to the euro area private sector. ECB Working Paper 202.", "https://ECB.eu/pub/pdf/scpwps/ecbwp202.pdf"],
  ["Cheung, C., & Demers, F. (2007). Evaluating Forecasts from Factor Models for Canadian GDP Growth and Core Inflation. Bank of Canada Staff Working Paper 2007-8.", "https://econpapers.repec.org/paper/bcabocawp/07-8.htm"],
  ["Chernis, T., & Sekkel, R. (2017). A Dynamic Factor Model for Nowcasting Canadian GDP Growth. Bank of Canada Staff Working Paper 2017-2.", "https://www.bankofcanada.ca/2017/02/staff-working-paper-2017-2/"],
  ["Chong, Y. Y., & Hendry, D. F. (1986). Econometric evaluation of linear macro-economic models. Review of Economic Studies, 53(4), 671–690.", null],
  ["Christensen, I., Corrigan, P., Mendicino, C., & Nishiyama, S.-I. (2009). Consumption, Housing Collateral, and the Canadian Business Cycle. Bank of Canada Staff Working Paper 2009-26.", "https://econpapers.repec.org/paper/bcabocawp/09-26.htm"],
  ["Covas, F. B., Rump, B., & Zakrajšek, E. (2013). Stress-Testing U.S. Bank Holding Companies: A Dynamic Panel Quantile Regression Approach. Finance and Economics Discussion Series 2013-55, Federal Reserve Board.", "https://www.federalreserve.gov/econres/feds/stress-testing-us-bank-holding-companies-a-dynamic-panel-quantile-regression-approach.htm"],
  ["Diebold, F. X., & Mariano, R. S. (1995). Comparing predictive accuracy. Journal of Business & Economic Statistics, 13(3), 253–263.", null],
  ["Duttagupta, R., & Barrera, N. (2010). The Impact of the Global Crisis on Canada—What Do Macro-Financial Linkages Tell Us? IMF Working Paper 10/5.", "https://www.imf.org/en/publications/wp/issues/2016/12/31/the-impact-of-the-global-crisis-on-canada-what-do-macro-financial-linkages-tell-us-23483"],
  ["Engle, R. F., & Granger, C. W. J. (1987). Co-integration and error correction: Representation, estimation, and testing. Econometrica, 55(2), 251–276.", null],
  ["Fair, R. C., & Shiller, R. J. (1990). Comparing information in forecasts from econometric models. American Economic Review, 80(3), 375–389.", null],
  ["Federal Reserve Board (2017). Dodd-Frank Act Stress Test: Supervisory Stress Test Framework and Model Methodology.", "https://www.federalreserve.gov/publications/2017-june-dodd-frank-act-stress-test-supervisory-stress-test-framework-and-model-methodology.htm"],
  ["Federal Reserve Board (2025). Supervisory Stress Test Methodology (June 2025).", "https://www.federalreserve.gov/publications/files/2025-june-supervisory-stress-test-methodology.pdf"],
  ["Fique, J. (2017). The MacroFinancial Risk Assessment Framework (MFRAF), Version 2.0. Bank of Canada Technical Report 111.", "https://www.bankofcanada.ca/2017/09/technical-report-111/"],
  ["Fortin-Gagnon, O., Leroux, M., Stevanovic, D., & Surprenant, S. (2022). A large Canadian database for macroeconomic analysis. Canadian Journal of Economics, 55(4), 1799–1833.", "https://ideas.repec.org/p/cir/cirwor/2018s-25.html"],
  ["Friedman, J. H. (2001). Greedy function approximation: A gradient boosting machine. Annals of Statistics, 29(5), 1189–1232.", null],
  ["Giannone, D., Lenza, M., & Primiceri, G. E. (2021). Economic predictions with big data: The illusion of sparsity. Econometrica, 89(5), 2409–2437.", "https://www.econometricsociety.org/publications/econometrica/2021/09/01/economic-predictions-big-data-illusion-sparsity"],
  ["Godbout, C., Su, A., & Xu, Y. (2025). How will mortgage payments change at renewal? An updated analysis. Bank of Canada Staff Analytical Note 2025-21.", "https://www.bankofcanada.ca/2025/07/staff-analytical-note-2025-21/"],
  ["Goulet Coulombe, P., Leroux, M., Stevanovic, D., & Surprenant, S. (2022). How is machine learning useful for macroeconomic forecasting? Journal of Applied Econometrics, 37(5), 920–964.", "https://ideas.repec.org/a/wly/japmet/v37y2022i5p920-964.html"],
  ["Guo, K., & Stepanyan, V. (2011). Determinants of Bank Credit in Emerging Market Economies. IMF Working Paper 11/51.", "https://ideas.repec.org/p/imf/imfwpa/2011-051.html"],
  ["Hartley, J., & Paixão, N. (2024). Mortgage stress tests and household financial resilience under monetary policy tightening. Bank of Canada Staff Analytical Note 2024-25.", "https://www.bankofcanada.ca/2024/11/staff-analytical-note-2024-25/"],
  ["Hendry, D. F. (1995). Dynamic Econometrics. Oxford University Press.", null],
  ["Hipp, R., & Ojea Ferreiro, J. (2026). From Stress to Strategy: How Banks Balance the Scales. Bank of Canada Staff Working Paper 2026-26.", "https://www.bankofcanada.ca/2026/07/staff-working-paper-2026-26/"],
  ["Hirtle, B., Kovner, A., Vickery, J., & Bhanot, M. (2014, rev. 2015). Assessing Financial Stability: The Capital and Loss Assessment under Stress Scenarios (CLASS) Model. Federal Reserve Bank of New York Staff Report 663.", "https://www.newyorkfed.org/medialibrary/media/research/staff_reports/sr663.pdf"],
  ["Hoerl, A. E., & Kennard, R. W. (1970). Ridge regression: Biased estimation for nonorthogonal problems. Technometrics, 12(1), 55–67.", null],
  ["Hofmann, B. (2001). The determinants of private sector credit in industrialised countries: do property prices matter? BIS Working Paper 108.", "https://www.bis.org/publ/work108.htm"],
  ["Hofmann, B. (2004). The Determinants of Bank Credit in Industrialized Countries: Do Property Prices Matter? International Finance, 7(2), 203–234.", "https://ideas.repec.org/a/bla/intfin/v7y2004i2p203-234.html"],
  ["International Monetary Fund (2025). Canada: Financial Sector Assessment Program — Technical Note on Stress Testing.", "https://meetings.imf.org/-/media/Files/Publications/CR/2025/English/1canea2025008-source-pdf.ashx"],
  ["Kapinos, P., & Mitnik, O. A. (2016). A Top-down Approach to Stress-testing Banks. Journal of Financial Services Research, 49(2) (FDIC CFR Working Paper 2015-02).", "https://www.fdic.gov/analysis/cfr/working-papers/2015/2015-02.pdf"],
  ["Kashyap, A. K., & Stein, J. C. (2000). What do a million observations on banks say about the transmission of monetary policy? American Economic Review, 90(3), 407–428.", null],
  ["Kiyotaki, N., & Moore, J. (1997). Credit cycles. Journal of Political Economy, 105(2), 211–248.", null],
  ["Koenker, R., & Bassett, G. (1978). Regression quantiles. Econometrica, 46(1), 33–50.", null],
  ["Krznar, I., & Morsink, J. (2014). With Great Power Comes Great Responsibility: Macroprudential Tools at Work in Canada. IMF Working Paper 14/83.", "https://ideas.repec.org/p/imf/imfwpa/2014-083.html"],
  ["MacGee, J., & Yao, Y. (2026). Housing and the Long-Term Real Effects of Changes in Trend Inflation. Bank of Canada Staff Working Paper 2026-1.", "https://www.bankofcanada.ca/wp-content/uploads/2026/02/swp2026-1.pdf"],
  ["Makridakis, S., Spiliotis, E., & Assimakopoulos, V. (2018). Statistical and Machine Learning forecasting methods: Concerns and ways forward. PLoS ONE, 13(3), e0194889.", null],
  ["Moody's Analytics. Forecast: Canada Subnational With Alternative Scenarios (product description).", "https://www.economy.com/products/data/forecast-canada-subnational"],
  ["Muellbauer, J., St-Amant, P., & Williams, D. (2015). Credit Conditions and Consumption, House Prices and Debt: What Makes Canada Different? Bank of Canada Staff Working Paper 2015-40.", "https://www.bankofcanada.ca/wp-content/uploads/2015/11/wp2015-40.pdf"],
  ["Newey, W. K., & West, K. D. (1987). A simple, positive semi-definite, heteroskedasticity and autocorrelation consistent covariance matrix. Econometrica, 55(3), 703–708.", null],
  ["Pesaran, M. H., Shin, Y., & Smith, R. J. (2001). Bounds testing approaches to the analysis of level relationships. Journal of Applied Econometrics, 16(3), 289–326.", null],
  ["Office of the Superintendent of Financial Institutions (2025). Guideline E-23: Model Risk Management (published September 2025; effective May 1, 2027).", "https://www.mondaq.com/canada/new-technology/1689734/model-risk-management-for-federally-regulated-financial-institutions"],
  ["Peterson, B., & Roberts, T. (2016). Household Risk Assessment Model. Bank of Canada Technical Report 106.", "https://www.bankofcanada.ca/2016/09/technical-report-106/"],
  ["Pugh, T. M., Wang, T., & Webley, T. (2026). Examining the Macro Drivers of Mortgage Arrears in Canada. Bank of Canada Staff Analytical Paper 2026-12.", "https://econpapers.repec.org/RePEc:bca:bocsap:26-12"],
  ["Smith, J., & Wallis, K. F. (2009). A simple explanation of the forecast combination puzzle. Oxford Bulletin of Economics and Statistics, 71(3), 331–355.", null],
  ["Stock, J. H., & Watson, M. W. (2002). Macroeconomic forecasting using diffusion indexes. Journal of Business & Economic Statistics, 20(2), 147–162.", "https://scholar.harvard.edu/sites/scholar.harvard.edu/files/stock/files/macroeconomic_forecasting_using_diffusion_indexes.pdf"],
  ["Stock, J. H., & Watson, M. W. (2004). Combination forecasts of output growth in a seven-country data set. Journal of Forecasting, 23(6), 405–430.", "https://ideas.repec.org/a/jof/jforec/v23y2004i6p405-430.html"],
  ["Theil, H., & Goldberger, A. S. (1961). On pure and mixed statistical estimation in economics. International Economic Review, 2(1), 65–78.", null],
  ["Tibshirani, R. (1996). Regression shrinkage and selection via the lasso. Journal of the Royal Statistical Society B, 58(1), 267–288.", null],
  ["Vaswani, A., et al. (2017). Attention is all you need. Advances in Neural Information Processing Systems 30.", null],
  ["Zou, H., & Hastie, T. (2005). Regularization and variable selection via the elastic net. Journal of the Royal Statistical Society B, 67(2), 301–320.", null],
];
for (const [t, url] of refs) {
  const ch = [new TextRun({ text: t + (url ? " " : ""), size: 19 })];
  if (url) ch.push(new ExternalHyperlink({ link: url, children: [new TextRun({ text: "Link", style: "Hyperlink", size: 19 })] }));
  c.push(new Paragraph({ children: ch, spacing: { after: 90 }, indent: { left: 360, hanging: 360 } }));
}

// Appendix
c.push(H1("Appendix A. Key configuration parameters"));
c.push(TABLE(["Parameter", "Default", "Meaning"], [
  ["ESTIMATION_START / HIST_END", "2002Q2 / 2025Q4", "Estimation sample"],
  ["BACKTEST_START, HORIZON", "2010Q4, 9", "First origin; quarters ahead"],
  ["MAX_LAG", "4", "Lags tried per transform"],
  ["TRANSFORMS_LEVEL / _RATE", "dlog, yoy, dlog2, acc, gap / diff, diff2, diff4, lvl, rgap", "Transform menu (Section 5)"],
  ["ALLOWED_GEOGRAPHIES / EXCLUDED_THEMES", "Ontario, Canada / Other, industry detail", "Relevance filter"],
  ["SCREEN_P, REQUIRE_SIGN_PRIOR", "0.05, True", "Screen significance; sign prior required"],
  ["CLUSTER_CORR, REP_TOLERANCE", "0.75, 0.75", "Redundancy threshold; Ontario preference"],
  ["MIN_VARS / MAX_VARS, T_MIN, VIF_MAX", "2 / 4, 1.96, 5", "Constrained search"],
  ["ONE_PER_THEME, REQUIRED_THEMES", "True, []", "Theme constraints"],
  ["N_OOS_CANDIDATES, SELECTION_TOLERANCE", "300, 5%", "Out-of-sample race; parsimony rule"],
  ["N_FACTORS, N_TARGETED_FACTORS, N_COMBINE", "3, 2, 10", "Alternative models"],
  ["DUMMIES, COVID_WINDOW", "2020Q1–2021Q2", "Special-period treatment"],
  ["LITERATURE_CORE, THEORY_THEMES", "4 channels; 6 themes", "Theory models and hybrids (Section 7.12–7.13)"],
  ["RUN_UNCONSTRAINED", "True", "Run the no-theory reference model"],
], [3400, 3160, 2800]));

// ---------- document ----------
const doc = new Document({
  creator: "Model Development",
  title: "Ontario Loan Balance Forecasting Model — Methodology and Literature Review",
  styles: {
    default: { document: { run: { font: FONT, size: 21 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 32, bold: true, font: FONT, color: C_HEAD }, paragraph: { spacing: { before: 240, after: 160 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 26, bold: true, font: FONT, color: C_HEAD }, paragraph: { spacing: { before: 220, after: 100 }, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 22, bold: true, font: FONT }, paragraph: { spacing: { before: 160, after: 80 }, outlineLevel: 2 } },
    ],
  },
  numbering: { config: [
    { reference: "bul", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
      style: { paragraph: { indent: { left: 540, hanging: 270 } } } },
      { level: 1, format: LevelFormat.BULLET, text: "–", alignment: AlignmentType.LEFT,
      style: { paragraph: { indent: { left: 1080, hanging: 270 } } } }] },
    { reference: "num", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
      style: { paragraph: { indent: { left: 540, hanging: 300 } } } }] },
  ] },
  features: { updateFields: true },
  sections: [{
    properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.RIGHT,
      children: [new TextRun({ text: "Ontario Loan Forecasting Model — Methodology   |   Page ", size: 16, color: C_MUTED }),
        new TextRun({ children: [PageNumber.CURRENT], size: 16, color: C_MUTED })] })] }) },
    children: c,
  }],
});
Packer.toBuffer(doc).then((buf) => {
  const out = path.join(__dirname, "..", "Methodology_and_Literature_Review.docx");
  fs.writeFileSync(out, buf);
  console.log("written", out);
});
