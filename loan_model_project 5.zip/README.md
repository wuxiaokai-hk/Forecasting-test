# Loan balance forecasting model

Selects a small set of macro drivers (at most 3 by default) for a loan balance, using two approaches side by side, then backtests, diagnoses and forecasts each one under every scenario.

- **Approach A, screen first:** test every candidate one at a time, cluster near-duplicates, keep one per cluster, then search.
- **Approach B, Elastic Net first:** run an Elastic Net on all candidates (with optional stability selection), group correlated picks, keep one per group, then search.

Both approaches finish with the same final step, so their results are directly comparable.

Their models then compete with benchmarks, models from published studies, hybrids of theory and data, machine-learning models and AI foundation models: about 20 models, all tested the same way 4, 8 and 12 quarters ahead (see **Competing models** below). A Quarto file builds the presentation deck from the results (`report/`).

## Run

```
python run_pipeline.py                                    # example data and config
python run_pipeline.py --config config/my_portfolio.yaml  # your data
python run_pipeline.py --config config/my_portfolio.yaml --approach en_first   # one approach only
```

Missing Python packages are installed automatically the first time. A full run takes about a minute (the machine-learning models take most of it); re-runs with nothing changed take seconds.

## The app (`streamlit run app.py`)

A point-and-click front end for everything above. It runs on your computer and opens in your browser; nothing leaves your machine.

```
pip install streamlit
streamlit run app.py
```

| Tab | What you do |
|---|---|
| ① Files | Upload the loan balance, the scenario files, the **literature workbook (required; a filled-in template can be downloaded here)**, the metadata (recommended) and the events (optional). The app reads them and proposes every setting |
| ② Data settings | **The dependent variable**: pick the balance column, with charts of its level and quarterly growth. Then the scenario names and the baseline, the metadata column mapping, the geographies and themes, the deflator, which of your series stands for each literature concept, and the published models to compare with their expected signs (the workbook's models sheet, editable: add or delete rows) and the literature settings (error-correction model, channels, regime threshold) |
| ③ Sample and models | Dates (estimation start, backtest window, out-of-sample origins, one-off quarters), **the transforms tried for each candidate (level forms, rate forms), the maximum lag and the ADF threshold**, the horizon and re-estimation schedule, the selection rules (most drivers, smallest \|t\|, VIF), and which model families compete |
| ④ Check and run | Save the configuration (`config/<name>.yaml`), see the pre-flight check, run the pipeline or the out-of-sample test with a live log |
| ⑤ Results | The out-of-sample ranking (the one to use) and the backtest, the charts, **a detail page for every model**, downloads (the Excel tables, the summary and the run trace with its data story), and **the presentation**: one button builds the styled PowerPoint deck for this run (title and region editable) and offers it for download |

**The model detail page** (⑤, pick a model):
- What the model is, its source and drivers.
- Its driver table, which depends on the model type:
  - regressions (ARDL, ECM, ARIMAX): coefficients with HAC standard errors, t, p and a plain-language reading, including long-run effects;
  - random forest and gradient boosting: importance;
  - TFT: the weight its variable-selection networks give each input, looking back and looking ahead;
  - combinations: member weights;
  - regime models: the coefficients in each regime.
- Two scenario-effect columns for every model, the networks included: how much the driver's baseline path moves growth (pp a year) and the balance after 8 quarters (%), compared with holding the driver at its last actual value. This makes black-box and regression models comparable.
- The residual checks, the balance error by horizon (backtest against out of sample), the forecast under each scenario, the coefficients at each backtest re-estimation (a stability check), the regime history, and the drivers chosen at each out-of-sample origin. The same tables are in `comparison/3_drivers.csv` and its neighbours.

"Existing configuration" in the sidebar opens a config you already have, to run it, see its results, or edit any setting in the file directly. Whatever the app saves is an ordinary config file, so `python run_pipeline.py --config config/<name>.yaml` repeats the same run from the command line. The deep-learning and foundation models are off by default in the app (they add several minutes and need extra packages): tick them in ③.

## Using a new data set (`tools/new_data_setup.py`, `tools/check_config.py`)

No code changes are needed. One command writes the config from your files:

```
python tools/new_data_setup.py --name my_portfolio --bank data/my/loans.xlsx \
    --macro-dir data/my/scenarios --metadata data/my/metadata.csv --fast
```

It finds the date and balance columns, takes the scenario names from the file names, and matches your metadata headers to the six fields the model needs. Missing metadata fields (transform, theme, expected sign) are filled with suggestions in `data/<name>_metadata_draft.csv`. It maps the literature concepts to your series by keywords (keeping any series your workbook already names; `--literature my_workbook.xlsx`, otherwise the example's) into `config/<name>_literature.xlsx`, sets every date from the data, and writes `config/<name>.yaml` with the example's comments kept. Review the metadata draft and the workbook it names, then run.

`python tools/check_config.py --config config/<name>.yaml` checks names, files and dates in a few seconds and prints a fix for each problem. The same check runs at the start of `run_pipeline.py` and `run_oos.py` and stops on errors (`--skip-check` overrides it).

The guide "Running the Loan Model on a New Dataset" covers the details: the file formats, every setting that depends on the data, the date rules and the check's messages.

## Using your own files: only the config changes

Copy `config/example_config.yaml`, rename it, and edit it. Everything that depends on a data set lives there:

| What | Where in the config |
|---|---|
| Bank file, sheet, date column, balance column, monthly or quarterly | `data.bank` |
| Inorganic events file and its columns (optional) | `data.events` |
| One Moody's file per scenario, any names, plus the date column | `data.macro.scenarios`, `data.macro.date_column` |
| Metadata file and **your** column names for mnemonic, description, geography, theme, transform, expected sign | `data.metadata.columns` |
| Extra variables built from macro columns (spreads, real rates) | `data.constructed` |
| Dates: last actual quarter, estimation start, backtest start, dummy quarters | `sample` |
| Selection settings for each approach and the final model | `features`, `screen_first`, `en_first`, `final_model` |

A few details on the inputs:

- Files can be `.csv` or `.xlsx`; give `sheet:` for Excel.
- Dates can be quarter labels (`2020Q1`) or real dates (`2020-03-31`).
- Monthly balances are converted to quarter-end values.
- `run_name` sets the output folder, so runs on different portfolios never overwrite each other.

## Skipping unchanged steps (hash-based cache)

Each step gets a fingerprint, a SHA-256 hash, built from everything it depends on:

| Step | Its fingerprint includes |
|---|---|
| `data` | the loaded values of the target, balance, metadata, macro history and every scenario |
| `features` | macro history, metadata, the `features` and `sample` settings, the code in `features/` |
| `screen_first` / `en_first` | the `features` fingerprint, the target, that approach's settings, `final_model`, `sample`, its code |
| `evaluate:<model>` | the chosen drivers, the target, the scenarios, `sample`, the evaluation code |

If a step's fingerprint matches a result already in the cache, the result is loaded instead of recomputed. A full rerun with nothing changed takes about 4 seconds instead of 30. Some examples from testing:

- **New scenario path only:** only the `evaluate` steps re-run.
- **One revised history value:** everything downstream re-runs.
- **Settings change that leaves the drivers the same:** the evaluation is reused, because it depends on the drivers, not on how they were found.
- **Same values under new file or column names:** everything is loaded from the cache. Data are hashed by value, not by file name.
- **Edited code:** only the steps that use that code re-run.

Each run writes `outputs/<run_name>/run_manifest.json` and appends to `run_history.csv`. These record, for every step, whether it was cached or computed and which inputs changed since the previous run, for example `changed: config.en_first` or `changed: scenarios`.

Options:

```
python run_pipeline.py --force                      # recompute everything
python run_pipeline.py --force-step en_first        # recompute one step (also: features, screen_first, evaluate)
python run_pipeline.py --no-cache                   # neither read nor write the cache
```

The cache lives in `cache/` (set by `cache.dir` in the config) and is shared by all configs. Delete the folder to clear it.

## Backtest window and re-estimation schedule

All set in `sample:` in the config. They apply to the rolling backtest in `comparison/` and to the backtest the final search uses to rank driver combinations, so selection and evaluation stay consistent.

| Setting | Default | What it does |
|---|---|---|
| `backtest_start` | 2018Q1 | First forecast origin |
| `backtest_end` | 2024Q4 | Last forecast origin (null = the last quarter with an actual after it) |
| `backtest_step` | 1 | Quarters between origins: 2 = every other quarter |
| `reestimate_every` | 4 | Quarters between re-estimations. 4 = once a year: the coefficients are estimated at the first origin of each year and kept for the next three quarters, and only the forecast is redone from the latest actual data, as in production |
| `reestimate_quarter` | 1 | With `reestimate_every: 4`, the quarter in which the yearly re-estimation happens |

**A short window.** The default window 2018Q1–2024Q4 has 28 origins, but the COVID quarters (2020Q1–2021Q2) are left out of the error metrics, and with data to 2025Q4 only origins up to 2022Q4 have a 12-quarter-ahead actual. So the 12-quarter errors rest on about 7 origins (22 at 1 quarter, 19 at 4, 11 at 8). The ranking of driver combinations uses the same window, so the chosen drivers can differ from a longer window. For a more robust ranking, widen it (`backtest_start: 2010Q4`, `backtest_end: null`).

Every estimation uses data up to its own origin only. Machine-learning models are re-estimated at least every 4 quarters (`refit_every`) to save time; this is aligned to the same calendar.

On the example data, with the earlier window 2010Q4–2022Q4 (average error over 1–12 quarters):

| Schedule | Origins | Re-estimations | Run time | AR(1) | Screen first | EN first | Hybrid: theory long run + data short run |
|---|---|---|---|---|---|---|---|
| Every quarter, re-estimate each | 60 | 60 | 79 s | 1.87% | 0.71% | 0.93% | 0.83% |
| Every 2nd quarter | 30 | 30 | 64 s | 1.90% | 0.72% | 0.92% | 0.83% |
| Every quarter, re-estimate yearly | 60 | 16 | 65 s | 1.89% | 0.70% | 0.95% | 0.88% |
| Every 2nd quarter, re-estimate yearly | 30 | 16 | 55 s | 1.89% | 0.77% | 0.92% | 0.81% |

Yearly re-estimation costs little accuracy. The run-time saving is modest because driver selection, not the backtest, takes most of the time. With every 2nd quarter and yearly re-estimation, screen first chooses Toronto single-detached prices and income instead of mortgage credit, income and permits.

The out-of-sample test has its own spacing: `oos.first_origin` and `oos.step` (default every 4 quarters).

## Out-of-sample test (`python run_oos.py`)

The backtest in the main pipeline re-estimates the coefficients at every origin, but it chooses the drivers once using all the data. That makes it optimistic. `run_oos.py` runs a true out-of-sample test instead:

1. **Re-select at every origin.** At each forecast origin (every `oos.step` quarters from `oos.first_origin`), the whole selection is re-run with data up to that origin only: stationarity tests, candidate features, both approaches, the final search, the hybrid searches and the construction of every competing model.
2. **Forecast.** Every model forecasts the next 1–12 quarters (`sample.horizon`), using realised macro values.
3. **Compare** against:
   - the same approach with the drivers chosen on the full sample (shows how much the full-sample backtest flatters the model);
   - the AR(1) benchmark.
4. **Report.** Outputs go to `outputs/<run_name>/oos/`:
   - MAPE, RMSE, bias and Theil's U against the benchmark, by horizon;
   - Diebold-Mariano tests against the benchmark, with the small-sample correction;
   - the drivers chosen at each origin, how often each driver was chosen, and the average overlap between consecutive origins;
   - a holdout: select and estimate on data up to `hist_end - holdout_quarters`, then forecast the held-out quarters.

Set `oos.window: rolling` (with `window_length`) for a fixed-length estimation window instead of an expanding one.

Each origin's selection is cached, so the first run takes a few minutes (about 4 minutes for 12 origins on the example data) and re-runs take seconds. `step: 1` gives more origins and more powerful tests, but takes about four times longer the first time.

Results on the example (simulated) data are in **Example results** below. The look-ahead check for the two data-driven approaches (average balance error, 1–12 quarters):

| Approach | Re-selected at each origin | Drivers fixed from the full sample |
|---|---|---|
| Screen first | 1.37% | 0.72% |
| Elastic Net first | 1.61% | 1.05% |

Elastic Net first chose more stable drivers across origins (average overlap with the previous origin 0.59, against 0.18 for screen first).

## Competing models (`src/models/`)

After the two approaches have chosen their drivers, `src/models/zoo.py` builds every competing model. All of them use the same information (the macro history, and the scenario path in scenario forecasts), the same rolling backtest and the same out-of-sample test.

| Family | Models | How they are specified |
|---|---|---|
| Benchmark | AR(1); mean growth | Loan growth on its own lag; average growth (a random walk with drift in the balance) |
| Data-driven | Screen first; Elastic Net first | The two selection approaches |
| Literature | Classic ARDL (Hofmann; Calza et al.); ECB BEAST loan demand (Budnik et al. 2023); four-channel core (house prices, income, mortgage rate, unemployment); error-correction model | Fixed specifications from published studies, in the literature workbook |
| Hybrid | Theory core + data add-ons; theory long run + data short run; theory channels, data measures; 50/50 data + theory; performance-weighted | Theory sets the structure and data fills it in, or both are averaged |
| Machine learning | Ridge; random forest; gradient boosting; neural network (5 small nets, averaged) | Lagged growth, dummies and the pooled drivers (literature core + data-chosen); forecasts iterated with the macro path |
| Regime switching | Markov switching (Hamilton); threshold ARDL; smooth transition (LSTAR); time-varying parameters (Kalman); break-adaptive ARDL | The literature core drivers, with relations that change with the state of the economy (see below) |
| Statistical time series | ARIMAX (literature core drivers with ARMA(1,1) errors); Theta (M3 winner, own history) | statsmodels; coefficients kept between re-estimations |
| Deep learning | TiDE (Google, 2023); N-HiTS (2023); TFT, temporal fusion transformer (2021); optional N-BEATS, TSMixer | Small networks trained on this data (darts), average of several random seeds; TiDE and TFT take the drivers' scenario paths as known future inputs |
| AI foundation model | Chronos-Bolt (own history); Chronos-2 (with the literature drivers and their scenario paths) | Pretrained, zero-shot |

**Keeping the run time down.** Machine-learning hyperparameters are fixed (no tuning loop), and in the rolling backtest these models are re-estimated every 4th origin (`refit_every`), always with data up to that origin only. Foundation models take under a second per forecast. On the example data the 17 models without foundation models take about a minute; the out-of-sample test with re-selection takes about 5 minutes the first time and is cached after that.

**Regime-switching models (`src/models/regime.py`).** All five use the four literature core drivers. Their only difference from "Literature: four-channel core" is that the relation is allowed to change, so the comparison shows directly whether regimes help.

| Model | How the regime is set | In scenarios |
|---|---|---|
| Markov switching (Hamilton 1989) | Two unobserved regimes with low and high mean growth. The regime probability is inferred from the data and carried forward with the estimated transition matrix | The drivers respond to the scenario; the regime probability evolves on its own |
| Threshold ARDL (Hansen 2000) | Every coefficient differs below and above an estimated threshold of the regime variable (default: house price growth, `models.regime.threshold`) | The scenario's house price path decides the regime in each future quarter |
| Smooth transition, LSTAR (Teräsvirta 1994) | As the threshold model, but the switch is gradual (a logistic weight) | Same |
| Time-varying parameters | Every coefficient drifts slowly as a random walk (Kalman filter); the speed of drift is estimated, and 0 means no drift | Latest coefficients |
| Break-adaptive ARDL (Andrews 1993) | Tests for a structural break (sup-F) at each re-estimation and, if one is significant, estimates only on the data after it | Post-break coefficients |

- `comparison/3_drivers.csv` shows each model's regimes: the threshold and the share of quarters in each regime, the regime means and expected durations, how the coefficients drifted, and the break date.
- `comparison/11_regimes.csv` and `regimes.png` show the regime indicator over history.
- The Markov model is estimated with growth in percent and standardised inputs, because the likelihood search needs this with about 100 quarters. Each regime having its own volatility is off by default: with this little data, one regime tends to collapse onto a few outliers. Turn it on with `settings: {markov: {switching_variance: true}}`.
- If the likelihood search fails, the model falls back to one regime and the driver table says so.
- On the simulated data, which was generated without regimes, the tests find weak evidence for them, as they should. Real Ontario data, with the 2017 mortgage stress test and the 2022 rate shock, is where they can show their value.

**Deep-learning models need `pip install darts`** (it installs PyTorch, about 1 GB, more on Linux with GPU libraries). Without it they are skipped with a message. They are deliberately small, because there are only about 100 quarters to learn from: 1 hidden layer of 16–32 units, 8 quarters of input, 4 quarters predicted per step (the 12-quarter path is built by repeating that), 80 training epochs, refitted once a year. Settings are in `models.deep.settings`, with per-model overrides (TFT uses 2 seeds and 50 epochs because it is the slowest). Approximate run time on 4 CPU cores for the rolling backtest plus scenarios: N-HiTS 50 s, TiDE 80 s, TFT 4 min.

**Foundation models need two extra things.** First, `pip install chronos-forecasting`, which also installs PyTorch. Second, the weights must be downloaded from Hugging Face on first use: about 190 MB for chronos-bolt-small and about 480 MB for chronos-2. Without them the two models are skipped with a message, and everything else runs as usual. Offline, download the model folders once and put their paths in `models.foundation.models[].id`. Their code was tested here with small randomly initialised networks, because Hugging Face could not be reached from the test environment; their accuracy has not been measured yet.

**Comparing models at 4, 8 and 12 quarters.** `sample.horizon: 12` sets the forecast length; `sample.report_horizons: [4, 8, 12]` sets the comparison points. For each model, `comparison/1_model_comparison.csv` and `oos/1_oos_summary.csv` give:

- `avg_1_h_pct`: the average balance error over 1..h quarters;
- `at_hq_pct`: the error at exactly h quarters;
- `vs_AR_1_h_pct`: the improvement on AR(1);
- the rank over 1–12 quarters.

The drivers of the data-driven approaches are ranked over the full 12 quarters.

Other outputs in `comparison/`:
- `model_comparison.png`: all models side by side at 4, 8 and 12 quarters, coloured by family;
- `9_model_list.csv`: what each model is, its drivers and its sources;
- `10_hybrid_*.csv`: the hybrid searches.

To switch families on or off, or change settings, edit the `models:` section of the config.

## Literature workbook (`config/literature_workbook.xlsx`)

Everything about the literature lives in one Excel workbook: the published models, their expected signs, the concept table, the error-correction and channel settings, the regime threshold and the references. The config only points to it:

```yaml
literature:
  workbook: config/literature_workbook.xlsx
```

The app requires one; `python tools/literature_template.py` writes a template filled with the example's content (the app offers the same file for download).

| Sheet | One row per | Columns |
|---|---|---|
| `models` | driver of a published model (rows with the same `model` name form one model) | `model`, `source`, `variable` (a concept from `concepts`, or one of your series directly), `transform` (dlog, yoy, dlog2, acc, gap, diff, diff2, diff4, lvl, rgap), `lag` (quarters), **`expected_sign`** (+1 / −1 / 0: the sign this study expects for this driver; empty = the concept's sign), `core` (yes on the rows of the one model that is the theory core) |
| `concepts` | economic concept | the concept table described below |
| `settings` | setting | `apply_signs_to_metadata`, `ecm_enabled`, `ecm_name`, `ecm_source`, `ecm_deflator`, `ecm_long_run` (`table` = the concepts with a `long_run_form`, or e.g. `house_prices:log, disposable_income:log_real`), `ecm_short_run` (`core` or a list), `channels` (`table` or a list), `regime_threshold` (e.g. `house_prices\|dlog\|L1`) |
| `references` | study | the full references |
| `how to fill` | — | these instructions |

**Expected signs:** each literature model's coefficients are checked against the signs in its `models` rows. The model detail page (⑤) shows an "Expected sign" and a "Sign as expected" column, and a wrong sign is listed in the diagnostics. In the concepts sheet, `moodys_name` cells that do not match your data are re-matched automatically by the set-up; the matches, the models (signs included) and the settings can all be changed in the app (②), and the app saves them into `config/<name>_literature.xlsx`. The pre-flight check validates every sheet: variables that exist, valid transforms and signs, a deflator and a regime threshold that resolve.

### The concepts sheet

One row per economic concept that the literature links to household and mortgage credit.

| Column | What it holds |
|---|---|
| `concept_id` | Used in the models sheet: `house_prices`, `disposable_income`, `real_gdp`, `mortgage_rate`, `policy_rate`, `real_mortgage_rate`, `unemployment`, `inflation`, `term_spread`, `affordability`, `credit_conditions`, `deposits` |
| `expected_sign`, `effect_on_loan_growth` | +1 / −1 / 0, and Positive / Negative / Ambiguous |
| `why`, `evidence` | The mechanism, and the studies that support it |
| `transform`, `theory_lags` | Suggested form and lag window |
| `core` | Part of the four-channel theory core (house prices, income, mortgage rate, unemployment) |
| `long_run_form` | Enters the error-correction long run (`log`, `log_real`, `real_rate`) |
| `include` | `yes` / `no`: your filter |
| `moodys_name` | **The name of the series in your macro file.** This is the only place names are matched. |

How the pipeline uses it:
- **Models refer to concepts, not Moody's names.** For example, `house_prices|dlog|L1` in the models sheet is resolved through `moodys_name`. If your vendor or vintage uses different names, edit that one column.
- **`include: no` removes a concept everywhere:** from every literature and hybrid model, the error-correction long run, the theory channels and the Chronos-2 covariates.
- **With `apply_signs_to_metadata = yes` in the settings sheet (the default),** the table's signs also apply to the data-driven screen. A concept set to `include: no` gets sign 0, so the data cannot select it either.
- **A concept with no `moodys_name`** (affordability and credit conditions in the example) is skipped with a message.
- **Each run writes `comparison/10_literature_variables.csv`,** showing for every concept whether it is in use, available, not mapped or switched off, and which models use it.

## Presentation deck (`report/loan_model_deck.qmd`)

```
python run_pipeline.py
python run_oos.py
python tools/make_deck.py --config config/example_config.yaml   # writes outputs/<run>/<run>_deck.pptx
```

`tools/make_deck.py` (also the "Build the presentation" button in the app) renders the deck for any config: the title, the region in the text and the footer come from the config (`screen_first.primary_geography`) or `--title` / `--region`; `--simulated` adds the simulated-data notes. `quarto render report/loan_model_deck.qmd` still works for the example (writes `report/loan_model_deck.pptx`).

Every number, table and chart in the deck is read from `outputs/`, so after a re-run the deck updates itself. The slides cover:
- the objective and requirements;
- the methodology: target, transformations, the two selection approaches, the selection rules, the literature, the model families, and machine learning and AI;
- the rolling backtest and the out-of-sample test at 4, 8 and 12 quarters;
- the best model of each family;
- the trade-off between accuracy and the number of variables;
- the look-ahead check, driver stability and the holdout;
- the recommended model with its diagnostics and scenarios;
- limitations and next steps.

The recommended model is the most accurate out-of-sample model with at most `max_variables` (3) distinct macro variables, long-run variables included. The most accurate model overall is shown next to it.

- **Requirements:** Quarto (quarto.org), plus `pip install python-pptx jupyter` in the same Python that runs the app or `tools/make_deck.py` (both are in requirements.txt). If one is missing, the build stops with the exact install command.
- **Another run:** `python tools/make_deck.py --config config/my_portfolio.yaml` (the deck's parameters are read from `DECK_CONFIG`, `DECK_OUTPUTS`, `DECK_SIMULATED`, `DECK_REGION` environment variables, so papermill is not needed).
- **Look:** two layers.
  - `report/reference.pptx` sets the theme: Cambria headings, Calibri body, the colour palette, and dark title and section slides. Build it with `python report/make_reference.py`.
  - `report/style_deck.py` runs automatically after `quarto render` (set in `report/_quarto.yml`) and turns simple markers in the `.qmd` into designed elements:

    | Marker | Becomes |
    |---|---|
    | `[[tile: 1.37% \| label \| note]]` | stat tile |
    | `[[icon: home \| heading \| text]]` | icon card (icons in `report/icons/`) |
    | `[[step: ...]]` | process steps |
    | `[[card: heading \| line; line]]` | card with a list |
    | `[[band: lead \| text]]` | dark band across the bottom |
    | `[[chart: id]]` | native, editable PowerPoint chart (specs written by the `.qmd` to `report/_charts/`) |
    | `[[split: 60]]` | left column 60% of the width |
    | `[[dark-slide]]` | dark background for the whole slide |

    A column starting with ★ becomes a dark card. Tables get a dark header, banded rows, and green Pass / red Review.
  - To keep Quarto's plain output for debugging, set `STYLE_DECK_SKIP=1`.

## Function reference (`docs/reference.html`, automatic)

A searchable page with a card for every module, class, function and method in the project (about 280), built from the code itself, so it cannot drift from it. Each card shows:

- the signature, and what each argument means and what is returned (from the docstring);
- the config settings the function reads, e.g. `sample.horizon`;
- what it calls and what calls it, with links. Calls that only show up at run time, like `model.fit` inside the backtest, are taken from the run trace and marked *run*;
- **an example from the latest run**: the inputs it actually received, what it returned and a preview of the returned table. If the function has changed since that run, a warning says the example may be out of date;
- its source code, and the date it was added or last changed.

The page also has a short run flow for each script, listing the steps it ran in order with their run times, plus a list of recent changes. `docs/REFERENCE.md` holds the same reference as plain text without the examples, for reading on GitHub.

**It updates itself.** Three ways, use any of them:

| When | How |
|---|---|
| After every run | `run_pipeline.py` and `run_oos.py` rebuild it at the end if any code or trace changed (about 2 s; `docs:` in the config, `enabled: false` to switch off) |
| While editing | `python tools/make_docs.py --watch` rebuilds every time a `.py` file is saved |
| On every commit | `python tools/make_docs.py --install-hook` adds a git pre-commit hook that rebuilds it and adds `docs/` to the commit |

`python tools/make_docs.py --check` exits with code 1 if the reference is out of date (for CI); `--force` rebuilds now.

Examples are kept in `docs/examples.json` between runs, so a step loaded from the cache keeps the example from the last time it ran. To give a new function a description, write a docstring in the same style as the others:

```python
def refit_flags(ctx, origins, every=None):
    """True where the coefficients are re-estimated.

    Args:
        ctx: Context. origins: positions of the forecast origins. every: quarters between re-estimations.

    Returns:
        bool array, one per origin.
    """
```

Functions without a docstring are listed on the overview page.

## Run trace (automatic, every run)

**Two views.** `trace.html` opens on the **Data story**, written for someone who knows econometrics but not this model. It walks the data through the pipeline in 14 steps (4 for `run_oos.py`: re-selection, accuracy, Diebold-Mariano tests, holdout):

1. data in
2. organic growth (events removed)
3. relevance filter
4. transforms
5. ADF stationarity tests
6. lags
7. univariate screen
8. correlation clusters
9. the combination search
10. Elastic Net with stability selection
11. the final estimate
12. one backtest origin worked through, quarter by quarter
13. the baseline forecast taken apart, driver by driver
14. the competing models

Each step gives:
- what goes in, and the operation as an equation (e.g. `y_t = a + ρ y_{t−1} + Σ δ_q D_q + β x_t + e_t`, HAC s.e.);
- the decision rule, and this run's own counts (e.g. 638 of 738 forms stationary, 2,625 combinations and what each rule removed);
- tables of the actual data, including the regression's design matrix: the exact rows OLS sees;
- links to the exact calls in the **Call tree** view.

One variable is followed through every step: the first chosen driver, or `trace.follow` in the config. The story is built from each stage's outputs, so it is complete even when steps come from the cache. The **Call tree** view is the debugger described below.


Every run of `run_pipeline.py` or `run_oos.py` writes a detailed trace. Nothing in the code needs marking up. At start-up the tracer wraps:
- every function and method under `src/`;
- the entry script's own functions, such as `run()`;
- functions defined inside other functions, and lambdas, when they are passed to a traced call (such as the work inside each cached step);
- the library routines that do the numerical work, marked **lib**: statsmodels OLS and the ADF test, the residual tests, scikit-learn's ElasticNet, scipy clustering, numpy least squares, and pandas file reading. What happens inside a library routine is not traced.

A function you add or change is traced on the next run.

For each call the trace records:
- the function, its file and line, its docstring, and its source code as it was when the run happened;
- which call it came from, in execution order, and how long it took;
- every argument and the return value: type, size, column names, values;
- **the local variables when the call ended**, as a debugger shows them, with small previews of tables. For a loop, these are the values from the last pass;
- for every regression, the coefficient table (coef, s.e., t, p);
- a preview of every table it returned, with the full table saved as CSV;
- the messages it printed;
- the error, traceback and local variables, if it failed.

A function called many times from the same place, such as one regression per candidate, is shown once with ×N. Its page lists the other calls (up to 500) with a short description of their arguments, start time and duration. Calls with a different text argument, such as the step names `screen_first` and `en_first`, get their own entry.

Output goes to `outputs/<run_name>/trace/<date_time>/` (`trace_oos/` for `run_oos.py`), one folder per run. The newest 10 are kept.

| File | What it is |
|---|---|
| `trace.html` | the clickable page: call tree on the left; **Step into / Step over / Step out / Back** (arrow keys) |
| `trace.log` | the same as an indented text log |
| `trace.json` | everything, for `tools/trace_to_html.py` |
| `tables/` | the full tables |

The page is built automatically at the end of the run. To rebuild one (for example from a trace a colleague sent you):

```
python tools/trace_to_html.py                                   # newest trace under outputs/
python tools/trace_to_html.py outputs/<run>/trace/<date_time>/trace.json
```

Settings are in the `trace:` section of the config:

| Setting | Default | What it does |
|---|---|---|
| `enabled` | `true` | `--no-trace` also switches it off for one run |
| `preview_rows` | 20 | rows shown per table in the page |
| `save_tables` | `true` | save returned tables as CSV |
| `max_table_cells` | 200000 | larger tables are previewed but not saved |
| `detail_calls` | 1 | how many repeated calls to record in full |
| `local_variables` | `true` | record each call's local variables |
| `local_preview_rows` | 8 | rows shown per local table |
| `library_functions` | `default` | `default` for the list in `src/utils/trace.py`, `[]` for none, or your own list such as `["statsmodels.tsa.stattools:adfuller"]` |
| `distinct_labels` | 8 | how many differently labelled calls get their own entry |
| `keep_runs` | 10 | how many trace folders to keep |

A step loaded from the cache has no calls inside it in the trace. Run with `--force` to trace the full computation. Tracing adds about 1–2 seconds to a 25-second full run.

## Step-by-step walkthrough (`python tools/walkthrough.py`)

A guided tour rather than a trace: it repeats the pipeline's steps by hand with an explanation for each, so it does not follow your code changes automatically (the run trace does).

Runs the whole pipeline one function at a time on a small example (`config/mini_config.yaml`: 12 macro variables in `data/mini/`, 2 scenarios, fewer transforms and lags), like stepping through it in a debugger. Takes about 20 seconds.

- Each step's result is saved as `outputs/mini_walkthrough/walkthrough/<NN>_<name>.csv` (or `.txt` for regression output).
- `walkthrough.html` in the same folder lets you click through the 25 steps. For each step it shows the call, the file and line of the function, its source code, the result tables and charts, the file the result was saved to, and which objects are now in memory (like RStudio's Environment pane).
- The last step re-runs `screen_first.run()` and `en_first.run()` and checks they give the same results as the step-by-step run.

To walk through your own data, point it at a small config: `python tools/walkthrough.py --config config/my_small_config.yaml` (`--skip-oos` leaves out the slower out-of-sample step).

## Folders

```
run_pipeline.py          entry point (selection, evaluation, scenarios)
run_oos.py               out-of-sample test with re-selection at each origin
app.py                   the app: upload files, review settings, run, see results (streamlit run app.py)
config/                  one YAML per data set
data/                    example (simulated) inputs
tools/simulate_data.py   rebuilds the example data
tools/walkthrough.py     step-by-step walkthrough (HTML) on the small example
tools/trace_to_html.py   turns a run trace into a clickable page
tools/new_data_setup.py  writes a config for a new data set from its files
tools/check_config.py    checks a config and its data before a run
tools/make_docs.py       builds the function reference (--watch, --check, --install-hook)
docs/                    reference.html and REFERENCE.md (generated; do not edit)
src/utils/trace.py       records every call during a run
src/utils/               config loading, file reading, package set-up, cache.py (hashing), docs.py (reference)
src/features/            transformations, stationarity tests, candidate features
src/selection/           screening.py, clustering.py, elastic_net.py (incl. stability selection)
src/modelling/           ardl.py (final model), search.py (shared final search), evaluate.py
src/pipelines/           screen_first.py (A), en_first.py (B)
src/validation/oos.py    out-of-sample test
src/models/              competing models: zoo.py (builds them all), ecm.py, ml.py, combination.py, foundation.py,
                         hybrid.py, deep.py (TiDE, N-HiTS, TFT, ARIMAX, Theta), regime.py (regime switching)
report/                  loan_model_deck.qmd (Quarto deck), style_deck.py (design pass), reference.pptx, icons/
config/literature_workbook.xlsx  everything on the literature: models with expected signs, concepts, settings,
                         references (literature_references.csv is the source of the template's references sheet)
tools/make_deck.py       builds the styled deck for any run (also the button in the app's Results tab)
src/reporting/           tables, charts, summary
outputs/<run_name>/      common/, screen_first/, en_first/, comparison/, summary.md
```

## What each approach does

**Shared start**
- Relevance filter, transformations (q/q, y/y, 2-quarter, acceleration, gap, real growth; changes and levels for rates).
- ADF stationarity test, lags 0–4, giving about 2,300 candidate features on the example data.

**A: screen first** (`src/pipelines/screen_first.py`)
1. Regress loan growth on lagged growth and the dummies plus each candidate on its own. A candidate passes if p < 0.05 (Newey-West) and has the expected sign.
2. Keep the best form and lag per variable.
3. Cluster at |correlation| > 0.75 and keep one per cluster (an Ontario series is preferred if nearly as strong).
4. The top 25 go to the final search.

**B: Elastic Net first** (`src/pipelines/en_first.py`, `src/selection/elastic_net.py`)
1. Lagged loan growth and the dummies are left unpenalized: they are partialled out first, which is the same as glmnet's `penalty.factor = 0`.
2. X and y are standardized as glmnet does.
3. Coefficients are constrained to their expected sign (optional).
4. Lambda is the first point on the path where `target_n` features are selected. There is no cross-validation, so the result is deterministic for given data.
5. **Stability selection** (optional, on by default): repeat on 100 subsamples built from blocks of consecutive quarters, and keep features selected in at least 60% of them.
6. Group the picks at |correlation| > 0.75 and keep one per group.

**Shared final step** (`src/modelling/search.py`)
1. Try every combination of 1–3 candidates. A combination is kept only if:
   - every driver is significant;
   - every sign is as expected;
   - the VIF is below 5;
   - there is at most one driver per theme.
2. Rank the survivors by out-of-sample balance error in the rolling backtest.
3. Choose the simplest model within 5% of the best.

**Evaluation** (`src/modelling/evaluate.py`)
- Rolling backtest 1–9 quarters ahead, with dummy quarters excluded from the error.
- Residual diagnostics.
- A plain-language driver table.
- Forecasts under every scenario.
- An AR(1) benchmark, run alongside for comparison.

## Example results (simulated data)

Average balance error (MAPE), dummy quarters excluded. "Rolling backtest" uses drivers chosen with all the data. "Out of sample" re-selects everything at each of 12 origins.

| Model | Family | Backtest 1–4Q | Backtest 1–12Q | Out of sample 1–4Q | 1–8Q | 1–12Q |
|---|---|---|---|---|---|---|
| AR(1) benchmark | Benchmark | 0.82% | 1.87% | 0.83% | 1.45% | 2.09% |
| Screen first | Data-driven | 0.43% | 0.71% | 0.60% | 0.91% | 1.37% |
| Elastic Net first | Data-driven | 0.43% | 0.93% | 0.53% | 1.05% | 1.61% |
| Literature: four-channel core | Literature | 0.46% | 1.02% | 0.47% | 0.77% | 1.11% |
| Literature: error-correction model | Literature | 0.55% | 0.94% | 0.59% | 0.90% | 1.10% |
| Hybrid: theory long run + data short run | Hybrid | 0.50% | 0.83% | 0.65% | 0.88% | 1.02% |
| Hybrid: 50/50 data + theory | Hybrid | 0.36% | 0.70% | 0.52% | 0.78% | 1.12% |
| Gradient boosting | Machine learning | 0.41% | 0.81% | 0.52% | 0.83% | 1.10% |
| Neural network (MLP) | Machine learning | 0.40% | 0.75% | 0.60% | 0.86% | 1.19% |

What this shows:
- With drivers chosen on all the data, the 50/50 hybrid and screen first look best.
- Out of sample, with everything re-selected, the models anchored in theory hold up best at 8–12 quarters. The best is the hybrid with a theory long run and data-chosen short-run drivers.
- Within the three-variable limit, screen first is best (35% below AR(1) over 1–12 quarters).
- The ECB BEAST specification does worse than AR(1) on this data.

With 12-quarter ranking, screen first chose Canadian mortgage-credit growth, Ontario income and residential building permits. Mortgage credit is close to the target itself; review whether credit aggregates should be allowed as drivers.

At `target_n = 10`, the full-sample Elastic Net spent 9 of its 10 picks on city house-price series. Stability selection and grouping reduced these to one house-price driver plus income.
