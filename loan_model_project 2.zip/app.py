"""Loan model app: upload your files, review the settings it proposes, check, run and see the results.

    pip install streamlit
    streamlit run app.py

Runs on your computer and opens in your browser. Nothing leaves your machine. Every setting the app writes is
an ordinary config file (config/<name>.yaml), so a run started here can be repeated from the command line.
"""
import glob
import os
import subprocess
import sys
import time

import numpy as np
import pandas as pd
import streamlit as st

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "tools"))

import new_data_setup as setup  # noqa: E402
from src.utils.config import load_config  # noqa: E402
from src.utils.preflight import check  # noqa: E402

st.set_page_config(page_title="Loan model", page_icon="📈", layout="wide")
_v = tuple(int(x) for x in st.__version__.split(".")[:2] if x.isdigit())
if _v < (1, 23):
    st.error(f"This app needs Streamlit 1.23 or later (you have {st.__version__}): pip install --upgrade streamlit")
    st.stop()
S = st.session_state

ML = ["ridge", "random_forest", "gradient_boosting", "neural_net"]
REGIME = ["markov", "threshold", "smooth_transition", "tvp", "break_adaptive"]
STAT = ["arimax", "theta"]
DEEP = ["tide", "nhits", "tft", "nbeats", "tsmixer"]


# --------------------------------------------------------------------------------------------- helpers
def wide_image(path):
    """Show an image at the page width, whatever the Streamlit version (the setting was renamed in 1.40).

    Args:
        path: image file.
    """
    for kw in ({"use_container_width": True}, {"use_column_width": True}, {}):
        try:
            return st.image(path, **kw)
        except TypeError:
            continue


class _Box:
    """Stand-in for st.status on Streamlit versions before 1.26: an expander whose label cannot change."""

    def __init__(self, label):
        """Open an expander.

        Args:
            label: its title.
        """
        self.exp = st.expander(label, expanded=True)

    def __enter__(self):
        """Enter the expander."""
        self.exp.__enter__()
        return self

    def __exit__(self, *a):
        """Leave the expander."""
        return self.exp.__exit__(*a)

    def update(self, label="", state="", expanded=True):
        """Show the final status as a message instead of relabelling.

        Args:
            label: message. state: complete or error. expanded: unused.
        """
        (st.error if state == "error" else st.success)(label)


def status_box(label):
    """st.status where available, an expander otherwise.

    Args:
        label: title.

    Returns:
        context manager with update().
    """
    return st.status(label, expanded=True) if hasattr(st, "status") else _Box(label)


def save_upload(f, folder):
    """Save an uploaded file to the project's data folder and return its path.

    Args:
        f: Streamlit UploadedFile. folder: target folder.

    Returns:
        path.
    """
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, f.name)
    with open(path, "wb") as out:
        out.write(f.getbuffer())
    return path


def quarters(a, b):
    """Quarter labels from a to b.

    Args:
        a, b: quarter labels.

    Returns:
        list of str.
    """
    return [str(q) for q in pd.period_range(pd.Period(a, "Q"), pd.Period(b, "Q"), freq="Q")]


def q_select(label, options, value, key, help=None):
    """A quarter picker that keeps a value missing from the options.

    Args:
        label: label. options: quarter labels. value: current value. key: widget key. help: tooltip.

    Returns:
        the chosen quarter.
    """
    opts = list(options)
    if value not in opts:
        opts = [value] + opts
    return st.selectbox(label, opts, index=opts.index(value), key=key, help=help)


def show_report(rep):
    """Pre-flight findings: errors and warnings with their fixes, the rest folded.

    Args:
        rep: Report from src.utils.preflight.check.
    """
    if rep.errors:
        st.error(f"{len(rep.errors)} problem(s) to fix before running")
    elif rep.warnings:
        st.warning(f"Ready to run, with {len(rep.warnings)} warning(s)")
    else:
        st.success("Ready to run: every check passed")
    for i in rep.errors + rep.warnings:
        box = st.error if i["level"] == "error" else st.warning
        box(f"**{i['area']}** · {i['message']}" + (f"\n\n→ {i['fix']}" if i["fix"] else ""))
    with st.expander(f"All {len(rep.items)} checks"):
        st.dataframe(pd.DataFrame(rep.items), hide_index=True, use_container_width=True)


def run_script(script, cfg_path, extra=()):
    """Run run_pipeline.py or run_oos.py and stream its log into the page.

    Args:
        script: script file name. cfg_path: config. extra: more command-line arguments.

    Returns:
        exit code.
    """
    cmd = [sys.executable, "-u", os.path.join(HERE, script), "--config", cfg_path, *extra]
    lines, steps = [], 0
    with status_box(f"Running {script} …") as box:
        bar = st.progress(0.0, text="starting")
        area = st.empty()
        t0 = time.time()
        p = subprocess.Popen(cmd, cwd=HERE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
        for ln in p.stdout:
            if "Warning" in ln or "warnings.warn" in ln or "litlogger" in ln:
                continue
            lines.append(ln.rstrip())
            if "[computed]" in ln or "[  cached]" in ln or ln.startswith("origin "):
                steps += 1
                bar.progress(min(0.98, steps / 40), text=ln.strip()[:90])
            area.code("\n".join(lines[-25:]), language=None)
        code = p.wait()
        bar.progress(1.0, text=f"finished in {time.time() - t0:.0f} s")
        box.update(label=f"{script} {'finished' if code == 0 else 'stopped with an error'} ({time.time() - t0:.0f} s)",
                   state="complete" if code == 0 else "error", expanded=code != 0)
    S["last_log"] = "\n".join(lines)
    return code


def friendly(df):
    """Error columns renamed for reading: avg_1_4_pct -> "Error, 1–4 quarters (%)".

    Args:
        df: table with avg_1_h_pct columns.

    Returns:
        DataFrame.
    """
    ren = {c: f"Error, 1–{c.split('_')[2]} quarters (%)" for c in df.columns if c.startswith("avg_1_") and c.endswith("_pct")}
    return df.rename(columns={**ren, "model": "Model", "family": "Family"}).round(3)


@st.cache_data
def lit_template():
    """The literature workbook template (the example's models, concepts, settings and references) as .xlsx bytes."""
    return open(os.path.join(HERE, "config", "literature_workbook.xlsx"), "rb").read()


def _read(out, *p):
    """A result table, or an empty one if the file is not there.

    Args:
        out: run output folder. p: path parts.

    Returns:
        DataFrame.
    """
    f = os.path.join(out, *p)
    return pd.read_csv(f) if os.path.exists(f) else pd.DataFrame()


def model_details(out, comp, H):
    """The detail page of one model: what it is, its drivers (coefficients, importance, scenario effect), checks,
    error by horizon, coefficients over time, scenario paths and regimes.

    Args:
        out: run output folder. comp: model comparison. H: horizon.
    """
    st.subheader("Model details")
    names = list(comp.sort_values(f"avg_1_{H}_pct")["model"])
    m = st.selectbox("Model", names, key="detail_model")
    ml = _read(out, "comparison", "9_model_list.csv")
    row = ml[ml["model"] == m]
    if len(row):
        r = row.iloc[0]
        st.markdown(f"**{m}** · {r['family']}  \n{r.get('how it is specified', '') or ''}"
                    + (f"  \nSource: {r['source']}" if isinstance(r.get("source"), str) and r["source"] else "")
                    + f"  \nDrivers: `{r['drivers']}`")
    drv = _read(out, "comparison", "3_drivers.csv")
    d = drv[drv["model"] == m].drop(columns=["model"]).dropna(axis=1, how="all")
    if len(d):
        st.markdown("**Drivers**: coefficients with HAC standard errors, t and p for regressions; importance (%) for trees and "
                    "TFT; weights for combinations. The two *scenario effect* columns work for every model type, including "
                    "the networks: how much the driver's baseline path moves the forecast, compared with holding the driver "
                    "at its last actual value.")
        names = {"term": "Driver", "coef": "Coefficient / importance / weight",
                 "se_hac": "s.e. (HAC)", "t": "t", "p": "p", "expected_sign": "Expected sign", "sign_ok": "Sign as expected",
                 "importance_decoder_pct": "TFT importance looking ahead (%)",
                 "growth_effect_pp_per_year": "Scenario effect on growth (pp a year)",
                 "balance_effect_pct_8q": "Scenario effect on the balance after 8 quarters (%)",
                 "description": "What it is", "reading": "Reading"}
        order = [c for c in names if c in d.columns] + [c for c in d.columns if c not in names]
        d = d[order].rename(columns=names)
        d["What it is"] = d["What it is"].fillna("") if "What it is" in d else ""
        st.dataframe(d.round(4), hide_index=True, use_container_width=True)
    dg = _read(out, "comparison", "4_diagnostics.csv")
    dg = dg[dg["model"] == m]
    if len(dg) and dg.iloc[0].get("note") != "no regression residual tests for this model type":
        st.markdown("**Residual checks** (p-values: above 0.05 means no evidence of a problem)")
        st.dataframe(dg.drop(columns=["model", "family"]).dropna(axis=1, how="all").T.rename(columns={dg.index[0]: "value"}),
                     use_container_width=True)
    c1, c2 = st.columns(2)
    bh = _read(out, "comparison", "2_backtest_by_horizon.csv")
    oh = _read(out, "oos", "2_oos_by_horizon.csv")
    err = pd.DataFrame(index=range(1, H + 1))
    if len(bh):
        err["backtest"] = bh[bh["model"] == m].set_index("horizon_q")["MAPE_exCOVID_pct"]
    if len(oh) and "MAPE_pct" in oh:
        err["out of sample"] = oh[oh["model"] == m].set_index("horizon_q")["MAPE_pct"]
    with c1:
        st.markdown("**Balance error by quarters ahead (%)**")
        st.line_chart(err.dropna(how="all"))
    sc = _read(out, "comparison", "6_scenario_forecasts.csv")
    sc = sc[sc["model"] == m]
    with c2:
        if len(sc):
            st.markdown("**Balance forecast under each scenario**")
            try:
                import altair as alt
                ch = alt.Chart(sc).mark_line().encode(
                    x=alt.X("date:O", title=None, axis=alt.Axis(labelAngle=-90, labelOverlap=True)),
                    y=alt.Y("balance_forecast:Q", title="balance", scale=alt.Scale(zero=False)),
                    color=alt.Color("scenario:N", sort=list(dict.fromkeys(sc["scenario"]))),
                    tooltip=["scenario", "date", alt.Tooltip("balance_forecast:Q", format=",.0f")]).properties(height=300)
                st.altair_chart(ch, use_container_width=True)
            except Exception:
                st.line_chart(sc.pivot_table(index="date", columns="scenario", values="balance_forecast", sort=False))
    cp = _read(out, "comparison", "7_coefficient_paths.csv")
    cp = cp[cp["model"] == m].dropna(axis=1, how="all") if len(cp) else cp
    if len(cp):
        keep = [c for c in cp.columns if c not in ("model", "origin", "const") and not c.startswith("D_")]
        if keep:
            st.markdown("**Coefficients at each backtest re-estimation** (stable lines = a stable model)")
            st.line_chart(cp.set_index("origin")[keep])
    rg = _read(out, "comparison", "11_regimes.csv")
    rg = rg[rg["model"] == m] if len(rg) else rg
    if len(rg):
        st.markdown(f"**Regime over history**: {rg['meaning'].iloc[0]}")
        st.line_chart(rg.set_index("date")["value"])
    pk = _read(out, "oos", "4_drivers_by_origin.csv")
    pk = pk[pk["model"] == m] if len(pk) else pk
    if len(pk):
        st.markdown("**Drivers chosen at each out-of-sample origin**")
        st.dataframe(pk.drop(columns=["model"]), hide_index=True, use_container_width=True)


# --------------------------------------------------------------------------------------------- sidebar
st.sidebar.title("Loan model")
mode = st.sidebar.radio("Start from", ["New data set", "Existing configuration"], key="mode")
if mode == "New data set":
    name = st.sidebar.text_input("Name of this set-up", value=S.get("name", "my_portfolio"),
                                 help="Used for config/<name>.yaml and outputs/<name>/").strip().replace(" ", "_")
    S["name"] = name
    cfg_path = os.path.join(HERE, "config", f"{name}.yaml")
else:
    cfgs = sorted(glob.glob(os.path.join(HERE, "config", "*.yaml")))
    pick = st.sidebar.selectbox("Configuration", [os.path.basename(c) for c in cfgs])
    cfg_path = os.path.join(HERE, "config", pick)
    name = os.path.splitext(pick)[0]
st.sidebar.caption(f"Config file: `config/{os.path.basename(cfg_path)}`")
st.sidebar.divider()
if mode == "New data set":
    st.sidebar.markdown("**Steps**\n1. Files\n2. Data settings\n3. Sample and models\n4. Check and run\n5. Results")
else:
    st.sidebar.markdown("**Steps**\n\n- ④ Check and run\n- ⑤ Results\n- Edit any setting in the config file")

# --------------------------------------------------------------------------------------------- pages
if mode == "New data set":
    tabs = st.tabs(["① Files", "② Data settings", "③ Sample and models", "④ Check and run", "⑤ Results"])
else:
    tabs = [None, None, None] + list(st.tabs(["④ Check and run", "⑤ Results", "Edit the config file"]))

# ① files
if mode == "New data set":
    with tabs[0]:
        st.header("Upload your files")
        st.caption("CSV or Excel. Column and variable names can be anything: the next step maps them. "
                   "Files are copied to data/<name>/ in the project folder.")
        c1, c2 = st.columns(2)
        with c1:
            up_bank = st.file_uploader("Loan balance (required)", type=["csv", "xlsx", "xls"], key="up_bank",
                                       help="A date column and the balance; quarterly or monthly")
            up_meta = st.file_uploader("Variable metadata (recommended)", type=["csv", "xlsx", "xls"], key="up_meta",
                                       help="One row per macro variable: code, description, geography, theme, transform, sign. "
                                            "Missing columns are suggested.")
            up_events = st.file_uploader("One-off events (optional)", type=["csv", "xlsx", "xls"], key="up_events",
                                         help="Acquisitions and portfolio sales to take out of the growth")
        with c2:
            up_macro = st.file_uploader("Scenario files (required, one per scenario)", type=["csv", "xlsx", "xls"],
                                        accept_multiple_files=True, key="up_macro",
                                        help="History followed by the scenario path; same variables in every file")
            up_lit = st.file_uploader("Literature models workbook (required)", type=["xlsx"], key="up_lit",
                                      help="Sheet 'models': the published models to compare, one row per driver. "
                                           "Sheet 'concepts': each economic concept and your series for it.")
            st.download_button("Download a template workbook (filled with the example's models)", lit_template(),
                               file_name="literature_workbook.xlsx", key="dl_tpl")
            sheet = st.text_input("Excel sheet name (if not the first sheet)", value="", key="sheet") or None
            target = st.text_input("Balance column (leave empty to detect)", value="", key="target") or None
        ready = up_bank is not None and up_macro and up_lit is not None
        if not ready:
            st.caption("Needed: the loan balance, at least one scenario file and the literature workbook.")
        if st.button("Read the files and propose settings", type="primary", disabled=not ready):
            folder = os.path.join(HERE, "data", name)
            bank = save_upload(up_bank, folder)
            macro = {setup.scenario_name(f.name): save_upload(f, os.path.join(folder, "scenarios")) for f in up_macro}
            meta = save_upload(up_meta, folder) if up_meta else None
            ev = save_upload(up_events, folder) if up_events else None
            litwb = save_upload(up_lit, folder)
            log = []
            try:
                S["P"] = setup.propose(bank, macro, meta, ev, sheet, target, None, name, log=log.append, literature=litwb)
                S["setup_log"] = "\n".join(log)
                st.success("Done: review the proposed settings in ② and ③.")
            except SystemExit as e:
                st.error(str(e))
            except Exception as e:
                st.error(f"{type(e).__name__}: {e}")
        if "setup_log" in S:
            st.subheader("What was found")
            st.code(S["setup_log"], language=None)

    P = S.get("P")

    # ② data settings
    with tabs[1]:
        st.header("Data settings")
        if not P:
            st.info("Upload the files in ① first.")
        else:
            st.subheader("Dependent variable")
            st.caption("Choose the balance to forecast. The model explains its organic quarterly log growth "
                       "(one-off events removed) and turns the growth forecasts back into the balance.")
            c1, c2, c3 = st.columns(3)
            cols = P["bank"]["columns"]
            P["bank"]["date_column"] = c1.selectbox("Date column", cols, index=cols.index(P["bank"]["date_column"]))
            num = [c for c in cols if c != P["bank"]["date_column"]]
            P["bank"]["target_column"] = c2.selectbox("Balance to forecast (dependent variable)", num,
                                                      index=num.index(P["bank"]["target_column"]) if P["bank"]["target_column"] in num else 0)
            P["bank"]["frequency"] = c3.selectbox("Frequency", ["Q", "M"], index=["Q", "M"].index(P["bank"]["frequency"]),
                                                  format_func=lambda x: {"Q": "Quarterly", "M": "Monthly (quarter-end used)"}[x])
            try:                                                  # preview of the chosen series
                from src.utils.io import read_table, to_quarters
                bk = read_table(P["bank"]["file"], P["bank"]["sheet"])
                y = pd.to_numeric(bk[P["bank"]["target_column"]], errors="coerce")
                y.index = to_quarters(bk[P["bank"]["date_column"]])
                y = (y.groupby(level=0).last() if P["bank"]["frequency"] == "M" else y).dropna().sort_index()
                g = (np.log(y).diff() * 100).rename("q/q growth (%)")
                y.index, g.index = y.index.astype(str), g.index.astype(str)
                p1, p2 = st.columns(2)
                p1.markdown(f"**{P['bank']['target_column']}**, {y.index[0]} to {y.index[-1]} ({len(y)} quarters)")
                p1.line_chart(y.rename("balance"))
                p2.markdown(f"**Quarterly log growth (%)**: mean {g.mean():.2f}, s.d. {g.std():.2f} (before removing one-off events)")
                p2.bar_chart(g.dropna())
                if (y <= 0).any():
                    st.error("This column has zero or negative values: the model needs a positive balance (it uses log growth).")
            except Exception as e:
                st.warning(f"Cannot preview this column: {e}")

            st.subheader("Scenarios")
            sc = pd.DataFrame({"scenario": list(P["macro"]["files"]), "file": [os.path.basename(f) for f in P["macro"]["files"].values()]})
            sc = st.data_editor(sc, hide_index=True, disabled=["file"], key="sc_edit", use_container_width=True)
            paths = list(P["macro"]["files"].values())
            P["macro"]["files"] = {n: p for n, p in zip(sc["scenario"], paths)}
            names_ = list(P["macro"]["files"])
            base = P["macro"]["base"] if P["macro"]["base"] in names_ else names_[0]
            P["macro"]["base"] = st.selectbox("Base scenario (its history is used for estimation)", names_, index=names_.index(base))

            st.subheader("Metadata columns")
            if P["metadata"]["file"] and os.path.basename(P["metadata"]["file"]).endswith("_metadata_draft.csv"):
                st.warning(f"Some metadata was missing, so the app drafted it: `{setup.rel(P['metadata']['file'])}`. "
                           "Review the expected signs: they decide what can be selected.")
            mcols = list(pd.read_csv(P["metadata"]["file"], nrows=0).columns) if P["metadata"]["file"].endswith(".csv") \
                else list(pd.read_excel(P["metadata"]["file"], nrows=0).columns)
            cc = st.columns(6)
            for i, k in enumerate(["mnemonic", "description", "geography", "theme", "transform", "expected_sign"]):
                cur = P["metadata"]["columns"].get(k, mcols[0])
                P["metadata"]["columns"][k] = cc[i].selectbox(k, mcols, index=mcols.index(cur) if cur in mcols else 0, key=f"mc_{k}")

            st.subheader("Which variables are candidates")
            c1, c2 = st.columns(2)
            P["allowed"] = c1.multiselect("Geographies considered (empty = all)", P["geographies"], default=[g for g in P["allowed"] if g in P["geographies"]])
            P["primary"] = c2.selectbox("Main region (preferred when two series are near-duplicates)", P["geographies"],
                                        index=P["geographies"].index(P["primary"]) if P["primary"] in P["geographies"] else 0)
            c1, c2, c3 = st.columns(3)
            P["excluded_themes"] = c1.multiselect("Themes left out", P["themes"], default=P["excluded_themes"])
            P["real_themes"] = c2.multiselect("Themes also tried in real terms", P["themes"], default=P["real_themes"])
            series = sorted(P["base"].columns)
            dfl = P["deflator"] if P["deflator"] in series else None
            P["deflator"] = c3.selectbox("Price index (deflator)", [None] + series, index=([None] + series).index(dfl),
                                         format_func=lambda x: "none (no real transforms)" if x is None else x)

            st.subheader("Literature concepts → your series")
            st.caption("The published models refer to concepts. Pick your series for each; leave empty or untick to leave a concept out. "
                       "The four core concepts feed most theory-based models.")
            lit = P["lit"].copy()
            lit["include"] = lit["include"].astype(str).str.lower().isin(["yes", "y", "true", "1"])
            opts = series + [c[0] for c in P["constructed"]]
            show = lit[["concept", "include", "moodys_name", "core", "expected_sign", "setup_note"]].rename(
                columns={"moodys_name": "your series", "setup_note": "how it was matched"})
            ed = st.data_editor(show, hide_index=True, use_container_width=True, key="lit_edit",
                                disabled=["concept", "core", "expected_sign", "how it was matched"],
                                column_config={"your series": st.column_config.SelectboxColumn(options=opts),
                                               "include": st.column_config.CheckboxColumn()})
            P["lit"]["moodys_name"] = ed["your series"].values
            P["lit"]["include"] = ["yes" if v else "no" for v in ed["include"]]
            st.subheader("Published models to compare (from your workbook)")
            st.caption("One row per driver; rows with the same model name form one model. The variable is a concept above "
                       "or one of your series. Mark the rows of one model as core: the theory core used by the hybrids, "
                       "regime-switching, ARIMAX and the networks. Add or delete rows here; the workbook is saved with the config.")
            from src.features.transforms import parse_feature
            csg = dict(zip(P["lit"]["concept_id"].astype(str), pd.to_numeric(P["lit"]["expected_sign"], errors="coerce")))
            mrows = [{"model": m["name"], "source": m.get("source", ""), "variable": parse_feature(f)[0],
                      "transform": parse_feature(f)[1], "lag": parse_feature(f)[2],
                      "expected_sign": (m.get("signs") or {}).get(f, csg.get(parse_feature(f)[0])), "core": bool(m.get("core"))}
                     for m in P["lit_models"] for f in m["features"]]
            TRS = ["dlog", "yoy", "dlog2", "acc", "gap", "rdlog", "ryoy", "diff", "diff2", "diff4", "lvl", "rgap"]
            med = st.data_editor(pd.DataFrame(mrows, columns=["model", "variable", "transform", "lag", "expected_sign", "core", "source"]),
                                 hide_index=True, use_container_width=True, num_rows="dynamic", key="lit_models_edit",
                                 column_config={"variable": st.column_config.SelectboxColumn(options=list(P["lit"]["concept_id"]) + opts),
                                                "transform": st.column_config.SelectboxColumn(options=TRS),
                                                "lag": st.column_config.NumberColumn(min_value=0, max_value=8, step=1),
                                                "expected_sign": st.column_config.SelectboxColumn(options=[1, -1, 0], help="+1 or -1: the sign the literature expects in this model; flagged in the diagnostics if the estimate disagrees"),
                                                "core": st.column_config.CheckboxColumn(),
                                                "source": st.column_config.TextColumn(width="medium")})
            new_models = []
            for nm_, g in med.dropna(subset=["model", "variable", "transform"]).groupby("model", sort=False):
                feats_ = [f"{r.variable}|{r.transform}|L{int(r.lag if pd.notna(r.lag) else 0)}" for r in g.itertuples()]
                spec = {"name": nm_, "source": str(g["source"].dropna().iloc[0]) if g["source"].notna().any() else "",
                        "features": feats_,
                        "signs": {f: int(v) for f, v in zip(feats_, pd.to_numeric(g["expected_sign"], errors="coerce")) if pd.notna(v)}}
                if g["core"].fillna(False).astype(bool).any():
                    spec["core"] = True
                new_models.append(spec)
            P["lit_models"] = new_models
            if sum(1 for m in new_models if m.get("core")) != 1:
                st.warning("Mark exactly one model as core.")
            st.subheader("Literature settings (from your workbook)")
            st.caption("The error-correction model, the channels hybrid, the regime threshold and the sign rule. "
                       "Saved in the workbook's settings sheet.")
            from src.models.literature import SETTINGS
            cur = {k: d for k, d, _ in SETTINGS}
            cur.update(P.get("lit_settings") or {})
            sdf = pd.DataFrame([(k, cur.get(k, d), mng) for k, d, mng in SETTINGS], columns=["setting", "value", "meaning"])
            sed = st.data_editor(sdf, hide_index=True, use_container_width=True, disabled=["setting", "meaning"], key="lit_settings_edit")
            P["lit_settings"] = {k: ("" if pd.isna(v) else str(v)) for k, v in zip(sed["setting"], sed["value"])}
            with st.expander(f"Constructed variables ({len(P['constructed'])})"):
                for c in P["constructed"]:
                    st.markdown(f"**{c[0]}** = `{c[1]}` — {c[2]}")

    # ③ sample and models
    with tabs[2]:
        st.header("Sample and models")
        if not P:
            st.info("Upload the files in ① first.")
        else:
            d = P["dates"]
            allq = quarters(d["first"], d["hist_end"])
            st.subheader("Dates")
            st.caption(f"Loan data from {P['series'].index[0]} to {P['series'].index[-1]}; the macro history allows estimation from {d['first']}.")
            c1, c2, c3 = st.columns(3)
            d["hist_end"] = q_select("Last actual quarter (hist_end)", allq, d["hist_end"], "q_he")
            d["estimation_start"] = q_select("Estimation starts", allq, d["estimation_start"], "q_es",
                                             help="Leave about 9 quarters after the data start for lags and yearly changes")
            d["oos_first"] = q_select("Out-of-sample test: first origin", allq, d["oos_first"], "q_fo")
            c1, c2, c3 = st.columns(3)
            d["backtest_start"] = c1.selectbox("Backtest: first origin", allq, index=allq.index(d["backtest_start"]) if d["backtest_start"] in allq else 0)
            d["backtest_end"] = c2.selectbox("Backtest: last origin", allq, index=allq.index(d["backtest_end"]) if d["backtest_end"] in allq else len(allq) - 1)
            S.setdefault("ov", {})
            ov = S["ov"]
            ov["sample.reestimate_every"] = str(c3.selectbox("Re-estimate every", [1, 2, 4], index=2, format_func=lambda x: f"{x} quarter(s)"))
            c1, c2, c3 = st.columns(3)
            ov["sample.horizon"] = str(c1.slider("Forecast horizon (quarters)", 4, 16, 12))
            ov["sample.backtest_step"] = str(c2.selectbox("Backtest origins every", [1, 2, 4], index=0, format_func=lambda x: f"{x} quarter(s)"))
            ov["oos.step"] = str(c3.selectbox("Out-of-sample origins every", [1, 2, 4], index=2, format_func=lambda x: f"{x} quarter(s)"))
            d["dummies"] = st.multiselect("One-off quarters (each gets a dummy and is left out of error measures)", allq, default=d["dummies"])

            st.subheader("Transforms tried for each candidate")
            st.caption("Levels and indexes (metadata transform = dlog) are tried in the level forms; rates (diff) in the rate forms. "
                       "Every form must pass the ADF test, and each is tried at lags 0 to the maximum.")
            LV = {"dlog": "q/q growth", "yoy": "y/y growth", "dlog2": "2-quarter growth", "acc": "acceleration", "gap": "gap from 3-year average"}
            RT = {"diff": "q/q change", "diff2": "2-quarter change", "diff4": "y/y change", "lvl": "level", "rgap": "gap from 3-year average"}
            c1, c2 = st.columns(2)
            ov["features.transforms_level"] = setup.yq(c1.multiselect("Level forms", list(LV), default=list(LV), format_func=lambda k: f"{k}: {LV[k]}"))
            ov["features.transforms_rate"] = setup.yq(c2.multiselect("Rate forms", list(RT), default=list(RT), format_func=lambda k: f"{k}: {RT[k]}"))
            c1, c2 = st.columns(2)
            ov["features.max_lag"] = str(c1.slider("Longest lag (quarters)", 0, 8, 4))
            ov["features.adf_p"] = str(c2.selectbox("ADF test: keep a form if p <", [0.01, 0.05, 0.10], index=1))

            st.subheader("Driver selection")
            c1, c2, c3, c4 = st.columns(4)
            ov["final_model.max_vars"] = str(c1.slider("Most drivers in a model", 1, 6, 3))
            ov["final_model.t_min"] = str(c2.number_input("Smallest |t| allowed", 1.0, 4.0, 1.96, 0.01))
            ov["final_model.vif_max"] = str(c3.number_input("Largest VIF allowed", 2.0, 20.0, 5.0, 0.5))
            ov["approaches"] = setup.yq(c4.multiselect("Selection approaches", ["screen_first", "en_first"], default=["screen_first", "en_first"]))

            st.subheader("Competing models")
            c1, c2, c3 = st.columns(3)
            for k, lab in [("benchmarks", "Benchmarks (AR(1), mean growth)"), ("literature", "Literature models"), ("hybrids", "Hybrids")]:
                ov[f"models.{k}"] = "true" if c1.checkbox(lab, True, key=f"m_{k}") else "false"
            ov["models.machine_learning"] = setup.yq(c2.multiselect("Machine learning", ML, default=ML))
            ov["models.statistical"] = setup.yq(c2.multiselect("Statistical time series", STAT, default=STAT))
            ov["models.regime.models"] = setup.yq(c3.multiselect("Regime switching", REGIME, default=REGIME))
            deep_on = c3.checkbox("Deep learning (TiDE, N-HiTS, TFT; needs darts, adds about 6 minutes)", False, key="m_deep")
            ov["models.deep.enabled"] = "auto" if deep_on else "false"
            ov["models.foundation.enabled"] = "auto" if c3.checkbox("AI foundation models (Chronos; needs internet once)", False, key="m_fm") else "false"

    # ④ check and run
    with tabs[3]:
        st.header("Check and run")
        if not P:
            st.info("Upload the files in ① first.")
        else:
            if st.button("Save the configuration and check it", type="primary"):
                path, lit_path = setup.write_config(P, name, overrides=S.get("ov", {}), log=lambda *_: None)
                S["saved"] = path
                st.success(f"Saved `{setup.rel(path)}` and `{setup.rel(lit_path)}`")
            if S.get("saved") == cfg_path and os.path.exists(cfg_path):
                show_report(check(load_config(cfg_path)))
                c1, c2 = st.columns(2)
                if c1.button("Run the pipeline (selection, backtest, scenarios)", type="primary"):
                    run_script("run_pipeline.py", cfg_path)
                if c2.button("Run the out-of-sample test (slower: re-selects at every origin)"):
                    run_script("run_oos.py", cfg_path)
else:
    with tabs[3]:
        st.header("Check and run")
        show_report(check(load_config(cfg_path)))
        c1, c2 = st.columns(2)
        if c1.button("Run the pipeline", type="primary"):
            run_script("run_pipeline.py", cfg_path)
        if c2.button("Run the out-of-sample test"):
            run_script("run_oos.py", cfg_path)
    with tabs[5]:
        st.header("Edit the config file")
        st.caption("Every setting, with its explanation. Saved as it is; the check in ④ runs on the saved file.")
        txt = open(cfg_path, encoding="utf-8").read()
        new = st.text_area("config", txt, height=600, label_visibility="collapsed")
        if st.button("Save"):
            with open(cfg_path, "w", encoding="utf-8") as f:
                f.write(new)
            st.success("Saved")

# ⑤ results
with tabs[4]:
    st.header("Results")
    try:
        out = load_config(cfg_path)["out_dir"]
    except Exception:
        out = None
    if not out or not os.path.exists(os.path.join(out, "comparison", "1_model_comparison.csv")):
        st.info("No results yet: run the pipeline in ④.")
    else:
        comp = pd.read_csv(os.path.join(out, "comparison", "1_model_comparison.csv"))
        oosf = os.path.join(out, "oos", "1_oos_summary.csv")
        H = max(int(c.split("_")[2]) for c in comp.columns if c.startswith("avg_1_") and c.endswith("_pct"))
        cols = ["model", "family"] + [c for c in comp.columns if c.startswith("avg_1_")]
        if os.path.exists(oosf):
            oo = pd.read_csv(oosf)
            oo = oo[oo["family"] != "Look-ahead check"].sort_values(f"avg_1_{H}_pct")
            best = oo.iloc[0]
            ar = oo[oo["model"] == "AR(1) benchmark"]
            st.success(f"**Most accurate out of sample: {best['model']}** ({best['family']}): average balance error "
                       f"{best[f'avg_1_{H}_pct']:.2f}% over 1–{H} quarters"
                       + (f", against {ar.iloc[0][f'avg_1_{H}_pct']:.2f}% for the AR(1) benchmark" if len(ar) else "")
                       + f". {len(oo)} models compared.")
            st.subheader("Ranking out of sample (drivers re-selected at every origin)")
            st.caption("Average absolute error of the balance, in %, over 1 … h quarters ahead. Lower is better. Use this table to rank models.")
            st.dataframe(friendly(oo[[c for c in cols if c in oo.columns]]), hide_index=True, use_container_width=True)
        else:
            st.info("Run the out-of-sample test in ④ for the fair ranking; below is the backtest only.")
        st.subheader("Rolling backtest (drivers chosen with all the data: optimistic for data-driven models)")
        st.dataframe(friendly(comp.sort_values(f"avg_1_{H}_pct")[cols]), hide_index=True, use_container_width=True)
        imgs = [p for p in [os.path.join(out, "comparison", "model_comparison.png"), os.path.join(out, "comparison", "scenarios.png"),
                            os.path.join(out, "oos", "oos_mape_by_horizon.png"), os.path.join(out, "oos", "holdout.png"),
                            os.path.join(out, "comparison", "regimes.png")] if os.path.exists(p)]
        for p in imgs:
            wide_image(p)
        model_details(out, comp, H)
        st.subheader("Downloads")
        c = st.columns(4)
        files = [("Tables (Excel)", os.path.join(out, "comparison", "tables.xlsx")), ("Summary", os.path.join(out, "summary.md"))]
        tr = sorted(glob.glob(os.path.join(out, "trace", "*", "trace.html")))
        if tr:
            files.append(("Run trace and data story", tr[-1]))
        oo_x = os.path.join(out, "oos", "tables.xlsx")
        if os.path.exists(oo_x):
            files.append(("Out-of-sample tables", oo_x))
        for i, (lab, p) in enumerate(files):
            if os.path.exists(p):
                c[i % 4].download_button(lab, open(p, "rb").read(), file_name=os.path.basename(p), key=f"dl{i}")

        st.subheader("Presentation")
        st.caption("The styled PowerPoint deck (methodology, literature, model comparison, recommended model, scenarios), "
                   "built from this run's results; run the out-of-sample test in ④ first for the full deck. Needs Quarto (quarto.org) on this computer; takes about half a minute.")
        sys.path.insert(0, os.path.join(HERE, "tools"))
        from make_deck import find_quarto
        cfg_now = load_config(cfg_path)
        deck = os.path.join(out, f"{cfg_now['run_name']}_deck.pptx")
        reg0 = (cfg_now.get("screen_first") or {}).get("primary_geography") or ""
        d1, d2, d3 = st.columns([3, 1, 1])
        title = d1.text_input("Title", value=f"Forecasting the {reg0} Loan Balance" if reg0 else "Forecasting the Loan Balance",
                              key="deck_title")
        region = d2.text_input("Region in the text", value=reg0, key="deck_region")
        sim = d3.checkbox("Simulated-data notes", value=False, key="deck_sim",
                          help="Adds 'results on simulated data' to every slide: for demonstrations only")
        if not find_quarto():
            st.warning("Quarto is not installed, so the deck cannot be built here. Install it from "
                       "https://quarto.org/docs/get-started/ and restart the app (or set the QUARTO environment variable to its path).")
        elif st.button("Rebuild the presentation" if os.path.exists(deck) else "Build the presentation", type="primary"):
            extra = ["--title", title, "--region", region, "--out", deck] + (["--simulated"] if sim else [])
            if run_script(os.path.join("tools", "make_deck.py"), cfg_path, extra) != 0:
                st.error("The deck could not be built: see the log above. Most often a missing package "
                         "(pip install jupyter python-pptx) or a pipeline run that has not finished.")
        if os.path.exists(deck):
            st.download_button("⬇ Download the presentation (.pptx)", open(deck, "rb").read(), file_name=os.path.basename(deck),
                               mime="application/vnd.openxmlformats-officedocument.presentationml.presentation", key="dl_deck")
        if S.get("last_log"):
            with st.expander("Log of the last run"):
                st.code(S["last_log"][-20000:], language=None)
