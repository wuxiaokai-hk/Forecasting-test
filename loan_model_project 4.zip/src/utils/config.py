"""Load the YAML configuration, fill defaults, resolve paths and check that the required names are there."""
import copy
import os

import pandas as pd
import yaml

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

DEFAULTS = {
    "run_name": "run",
    "output_dir": "outputs",
    "data": {
        "bank": {"sheet": None, "date_column": "date", "frequency": "Q"},
        "events": {"file": None, "sheet": None, "date_column": "date", "series_column": "series",
                   "amount_column": "amount"},
        "macro": {"date_column": "date", "sheet": None},
        "metadata": {"sheet": None, "columns": {"mnemonic": "mnemonic", "description": "description",
                                                "geography": "geography", "theme": "theme",
                                                "transform": "transform", "expected_sign": "expected_sign"}},
        "constructed": [],
    },
    "sample": {"horizon": 12, "report_horizons": [4, 8, 12], "dummy_quarters": [], "backtest_end": None,
               "backtest_step": 1, "reestimate_every": 4, "reestimate_quarter": 1},
    "features": {"max_lag": 4, "adf_p": 0.05, "transforms_level": ["dlog", "yoy", "dlog2", "acc", "gap"],
                 "transforms_rate": ["diff", "diff2", "diff4", "lvl", "rgap"], "real_themes": [],
                 "deflator": None, "allowed_geographies": [], "excluded_themes": [], "require_sign_prior": True},
    "approaches": ["screen_first", "en_first"],
    "screen_first": {"screen_p": 0.05, "cluster_corr": 0.75, "primary_geography": None, "rep_tolerance": 0.75,
                     "shortlist_max": 25},
    "en_first": {"l1_ratio": 0.5, "target_n": 10, "unpenalized_controls": True, "sign_constraints": True,
                 "stability": {"enabled": True, "n_subsamples": 100, "fraction": 0.75, "block_length": 8,
                               "threshold": 0.6, "seed": 42},
                 "group_corr": 0.75, "primary_geography": None, "rep_tolerance": 0.75},
    "literature": {"workbook": None, "table": None, "apply_signs_to_metadata": True, "models": [], "ecm": None,
                   "channels": "table"},
    "models": {"benchmarks": True, "literature": True, "hybrids": True, "hybrid_max_add": 2, "channel_prune_t": 1.0,
               "machine_learning": ["ridge", "random_forest", "gradient_boosting", "neural_net"],
               "machine_learning_settings": {},
               "foundation": {"enabled": "auto", "device": "cpu", "models": [
                   {"name": "Chronos-Bolt (own history)", "id": "amazon/chronos-bolt-small"},
                   {"name": "Chronos-2 (with drivers)", "id": "amazon/chronos-2", "covariates": "core"}]},
               "statistical": ["arimax", "theta"],
               "regime": {"models": ["markov", "threshold", "smooth_transition", "tvp", "break_adaptive"],
                          "threshold": "house_prices|dlog|L1", "settings": {}},
               "deep": {"enabled": "auto", "models": ["tide", "nhits", "tft"], "settings": {}}},
    "cache": {"enabled": True, "dir": "cache"},
    "docs": {"enabled": True, "folder": "docs", "examples": True},
    "trace": {"enabled": True, "folder": "trace", "preview_rows": 20, "save_tables": True, "detail_calls": 1,
              "distinct_labels": 8, "keep_runs": 10, "max_table_cells": 200000,
              "local_variables": True, "local_preview_rows": 8, "library_functions": "default", "follow": "auto"},
    "oos": {"first_origin": None, "step": 4, "horizon": None, "window": "expanding", "window_length": 40,
            "holdout_quarters": 8},
    "final_model": {"min_vars": 1, "max_vars": 3, "t_min": 1.96, "vif_max": 5.0, "one_per_theme": True,
                    "required_themes": [], "n_oos_candidates": 300, "selection_tolerance": 0.05},
}

REQUIRED = [
    ("data", "bank", "file"), ("data", "bank", "target_column"),
    ("data", "macro", "scenarios"), ("data", "macro", "base_scenario"),
    ("data", "metadata", "file"),
    ("sample", "hist_end"), ("sample", "estimation_start"), ("sample", "backtest_start"),
]


SWITCH_NOTES = []


def _fix_switches(cfg, base=None, path=()):
    """Read true/false/yes/no written where a list or a block is expected the way it is meant.

    YAML turns the words true, yes, on (and ON, the Ontario code) into True, and false, no, off into False. A switch
    written in place of a list or block (e.g. statistical: yes, deep: false) would otherwise stop the run with
    "'bool' object is not iterable". True keeps the default list or block (switched on), False switches it off.

    Args:
        cfg: merged configuration (changed in place). base: the defaults at the same level. path: keys so far.

    Returns:
        list of "path: value -> meaning" notes, for the log.
    """
    base = DEFAULTS if base is None else base
    notes = []
    for k, d in base.items():
        if k not in cfg:
            continue
        v, where = cfg[k], ".".join(path + (k,))
        if isinstance(v, bool) and isinstance(d, list):
            cfg[k] = copy.deepcopy(d) if v else []
            notes.append(f"{where}: {v} read as {'the default list ' + str(d) if v else 'switched off ([])'}")
        elif isinstance(v, bool) and isinstance(d, dict):
            cfg[k] = copy.deepcopy(d)
            if "enabled" in d:
                cfg[k]["enabled"] = v if not v else d["enabled"]
            elif "models" in d and not v:
                cfg[k]["models"] = []
            notes.append(f"{where}: {v} read as {'the default settings' if v else 'switched off'}")
        elif isinstance(v, dict) and isinstance(d, dict):
            notes += _fix_switches(v, d, path + (k,))
    return notes


def _merge(base, over):
    """Recursively merge a user config over the defaults (user values win).

    Args:
        base: defaults. over: user values.

    Returns:
        new dict.
    """
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        out[k] = _merge(out[k], v) if isinstance(v, dict) and isinstance(out.get(k), dict) else v
    return out


def _path(p):
    """Resolve a path relative to the project folder.

    Args:
        p: path or None.

    Returns:
        absolute path or None.
    """
    if p is None:
        return None
    return p if os.path.isabs(p) else os.path.join(PROJECT_ROOT, p)


def load_config(path):
    """Read a YAML config, fill defaults, check required keys and normalise values.

    Args:
        path: config file.

    Returns:
        dict (also holds out_dir and config_file).

    Raises:
        KeyError / ValueError on missing keys or invalid settings.
    """
    with open(path) as f:
        user = yaml.safe_load(f) or {}
    cfg = _merge(DEFAULTS, user)
    SWITCH_NOTES[:] = _fix_switches(cfg)             # reported by the pre-flight check
    missing = []
    for keys in REQUIRED:
        node = cfg
        for k in keys:
            node = node.get(k) if isinstance(node, dict) else None
        if node in (None, "", {}):
            missing.append(".".join(keys))
    if missing:
        raise ValueError(f"Config {path} is missing: {', '.join(missing)}")
    d = cfg["data"]
    d["bank"]["file"] = _path(d["bank"]["file"])
    d["events"]["file"] = _path(d["events"]["file"])
    d["metadata"]["file"] = _path(d["metadata"]["file"])
    d["macro"]["scenarios"] = {k: _path(v) for k, v in d["macro"]["scenarios"].items()}
    if d["macro"]["base_scenario"] not in d["macro"]["scenarios"]:
        raise ValueError(f"base_scenario '{d['macro']['base_scenario']}' is not one of the scenarios")
    for label, f in [("bank", d["bank"]["file"]), ("metadata", d["metadata"]["file"])] + \
            [(f"scenario {k}", v) for k, v in d["macro"]["scenarios"].items()]:
        if not os.path.exists(f):
            raise FileNotFoundError(f"{label} file not found: {f}")
    for k in ("hist_end", "estimation_start", "backtest_start"):
        cfg["sample"][k] = str(cfg["sample"][k])
    if cfg["sample"].get("backtest_end"):
        cfg["sample"]["backtest_end"] = str(cfg["sample"]["backtest_end"])
    for k in ("backtest_step", "reestimate_every", "reestimate_quarter"):
        cfg["sample"][k] = int(cfg["sample"][k])
    if not 1 <= cfg["sample"]["reestimate_quarter"] <= 4:
        raise ValueError("sample.reestimate_quarter must be 1, 2, 3 or 4")
    cfg["sample"]["dummy_quarters"] = [str(q) for q in cfg["sample"]["dummy_quarters"]]
    H = int(cfg["sample"]["horizon"])                      # the full horizon is always one of the comparison points
    cfg["sample"]["report_horizons"] = sorted({int(h) for h in cfg["sample"]["report_horizons"] if int(h) <= H} | {H})
    cfg["out_dir"] = os.path.join(_path(cfg["output_dir"]), cfg["run_name"])
    cfg["cache"]["dir"] = _path(cfg["cache"]["dir"])
    if cfg["literature"].get("workbook"):                  # the workbook replaces literature.models and .table
        cfg["literature"]["workbook"] = _path(cfg["literature"]["workbook"])
        if os.path.exists(cfg["literature"]["workbook"]):
            from ..models.literature import apply_settings, read_workbook
            wb = read_workbook(cfg["literature"]["workbook"], full=True)
            cfg["literature"]["models"] = wb["models"]
            cfg["literature"]["table"] = cfg["literature"]["workbook"]
            apply_settings(cfg, wb["settings"])
    if cfg["literature"].get("table"):
        cfg["literature"]["table"] = _path(cfg["literature"]["table"])
    if not cfg["oos"]["first_origin"]:                    # default: 3 years after the backtest start
        cfg["oos"]["first_origin"] = str(pd.Period(cfg["sample"]["backtest_start"], freq="Q") + 12)
    cfg["oos"]["first_origin"] = str(cfg["oos"]["first_origin"])
    if cfg["oos"]["window"] not in ("expanding", "rolling"):
        raise ValueError("oos.window must be 'expanding' or 'rolling'")
    cfg["config_file"] = os.path.abspath(path)
    return cfg
