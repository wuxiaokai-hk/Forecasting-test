"""Shared evaluation of a final model (any type): rolling backtest, diagnostics, driver table, scenario forecasts."""
import numpy as np
import pandas as pd
from statsmodels.stats.diagnostic import acorr_ljungbox, breaks_cusumolsresid, het_breuschpagan
from statsmodels.stats.stattools import durbin_watson, jarque_bera

from ..features.transforms import TR_DESC, RATE_TRS, describe, parse_feature
from .ardl import ARDL, vif
from .search import backtest_origins, covid_mask, refit_flags


def backtest(ctx, model, P):
    """Re-estimate at every origin from backtest_start, forecast 1..H quarters with realised macro values,
    and compare the cumulated balance with the organic actual balance."""
    H = ctx.cfg["sample"]["horizon"]
    start = pd.Period(ctx.cfg["sample"]["estimation_start"], freq="Q")
    origins = backtest_origins(ctx)
    E = np.full((len(origins), H), np.nan)
    coefs = []
    Ph = P.loc[:ctx.idx[ctx.end]]
    # re-estimate on the schedule in the config (sample.reestimate_every); slow models may ask for a longer
    # interval (refit_every, in quarters). Between re-estimations the coefficients are kept and only the
    # forecast is redone from the latest actual data. Every estimation uses data up to its origin only.
    every = max(int(ctx.cfg["sample"].get("reestimate_every", 1)), int(getattr(model, "refit_every", 1)))
    flags = refit_flags(ctx, origins, every)
    for i, o in enumerate(origins):
        lab = ctx.idx[o]
        if flags[i]:
            model.fit(P, start, lab)
        fc = model.forecast(Ph, lab, H)
        act = ctx.y.values[o + 1:o + 1 + len(fc)]
        E[i, :len(fc)] = np.exp(np.cumsum(fc) - np.cumsum(act)) - 1
        if getattr(model, "params", None) is not None:
            coefs.append(model.params.rename(str(lab)))
        elif getattr(model, "weights", None) is not None:
            coefs.append(pd.Series(model.weights, index=[m.name for m in model.members], name=str(lab)))
    M = covid_mask(ctx, origins, H)
    Ex = np.where(M, np.nan, E)
    by_h = pd.DataFrame({"model": model.name, "family": model.family, "horizon_q": np.arange(1, H + 1),
                         "MAPE_all_pct": np.nanmean(np.abs(E), axis=0) * 100,
                         "MAPE_exCOVID_pct": np.nanmean(np.abs(Ex), axis=0) * 100,
                         "bias_exCOVID_pct": np.nanmean(Ex, axis=0) * 100,
                         "n_origins": (~np.isnan(Ex)).sum(axis=0), "re_estimations": int(flags.sum())})
    return by_h, pd.DataFrame(coefs)


def horizon_summary(by_h, horizons, col="MAPE_exCOVID_pct", bench="AR(1) benchmark"):
    """One row per model: average error over 1..h and error at exactly h, for each h in `horizons`.

    Args:
        col: error column to summarise. bench: benchmark model for the improvement columns.
    """
    rows = []
    for (m, fam), d in by_h.groupby(["model", "family"], sort=False):
        d = d.set_index("horizon_q")[col]
        r = {"model": m, "family": fam}
        for h in horizons:
            r[f"avg_1_{h}_pct"] = d.loc[:h].mean() if h in d.index else np.nan
        for h in horizons:
            r[f"at_{h}q_pct"] = d.get(h, np.nan)
        rows.append(r)
    S = pd.DataFrame(rows)
    hmax = max(horizons)
    if bench in set(S["model"]):
        b = S.set_index("model").loc[bench]
        for h in horizons:
            S[f"vs_AR_1_{h}_pct"] = (1 - S[f"avg_1_{h}_pct"] / b[f"avg_1_{h}_pct"]) * 100
    S[f"rank_1_{hmax}"] = S[f"avg_1_{hmax}_pct"].rank(method="min").astype("Int64")
    return S


def diagnostics(ctx, model, P):
    """Residual tests of a model estimated on the full sample.

    Ljung-Box autocorrelation (4 and 8 lags), CUSUM stability, Breusch-Pagan, Jarque-Bera, maximum VIF and sign
    checks. Non-regression models get a row saying the tests do not apply.

    Args:
        ctx: Context. model: any model. P: the model's panel.

    Returns:
        dict, one row of comparison/diagnostics.
    """
    start = pd.Period(ctx.cfg["sample"]["estimation_start"], freq="Q")
    model.fit(P, start, ctx.idx[ctx.end])
    if not isinstance(model, ARDL):
        return {"model": model.name, "family": model.family, "n_obs": np.nan,
                "note": "no regression residual tests for this model type"}
    r = model.res
    e = r.resid
    lb = acorr_ljungbox(e, lags=[4, 8], return_df=True)["lb_pvalue"].values
    try:
        cus = breaks_cusumolsresid(e.values, ddof=r.model.exog.shape[1])[1]
    except Exception:
        cus = np.nan
    exog = pd.DataFrame(r.model.exog, columns=r.model.exog_names)
    feats = [f for f in model.features if f in exog]
    wrong = [f for f in feats if _expected_sign(ctx, model, f) not in (0, np.sign(r.params[f]))]
    out = {"model": model.name, "family": model.family, "n_obs": int(r.nobs), "adj_R2": round(r.rsquared_adj, 3),
           "BIC": round(r.bic, 1), "max p-value of drivers": round(max([r.pvalues[f] for f in feats] or [np.nan]), 4),
           "max VIF": round(float(np.max(vif(exog[feats].values))) if len(feats) > 1 else 1.0, 2),
           "Ljung-Box p (4)": round(lb[0], 3), "Ljung-Box p (8)": round(lb[1], 3),
           "Breusch-Pagan p": round(het_breuschpagan(e, r.model.exog)[1], 3),
           "Jarque-Bera p": round(jarque_bera(e)[1], 3), "Durbin-Watson": round(durbin_watson(e), 2),
           "CUSUM p": round(cus, 3), "wrong-sign drivers": ", ".join(wrong) or "none"}
    if hasattr(model, "eg_p"):
        out["note"] = (f"error-correction speed {r.params.get('ect_lag1', np.nan):.3f} "
                       f"(t {r.tvalues.get('ect_lag1', np.nan):.2f}); Engle-Granger ADF p = {model.eg_p:.3f}")
    return out


def driver_sensitivity(ctx, model, P, H=8):
    """How much each driver's scenario path moves the forecast: baseline path against the driver held at its last
    actual value, all else equal. Works for every model type (regressions, trees, networks).

    Args:
        ctx: Context. model: a fitted model. P: its panel (history + base scenario). H: quarters ahead.

    Returns:
        dict feature -> (effect on growth in pp per year, effect on the balance after H quarters in %).
    """
    out = {}
    end = ctx.idx[ctx.end]
    pos = P.index.get_loc(end)
    H = min(H, len(P) - pos - 1)
    if H <= 0:
        return out
    try:
        base = np.asarray(model.forecast(P, end, H))
    except Exception:
        return out
    for f in getattr(model, "features", []) or []:
        if f not in P.columns:
            continue
        P2 = P.copy()
        P2.iloc[pos + 1:, P2.columns.get_loc(f)] = P2[f].iloc[pos]
        try:
            alt = np.asarray(model.forecast(P2, end, H))
        except Exception:
            continue
        n = min(len(base), len(alt))
        out[f] = (float(np.mean(base[:n] - alt[:n]) * 400), float((np.exp(base[:n].sum() - alt[:n].sum()) - 1) * 100))
    return out


def driver_table(ctx, model, P=None):
    """How each driver enters the model, for the driver tables.

    ARDL: coefficient, Newey-West t-statistic, expected sign and long-run multiplier; ML: importance or
    standardised coefficient; combinations: member weights.

    Args:
        ctx: Context. model: an estimated model.

    Returns:
        DataFrame, one row per term.
    """
    rows = _driver_rows(ctx, model, P)
    D = pd.DataFrame(rows)
    if P is not None:                                            # scenario effect of each driver, for every model
        sens = driver_sensitivity(ctx, model, P)
        if sens:
            if "term" not in D:
                D["term"] = None
            for f in sens:
                if f not in set(D["term"]):
                    D = pd.concat([D, pd.DataFrame([{"model": model.name, "term": f, "reading": ""}])], ignore_index=True)
            D["growth_effect_pp_per_year"] = D["term"].map(lambda t: sens.get(t, (np.nan, np.nan))[0])
            D["balance_effect_pct_8q"] = D["term"].map(lambda t: sens.get(t, (np.nan, np.nan))[1])
            D["description"] = D.get("description", pd.Series(index=D.index, dtype=object))
            D["description"] = [d if isinstance(d, str) and d else _describe_term(t, ctx.meta)
                                for d, t in zip(D["description"], D["term"])]
    return D


def _expected_sign(ctx, model, f):
    """Expected sign of a driver: the model's own (literature workbook, sheet models) or the metadata's.

    Args:
        ctx: Context. model: the model. f: feature name.

    Returns:
        -1, 0 or 1.
    """
    s_ = (getattr(model, "signs", None) or {}).get(f)
    if s_ is not None:
        return int(s_)
    code = parse_feature(f)[0]
    return int(ctx.meta.loc[code, "expected_sign"]) if code in ctx.meta.index else 0


def _describe_term(t, meta):
    """Plain description of a driver-table term when it is a feature name; None for other terms (regime labels,
    member models, "long run: ...").

    Args:
        t: term. meta: variable metadata.

    Returns:
        str or None.
    """
    if not isinstance(t, str) or t.count("|") != 2 or " " in t:
        return None
    try:
        return describe(t, meta)
    except Exception:
        return None


def _driver_rows(ctx, model, P):
    """Rows of the driver table before the scenario-effect columns: coefficients, importances or weights.

    Args:
        ctx: Context. model: an estimated model. P: its panel (or None).

    Returns:
        list of dict rows.
    """
    rows = []
    if hasattr(model, "driver_rows"):                            # regime-switching models describe themselves
        return list(model.driver_rows())
    if hasattr(model, "detail_rows") and P is not None:          # ARIMAX, Theta, deep learning
        return list(model.detail_rows(ctx, P))
    if not isinstance(model, ARDL):
        if hasattr(model, "importance") and model.importance() is not None:
            imp = model.importance()
            for c, v in imp.items():
                if str(c).startswith("D_"):
                    continue
                rows.append({"model": model.name, "term": c, "coef": v,
                             "reading": ("importance in the trees" if model.kind != "ridge" else "standardised ridge coefficient")})
        elif getattr(model, "weights", None) is not None:
            for m, w in zip(model.members, model.weights):
                rows.append({"model": model.name, "term": m.name, "coef": w,
                             "reading": f"weight {w:.0%}; drivers {', '.join(m.drivers()) or '(none)'}"})
        else:
            rows.append({"model": model.name, "term": ", ".join(model.drivers()), "reading": model.note or ""})
        return rows
    r = model.res
    rho = r.params.get("y_lag1", 0.0)
    for c in r.params.index:
        if c == "const" or c.startswith("D_"):
            continue
        b = r.params[c]
        row = {"model": model.name, "term": c, "coef": b, "se_hac": r.bse[c], "t": r.tvalues[c], "p": r.pvalues[c]}
        if c.count("|") == 2:
            es = _expected_sign(ctx, model, c)
            row["expected_sign"] = es
            row["sign_ok"] = "no rule" if es == 0 else ("yes" if np.sign(b) == es else "no")
        if c == "y_lag1":
            row.update(description="Loan growth last quarter (momentum)",
                       reading=f"{b:.2f} of last quarter's growth carries into this quarter")
        elif c == "ect_lag1":
            row.update(description="Gap between loans and their long-run level, last quarter",
                       reading=f"{abs(b):.1%} of the gap to the long-run level closes each quarter" if b < 0
                       else "no pull back to the long-run level (wrong sign)")
        else:
            code, tr, lag = parse_feature(c)
            per_unit = b * (1 if tr in RATE_TRS else 0.01) * 100
            unit = "1 pp" if tr in RATE_TRS else "1%"
            when = "in the same quarter" if lag == 0 else f"{lag} quarter{'s' if lag > 1 else ''} later"
            lr = f"; long-run effect {abs(per_unit) / (1 - rho):.3f} pp" if rho < 1 else ""
            row.update(description=describe(c, ctx.meta),
                       reading=(f"A {unit} rise in {ctx.meta.loc[code, 'description']} [{TR_DESC.get(tr, tr)}] "
                                f"{'raises' if b > 0 else 'lowers'} q/q loan growth by {abs(per_unit):.3f} pp {when}{lr}"))
        rows.append(row)
    if getattr(model, "beta", None) is not None and hasattr(model, "lr_names"):    # ECM: the long-run relation
        rows.append({"model": model.name, "term": "long run: constant", "coef": float(model.beta[0]),
                     "reading": "long-run relation of the real loan level (Engle-Granger step 1)"})
        for n, b in zip(model.lr_names, model.beta[1:]):
            rows.append({"model": model.name, "term": f"long run: {n[3:]}", "coef": float(b),
                         "reading": f"a 1% higher {n[3:].split(':')[0]} goes with a {b:.2f}% higher real loan level in the long run"
                         if n.endswith(("log", "log_real")) else "long-run coefficient"})
    return rows


def scenario_forecasts(ctx, model):
    """Forecast every Moody's scenario with the model estimated on all history.

    Args:
        ctx: Context (ctx.macro holds the scenarios). model: any model.

    Returns:
        long DataFrame: model, family, scenario, date, dlog_forecast, balance_forecast.
    """
    start = pd.Period(ctx.cfg["sample"]["estimation_start"], freq="Q")
    last = ctx.level.iloc[-1]
    out = []
    for name, mdf in ctx.macro.items():
        P = model.panel(ctx, mdf)
        model.fit(P, start, ctx.idx[ctx.end])
        fc = model.forecast(P, ctx.idx[ctx.end], len(P))
        dates = P.index[P.index.get_loc(ctx.idx[ctx.end]) + 1:][:len(fc)]
        lvl = last * np.exp(np.cumsum(fc))
        out += [{"model": model.name, "family": model.family, "scenario": name, "date": str(d), "dlog_forecast": f,
                 "balance_forecast": l} for d, f, l in zip(dates, fc, lvl)]
    return pd.DataFrame(out)


def evaluate(ctx, model):
    """Everything the comparison needs for one model: backtest, diagnostics, drivers, scenarios.

    Args:
        ctx: Context. model: any model following the model interface.

    Returns:
        dict with by_horizon, coef_path, diagnostics, drivers and scenarios (DataFrames / dict).
    """
    P = model.panel(ctx, ctx.base)
    by_h, coef_path = backtest(ctx, model, P)
    diag = diagnostics(ctx, model, P)
    drivers = driver_table(ctx, model, P)
    scen = scenario_forecasts(ctx, model)
    out = {"by_horizon": by_h, "coef_path": coef_path, "diagnostics": diag, "drivers": drivers, "scenarios": scen}
    if hasattr(model, "regime_path"):                         # regime-switching models: regime over history
        out["regimes"] = regime_history(ctx, model, P)
    return out


def regime_history(ctx, model, P):
    """The regime indicator of a regime-switching model over history, estimated on all data.

    Args:
        ctx: Context. model: a model with regime_path(). P: its panel on the history.

    Returns:
        DataFrame: model, family, date, value, meaning.
    """
    start = pd.Period(ctx.cfg["sample"]["estimation_start"], freq="Q")
    model.fit(P, start, ctx.idx[ctx.end])
    r = model.regime_path(P).loc[:ctx.idx[ctx.end]].dropna()
    return pd.DataFrame({"model": model.name, "family": model.family, "date": r.index.astype(str), "value": r.values,
                         "meaning": getattr(model, "regime_label", "")})
