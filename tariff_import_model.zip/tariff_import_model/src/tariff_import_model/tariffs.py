"""Tariff measures -> effective quarterly tariff by sector and source.

Two ways to describe the tariff shock:

1. `measures` table (sector level, quick): one row per measure x sector x source
   with a statutory rate, the share of that sector-source import value covered,
   a remission share, and start/end dates.
2. HS-level build (preferred, mirrors the Bank of Canada method of weighting each
   announced tariff by the product's 2024 trade share): use
   `build_measures_from_hs` with the Finance Canada counter-tariff HS lists and
   CIMT HS-level import values to compute coverage and average rates per sector.
"""
from __future__ import annotations

import pandas as pd


def quarter_range(start: str, end: str) -> list[str]:
    return [str(p) for p in pd.period_range(pd.Period(start, "Q"), pd.Period(end, "Q"), freq="Q")]


def _active_fraction(q: str, start: pd.Timestamp, end: pd.Timestamp | None) -> float:
    per = pd.Period(q, "Q")
    q0, q1 = per.start_time.normalize(), per.end_time.normalize() + pd.Timedelta(days=1)
    lo = max(q0, start)
    hi = q1 if end is None or pd.isna(end) else min(q1, end)
    days = (hi - lo).days
    return max(0.0, days / (q1 - q0).days)


def effective_tariffs(measures: pd.DataFrame, quarters: list[str]) -> pd.DataFrame:
    """Quarterly effective tariff tau by sector and source.

    tau = sum_measures rate x coverage x (1 - remission) x share of quarter active.
    `end` is the first day the measure no longer applies (blank = still in force).
    """
    m = measures.copy()
    m["start"] = pd.to_datetime(m["start"])
    m["end"] = pd.to_datetime(m["end"]) if "end" in m else pd.NaT
    m["remission_share"] = m.get("remission_share", 0.0)
    m["remission_share"] = m["remission_share"].fillna(0.0)
    rows = []
    for q in quarters:
        for _, r in m.iterrows():
            f = _active_fraction(q, r["start"], r["end"])
            if f <= 0:
                continue
            tau = r["rate"] * r["coverage_share"] * (1 - r["remission_share"]) * f
            rows.append({"quarter": q, "sector": r["sector"], "source": r["source"],
                         "measure_id": r["measure_id"], "tau": tau})
    detail = pd.DataFrame(rows, columns=["quarter", "sector", "source", "measure_id", "tau"])
    return detail.groupby(["quarter", "sector", "source"], as_index=False)["tau"].sum()


def average_tariff_rate(tau: pd.DataFrame, baseline: pd.DataFrame, source: str = "US") -> pd.Series:
    """Trade-weighted average tariff on imports from `source` by quarter (%),
    using baseline values as weights (BoC MPR convention: fixed 2024 weights)."""
    b = baseline[baseline["source"] == source][["sector", "value"]]
    t = tau[tau["source"] == source].merge(b, on="sector", how="right")
    t["tau"] = t["tau"].fillna(0.0)
    tot = b["value"].sum()
    return t.groupby("quarter").apply(lambda d: 100 * (d["tau"] * d["value"]).sum() / tot,
                                      include_groups=False)


def build_measures_from_hs(
    hs_list: pd.DataFrame,
    hs_imports: pd.DataFrame,
    concordance: pd.DataFrame,
    measures_meta: pd.DataFrame,
    hs_digits: int = 6,
) -> pd.DataFrame:
    """Aggregate an HS-level counter-tariff list into sector-level measures.

    hs_list       : [measure_id, hs, rate]           (Finance Canada schedules)
    hs_imports    : [hs, source, value]              (CIMT, baseline year, e.g. 2024)
    concordance   : [hs_prefix, sector]              (longest prefix wins)
    measures_meta : [measure_id, source, start, end, remission_share, reference]

    Output rows: measure_id, sector, source, rate (value-weighted over covered
    lines), coverage_share (covered value / sector-source value), dates, ...
    """
    def norm(x):
        return x.astype(str).str.replace(r"\D", "", regex=True).str[:hs_digits]

    hs_list = hs_list.assign(hs=norm(hs_list["hs"]))
    hs_imports = hs_imports.assign(hs=norm(hs_imports["hs"]))
    hs_imports = hs_imports.groupby(["hs", "source"], as_index=False)["value"].sum()

    conc = concordance.assign(hs_prefix=concordance["hs_prefix"].astype(str))
    conc = conc.sort_values("hs_prefix", key=lambda s: s.str.len(), ascending=False)

    def to_sector(code: str) -> str:
        for pre, sec in zip(conc["hs_prefix"], conc["sector"]):
            if code.startswith(pre):
                return sec
        return "other"

    hs_imports["sector"] = hs_imports["hs"].map(to_sector)
    sector_tot = hs_imports.groupby(["sector", "source"])["value"].sum().rename("sector_value")

    lst = hs_list.groupby(["measure_id", "hs"], as_index=False)["rate"].max()
    lst = lst.merge(measures_meta[["measure_id", "source"]], on="measure_id")
    cov = lst.merge(hs_imports, on=["hs", "source"], how="left").fillna({"value": 0.0})
    cov["rate_x_value"] = cov["rate"] * cov["value"]
    agg = cov.groupby(["measure_id", "sector", "source"], as_index=False)[["value", "rate_x_value"]].sum()
    agg = agg.merge(sector_tot.reset_index(), on=["sector", "source"])
    agg["coverage_share"] = agg["value"] / agg["sector_value"]
    agg["rate"] = agg["rate_x_value"] / agg["value"].where(agg["value"] > 0)
    agg = agg.dropna(subset=["rate"])
    meta_cols = [c for c in measures_meta.columns if c != "source"]
    return agg[["measure_id", "sector", "source", "rate", "coverage_share"]].merge(
        measures_meta[meta_cols], on="measure_id")
