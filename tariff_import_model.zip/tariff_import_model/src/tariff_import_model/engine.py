"""Core import-adjustment engine.

Two-tier nested CES (Armington) import demand with an activity channel and
partial adjustment, applied sector by sector.

Notation (sector s, source j, quarter t; hats are log deviations from baseline)
---------------------------------------------------------------------------
tau_sjt   effective ad-valorem tariff = statutory rate x coverage x (1 - remission)
phi_s     pass-through of the tariff into the tariff-inclusive landed price
p_sjt     landed price index of source j:   ln p = ln(1 + phi*tau) + io_price + pref
w_sj      baseline source share of sector-s imports (customs value)
sigma_s   elasticity of substitution between import sources (lower nest)
eta_s     elasticity of substitution domestic vs imported composite (upper nest)
omega_s   baseline import penetration (imports / domestic absorption) of sector s
alpha_s   elasticity of real imports to import-weighted final demand (activity)
lambda_s  quarterly partial-adjustment speed toward the long-run target

Lower nest  : P_M   = (sum_j w_j p_j^(1-sigma))^(1/(1-sigma))
              m_j/M = w_j (p_j / P_M)^(-sigma)
Upper nest  : P     = (omega P_M^(1-eta) + (1-omega) P_D^(1-eta))^(1/(1-eta))
              M     = omega * D * (P_M / P)^(-eta)
Activity    : ln D  = alpha * activity_dev
Dynamics    : x_t   = x_{t-1} + lambda (x*_t - x_{t-1})   (in logs, per source)
Customs val.: v_j   = m_j * (1 - (1-phi)*tau_j)  (foreign exporter absorbs 1-phi)
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass
class SectorParams:
    sigma: float          # between-source elasticity
    eta: float            # domestic vs import elasticity
    omega: float          # baseline import penetration (0-1)
    alpha: float          # activity elasticity
    phi: float            # tariff pass-through to landed price (0-1)
    lam: float            # partial-adjustment speed per quarter (0-1]


def _ces_index(shares: np.ndarray, prices: np.ndarray, elast: float) -> float:
    """CES price index normalised to 1 at baseline prices of 1."""
    if abs(elast - 1.0) < 1e-9:  # Cobb-Douglas limit
        return float(np.exp(np.sum(shares * np.log(prices))))
    return float(np.sum(shares * prices ** (1.0 - elast)) ** (1.0 / (1.0 - elast)))


def long_run_target(
    w: np.ndarray,
    tau: np.ndarray,
    prm: SectorParams,
    activity_dev: float = 0.0,
    io_price: np.ndarray | None = None,
    pref_shift: np.ndarray | None = None,
    domestic_price: float = 0.0,
) -> dict:
    """Static (fully adjusted) response of one sector in one quarter.

    Returns log-deviation of quantity by source, sector totals and price indexes.
    `io_price` is an optional log price effect by source (e.g. from the IO
    tariff_price_model); `pref_shift` is an optional log demand shifter by source
    expressed as a price-equivalent (positive = less demand, e.g. Buy-Canadian).
    `domestic_price` is the log change of the domestic competing price.
    """
    n = len(w)
    io_price = np.zeros(n) if io_price is None else np.asarray(io_price, float)
    pref_shift = np.zeros(n) if pref_shift is None else np.asarray(pref_shift, float)

    ln_p = np.log1p(prm.phi * tau) + io_price + pref_shift
    p = np.exp(ln_p)
    P_M = _ces_index(w, p, prm.sigma)
    P_D = np.exp(domestic_price)
    P = _ces_index(np.array([prm.omega, 1 - prm.omega]), np.array([P_M, P_D]), prm.eta)

    ln_D = prm.alpha * activity_dev
    ln_M = ln_D - prm.eta * (np.log(P_M) - np.log(P))           # total imports
    ln_share = -prm.sigma * (ln_p - np.log(P_M))                  # m_j/M vs baseline share
    ln_m = ln_M + ln_share                                        # quantity by source
    return {"ln_m": ln_m, "ln_M": ln_M, "ln_PM": np.log(P_M), "ln_p": ln_p}


def simulate(
    baseline: pd.DataFrame,
    params: dict[str, SectorParams],
    tariffs: pd.DataFrame,
    activity: pd.Series,
    io_price: pd.DataFrame | None = None,
    pref_shift: pd.DataFrame | None = None,
) -> pd.DataFrame:
    """Run the dynamic simulation.

    baseline : columns [sector, source, value]  (baseline annual customs value)
    tariffs  : columns [quarter, sector, source, tau]  effective tariff (decimal)
    activity : index quarter -> % deviation of import-weighted demand (decimal log)
    io_price / pref_shift : optional long tables [quarter, sector, source, value]

    Returns a long table by quarter, sector, source with quantity and customs
    value deviations (%, log*100) plus levels at the baseline quarterly run-rate.
    """
    quarters = list(activity.index)
    out = []
    for sector, grp in baseline.groupby("sector", sort=False):
        grp = grp.reset_index(drop=True)
        sources = grp["source"].tolist()
        w = (grp["value"] / grp["value"].sum()).to_numpy()
        prm = params[sector]
        x_prev = np.zeros(len(sources))  # log quantity deviation, starts at baseline

        def _lookup(tbl, q, col):
            if tbl is None:
                return np.zeros(len(sources))
            sub = tbl[(tbl["quarter"] == q) & (tbl["sector"] == sector)].set_index("source")[col]
            return np.array([float(sub.get(s, 0.0)) for s in sources])

        for q in quarters:
            tau = _lookup(tariffs, q, "tau")
            tgt = long_run_target(
                w, tau, prm,
                activity_dev=float(activity.loc[q]),
                io_price=_lookup(io_price, q, "value"),
                pref_shift=_lookup(pref_shift, q, "value"),
            )
            x = x_prev + prm.lam * (tgt["ln_m"] - x_prev)
            x_prev = x
            base_q = grp["value"].to_numpy() / 4.0
            qty_level = base_q * np.exp(x)
            customs_level = qty_level * (1.0 - (1.0 - prm.phi) * tau)
            for k, s in enumerate(sources):
                out.append({
                    "quarter": q, "sector": sector, "source": s,
                    "tau": tau[k],
                    "landed_price_pct": 100 * tgt["ln_p"][k],
                    "target_qty_pct": 100 * tgt["ln_m"][k],
                    "qty_pct": 100 * x[k],
                    "baseline_value": base_q[k],
                    "real_imports": qty_level[k],
                    "customs_value": customs_level[k],
                })
    res = pd.DataFrame(out)
    res["customs_value_pct"] = 100 * np.log(res["customs_value"] / res["baseline_value"])
    return res


def aggregate(res: pd.DataFrame, by: list[str]) -> pd.DataFrame:
    """Aggregate levels and recompute % deviations (log*100) and source shares."""
    g = res.groupby(by, sort=False)[["baseline_value", "real_imports", "customs_value"]].sum()
    g["real_pct"] = 100 * np.log(g["real_imports"] / g["baseline_value"])
    g["customs_pct"] = 100 * np.log(g["customs_value"] / g["baseline_value"])
    return g.reset_index()


def source_shares(res: pd.DataFrame, sector_filter: list[str] | None = None) -> pd.DataFrame:
    """Source shares of customs value by quarter (and baseline), in %."""
    df = res if sector_filter is None else res[res["sector"].isin(sector_filter)]
    g = df.groupby(["quarter", "source"])[["baseline_value", "customs_value"]].sum()
    tot = g.groupby(level="quarter").transform("sum")
    sh = 100 * g / tot
    sh.columns = ["baseline_share", "share"]
    sh["share_change_pp"] = sh["share"] - sh["baseline_share"]
    return sh.reset_index()
