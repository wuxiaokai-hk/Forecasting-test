"""Command-line runner: python -m tariff_import_model.run config/scenario.yaml"""
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd
import yaml

from .engine import SectorParams, aggregate, simulate, source_shares
from .tariffs import average_tariff_rate, effective_tariffs, quarter_range


def load_scenario(cfg_path: str | Path):
    cfg_path = Path(cfg_path)
    cfg = yaml.safe_load(cfg_path.read_text())
    root = cfg_path.parent.parent  # project root (config/ sits under it)

    def rd(key):
        p = cfg["inputs"].get(key)
        return None if p is None else pd.read_csv(root / p)

    baseline = rd("baseline")
    el = rd("elasticities").set_index("sector")
    params = {s: SectorParams(sigma=r.sigma, eta=r.eta, omega=r.omega, alpha=r.alpha,
                              phi=r.phi, lam=r.lam) for s, r in el.iterrows()}
    quarters = quarter_range(cfg["horizon"]["start"], cfg["horizon"]["end"])
    measures = rd("measures")
    if "enabled_measures" in cfg:
        measures = measures[measures["measure_id"].isin(cfg["enabled_measures"])]
    tau = effective_tariffs(measures, quarters)

    act = rd("activity")
    activity = (act.set_index("quarter")["import_weighted_demand_pct"] / 100.0).reindex(quarters).fillna(0.0)
    io_price = rd("io_price")
    pref = rd("preference_shift")
    return cfg, baseline, params, tau, activity, io_price, pref, measures


def run(cfg_path: str | Path) -> Path:
    cfg, baseline, params, tau, activity, io_price, pref, measures = load_scenario(cfg_path)
    res = simulate(baseline, params, tau, activity, io_price=io_price, pref_shift=pref)

    total = aggregate(res, ["quarter"])
    by_sector = aggregate(res, ["quarter", "sector"])
    by_source = aggregate(res, ["quarter", "source"])
    us_share_all = source_shares(res)
    tariffed = sorted(tau.loc[tau["tau"] > 0, "sector"].unique())
    us_share_tariffed = source_shares(res, tariffed)
    avg = average_tariff_rate(tau, baseline).rename("avg_cdn_tariff_on_US_pct").reset_index()

    out_dir = Path(cfg_path).parent.parent / cfg.get("output_dir", "output")
    out_dir.mkdir(exist_ok=True)
    out = out_dir / f"{cfg['name']}.xlsx"
    with pd.ExcelWriter(out) as xw:
        total.to_excel(xw, "total", index=False)
        by_source.to_excel(xw, "by_source", index=False)
        by_sector.to_excel(xw, "by_sector", index=False)
        us_share_all.to_excel(xw, "source_shares_all", index=False)
        us_share_tariffed.to_excel(xw, "source_shares_tariffed", index=False)
        avg.to_excel(xw, "avg_tariff_check", index=False)
        tau.to_excel(xw, "effective_tariffs", index=False)
        res.to_excel(xw, "detail", index=False)
        pd.DataFrame([{"sector": s, **vars(p)} for s, p in params.items()]).to_excel(xw, "params", index=False)
        measures.to_excel(xw, "measures", index=False)
    res.to_csv(out_dir / f"{cfg['name']}_detail.csv", index=False)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("config")
    a = ap.parse_args()
    print(f"Wrote {run(a.config)}")


if __name__ == "__main__":
    main()
