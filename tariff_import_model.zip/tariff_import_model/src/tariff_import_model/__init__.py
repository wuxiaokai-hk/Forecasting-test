"""Tariff import adjustment model for Canada (nested-CES Armington with activity
channel and partial adjustment). See README.md and docs/REFERENCES.md."""
from .engine import SectorParams, aggregate, long_run_target, simulate, source_shares
from .tariffs import average_tariff_rate, build_measures_from_hs, effective_tariffs, quarter_range

__all__ = ["SectorParams", "aggregate", "long_run_target", "simulate", "source_shares",
           "average_tariff_rate", "build_measures_from_hs", "effective_tariffs", "quarter_range"]
