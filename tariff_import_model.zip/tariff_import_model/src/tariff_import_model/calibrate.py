"""Calibrate the between-source elasticity and adjustment speed to observed
reallocation (e.g. the 2025 counter-tariff episode).

Target: change in the US share of import value in tariffed sectors versus the
baseline year. The Bank of Canada (MPR Jan 2026, In focus) reports that about
80% of the 2025 decline in the US import share came from counter-tariff sectors
and that the shift partly reversed once most counter-tariffs were lifted on
1 Sept 2025 -- a natural out-of-sample check for lambda.
"""
from __future__ import annotations

import itertools
from dataclasses import replace

import numpy as np
import pandas as pd

from .engine import SectorParams, simulate, source_shares


def observed_us_share_change(observed: pd.DataFrame, baseline: pd.DataFrame,
                             sectors: list[str], source: str = "US") -> pd.Series:
    """observed: [quarter, sector, source, value] (quarterly customs value)."""
    o = observed[observed["sector"].isin(sectors)]
    sh = o.groupby(["quarter", "source"])["value"].sum().unstack("source")
    sh = 100 * sh[source] / sh.sum(axis=1)
    b = baseline[baseline["sector"].isin(sectors)]
    base = 100 * b.loc[b["source"] == source, "value"].sum() / b["value"].sum()
    return sh - base


def grid_calibrate(baseline, params: dict[str, SectorParams], tariffs, activity,
                   observed, sectors, sigma_scales=np.arange(0.5, 2.51, 0.25),
                   lams=np.arange(0.15, 0.91, 0.05), source="US", pref_shift=None):
    """Scale every sector's sigma by a common factor and pick one lambda for all
    sectors, minimising squared error on the US-share change (pp)."""
    target = observed_us_share_change(observed, baseline, sectors, source)
    rows = []
    for k, lam in itertools.product(sigma_scales, lams):
        p2 = {s: replace(p, sigma=p.sigma * k, lam=lam) for s, p in params.items()}
        res = simulate(baseline[baseline["sector"].isin(sectors)], p2, tariffs, activity,
                       pref_shift=pref_shift)
        sim = source_shares(res).query("source == @source").set_index("quarter")["share_change_pp"]
        common = target.index.intersection(sim.index)
        err = float(np.mean((sim.loc[common] - target.loc[common]) ** 2))
        rows.append({"sigma_scale": k, "lam": lam, "mse": err, "n_obs": len(common)})
    grid = pd.DataFrame(rows).sort_values("mse")
    return grid.iloc[0].to_dict(), grid
