import numpy as np
import pandas as pd
import pytest

from tariff_import_model import SectorParams, build_measures_from_hs, effective_tariffs, simulate
from tariff_import_model.calibrate import grid_calibrate


def test_hs_build_coverage_and_rate():
    hs_list = pd.DataFrame({"measure_id": ["m", "m"], "hs": ["7208.10", "9401.20"], "rate": [0.5, 0.25]})
    hs_imp = pd.DataFrame({"hs": ["720810", "720900", "940120", "940300"],
                           "source": ["US"] * 4, "value": [30, 70, 10, 30]})
    conc = pd.DataFrame({"hs_prefix": ["72", "94"], "sector": ["steel", "furn"]})
    meta = pd.DataFrame({"measure_id": ["m"], "source": ["US"], "start": ["2026-09-08"],
                         "end": [None], "remission_share": [0.0]})
    out = build_measures_from_hs(hs_list, hs_imp, conc, meta).set_index("sector")
    assert out.loc["steel", "coverage_share"] == pytest.approx(0.3)
    assert out.loc["furn", "coverage_share"] == pytest.approx(0.25)
    assert out.loc["steel", "rate"] == pytest.approx(0.5)


def test_calibration_recovers_known_parameters():
    base = pd.DataFrame({"sector": ["s", "s"], "source": ["US", "ROW"], "value": [60.0, 40.0]})
    q = [str(p) for p in pd.period_range("2025Q1", "2026Q4", freq="Q")]
    m = pd.DataFrame([{"measure_id": "x", "sector": "s", "source": "US", "rate": 0.25,
                       "coverage_share": 0.6, "remission_share": 0.0, "start": "2025-03-04", "end": "2025-09-01"}])
    tau = effective_tariffs(m, q)
    act = pd.Series(0.0, index=q)
    true = {"s": SectorParams(sigma=6.0, eta=1.0, omega=0.4, alpha=1.5, phi=1.0, lam=0.5)}
    sim = simulate(base, true, tau, act)
    observed = sim.rename(columns={"customs_value": "value"})[["quarter", "sector", "source", "value"]]
    start = {"s": SectorParams(sigma=4.0, eta=1.0, omega=0.4, alpha=1.5, phi=1.0, lam=0.3)}
    best, _ = grid_calibrate(base, start, tau, act, observed, ["s"])
    assert best["sigma_scale"] == pytest.approx(1.5)
    assert best["lam"] == pytest.approx(0.5)
