import numpy as np
import pandas as pd
import pytest

from tariff_import_model import SectorParams, effective_tariffs, long_run_target, simulate

P = SectorParams(sigma=4.0, eta=1.0, omega=0.5, alpha=1.5, phi=1.0, lam=1.0)
W = np.array([0.6, 0.4])  # US, ROW


def test_no_shock_no_change():
    r = long_run_target(W, np.zeros(2), P)
    assert np.allclose(r["ln_m"], 0.0)


def test_tariff_on_us_diverts_to_row():
    r = long_run_target(W, np.array([0.25, 0.0]), P)
    assert r["ln_m"][0] < 0 < r["ln_m"][1]          # trade diversion
    assert r["ln_M"] < 0                              # total imports fall


def test_uniform_tariff_only_upper_nest():
    tau = 0.10
    r = long_run_target(W, np.array([tau, tau]), P)
    # equal tariffs leave source mix unchanged
    assert np.allclose(r["ln_m"][0], r["ln_m"][1])
    # eta=1, omega=.5: ln M = -eta*(1-omega)*ln(1+tau)
    assert r["ln_M"] == pytest.approx(-(1 - P.omega) * np.log1p(tau))


def test_activity_channel():
    r = long_run_target(W, np.zeros(2), P, activity_dev=-0.02)
    assert np.allclose(r["ln_m"], 1.5 * -0.02)


def test_partial_adjustment_converges():
    base = pd.DataFrame({"sector": ["s", "s"], "source": ["US", "ROW"], "value": [60.0, 40.0]})
    q = [str(p) for p in pd.period_range("2025Q1", "2030Q4", freq="Q")]
    tau = pd.DataFrame({"quarter": q, "sector": "s", "source": "US", "tau": 0.25})
    prm = {"s": SectorParams(4.0, 1.0, 0.5, 1.5, 1.0, 0.35)}
    res = simulate(base, prm, tau, pd.Series(0.0, index=q))
    us = res[res.source == "US"].set_index("quarter")
    assert us["qty_pct"].iloc[0] == pytest.approx(0.35 * us["target_qty_pct"].iloc[0])
    assert us["qty_pct"].iloc[-1] == pytest.approx(us["target_qty_pct"].iloc[-1], rel=1e-3)


def test_effective_tariff_partial_quarter():
    m = pd.DataFrame([{"measure_id": "x", "sector": "s", "source": "US", "rate": 0.5,
                       "coverage_share": 0.5, "remission_share": 0.0,
                       "start": "2026-09-08", "end": None}])
    t = effective_tariffs(m, ["2026Q3", "2026Q4"]).set_index("quarter")["tau"]
    assert t["2026Q4"] == pytest.approx(0.25)
    assert 0 < t["2026Q3"] < 0.25 * 0.3  # ~23 of 92 days active
