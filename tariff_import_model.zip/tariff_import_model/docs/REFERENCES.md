# References — what each one is used for

Every parameter and design choice in the model is tied to a source below. Entries marked **[verify]** were not re-checked against the paper during the build. Confirm the exact number from the published table before you cite it.

## A. Policy facts: the tariff shock

| # | Source | Used for |
|---|--------|----------|
| A1 | Bank of Canada, *MPR October 2026*, "Tariff and other assumptions". https://www.bankofcanada.ca/?p=256178 | **Calibration target.** Average Canadian tariff on US goods is **3.9%** and the average US tariff on Canada is 7.5%. Both include remissions and the post-August-2026 measures. Compare with `avg_tariff_check` in the output. |
| A2 | Bank of Canada, *MPR October 2025*, Box "How the average tariff rates are calculated". https://www.bankofcanada.ca/publications/mpr/mpr-2025-10-29/section-8/ | **Method.** Each tariff is weighted by its product's 2024 trade share, and remissions are netted out. Without remissions the rate was 2.4% instead of 1.0%. `tariffs.build_measures_from_hs` and `average_tariff_rate` follow this method. |
| A3 | Bank of Canada, *MPR January 2026*, In focus "How Canadian businesses are adapting to US tariffs". https://www.bankofcanada.ca/publications/mpr/mpr-2026-01-28/in-focus-1/ | **Empirical targets.** About 80% of the fall in the US import share came from sectors with counter-tariffs. Part of the shift reversed after the September 2025 repeal. In 2024 about a quarter of non-US imports were routed through the US, and that share has since fallen. The rest of the decline is attributed to "Buy Canadian" sentiment and supplier diversification, which is what the `preference_shift` input represents. |
| A4 | Bank of Canada, *MPR April 2026*, Tariff assumptions. https://www.bankofcanada.ca/publications/mpr/mpr-2026-04-29/section-8/ | Three-quarters of tariff costs pass through to consumer prices within six quarters. This is the consumer-price link to your `tariff_price_model`. It also documents the end of some steel remissions on 31 Jan 2026. |
| A5 | Finance Canada / CBSA: *United States Surtax Order (2025-1)* SOR/2025-66 (repealed 1 Sep 2025); *Steel and Aluminum 2025* SOR/2025-95 (CN 25-11); *Motor Vehicles 2025* (CN 25-15). Summaries: EY Tax Alert 19 Sep 2025; KPMG 15 Sep 2025 | Dates, rates and coverage of the 2025 measures (`CA2025_*` rows). |
| A6 | Finance Canada, "List of products from the United States subject to counter-tariffs effective September 8, 2026" (canada.ca). Summaries: EY 28 Aug 2026; Baker McKenzie 26 Aug 2026; Covington Aug 2026 | The 15%, 25% and 50% list covering about C$27.6B of US goods. It matches the US s.338 tariffs rate for rate. Goods already in transit are exempt. These are the `CA2026_*` rows. **Load the HS list itself to replace the illustrative coverage shares.** |
| A7 | US Section 338 proclamations, 20 Jul 2026 (in force 22 Aug 2026). PwC Tax Insights 2026-26R; Dorsey client alert 27 Aug 2026 | The trigger for the 2026 escalation. CUSMA status does not exempt goods from these tariffs. Relevant to the export side and to the activity path. |

## B. Structural parameters

| # | Source | Parameter |
|---|--------|-----------|
| B1 | Fontagné, Guimbard & Orefice (2022), "Tariff-based product-level trade elasticities," *J. Int. Econ.* 137, 103593. Data: https://sites.google.com/view/product-level-trade-elasticity | **σ (between sources).** HS6 elasticities estimated from bilateral tariff variation over 2001–2016, centred around −6. Downloadable in the **GTAP 10/11 classification**, including a final vs intermediate split. Map GTAP sectors to model sectors and take the import-weighted median. |
| B2 | Fajgelbaum, Goldberg, Kennedy & Khandelwal (2020), "The Return to Protectionism," *QJE* 135(1): 1–55 | **Nesting structure** (variety, product, sector; imports vs domestic). **φ ≈ 1**: complete pass-through of tariffs into tariff-inclusive import prices. Imports of targeted varieties fell about 31.5%. Variety-level σ is about 2.5 **[verify]**. Use it as the short-run lower bound. |
| B3 | Amiti, Redding & Weinstein (2019), "The Impact of the 2018 Tariffs on Prices and Welfare," *J. Econ. Perspectives* 33(4) **[verify]** | A second source for complete pass-through (φ = 1). |
| B4 | Feenstra, Luck, Obstfeld & Russ (2018), "In Search of the Armington Elasticity," *Rev. Econ. Stat.* 100(1) **[verify]** | **η (domestic vs import) ≈ 1**. The macro elasticity is well below the micro (between-source) one. This is why the model uses two nests, with η < σ. |
| B5 | Amano & Wirjanto (1994), "The Dynamic Behaviour of Canadian Imports and the Linear-Quadratic Model," BoC SWP 94-6 | **α ≈ 1.5** (long-run activity elasticity). The aggregate relative-price elasticity is ≈ −0.5, which is a sanity check on η×(1−ω). Adjustment costs are 9–13 times disequilibrium costs, so imports adjust gradually. This supports **λ < 1**. |
| B6 | Bussière, Gaulier & Steingress (2020), "Global Trade Flows: Revisiting the Exchange Rate Elasticities," BoC SWP 2017-41 | Aggregate quantity elasticities are below 1. A cross-check on η and the aggregate response. |
| B7 | Lam (2025), "Assessing tariff pass-through to consumer prices in Canada: Lessons from 2018," BoC SAN 2025-18 | Canadian evidence on how far tariffs pass through to retail prices. Use it for the CPI link, not for φ at the border. |

## C. Diversion, transshipment, and general-equilibrium benchmarks

| # | Source | Used for |
|---|--------|----------|
| C1 | Fajgelbaum, Goldberg, Kennedy, Khandelwal & Taglioni (2024), "The US-China Trade War and Global Reallocations," *AER: Insights* 6(2): 295–312 | Supports the trade-diversion channel: bystanders gained share in the targeted products. It also explains why non-US supply can be elastic or even downward sloping, which justifies a high σ. |
| C2 | Charbonneau & Landry (2018), "The Trade War in Numbers," BoC SWP 2018-57; Charbonneau (2019), BoC SAN 2019-20 | A Caliendo–Parro long-run GE benchmark. Trade effects are large while GDP effects are small. Use it to cross-check the long-run (λ→1) results. |

## D. Data

| Table | Use |
|-------|-----|
| StatCan **12-10-0011-01**: merchandise trade by principal trading partner, monthly, SA, customs and BOP basis | Aggregate check of US and non-US imports |
| StatCan **12-10-0178-01**: imports by **country of origin and country of export**, monthly | Origin is what the counter-tariffs apply to. Export country captures the US-routed transshipment noted in A3. |
| StatCan **12-10-0099-01**: imports by HS section, monthly | Sector baseline |
| StatCan CIMT online database (HS8/HS10 by country) | Input to `build_measures_from_hs` (coverage shares) and to the 2025 calibration (`calibrate.grid_calibrate`) |
| BoC Valet series `MPR_2026M0x_TARIFF_PLACEMAT` | Machine-readable BoC tariff-rate charts |
