# tariff_import_model — adjusting Canadian imports for the Canada–US tariff war

This model turns Canadian counter-tariffs, plus any non-tariff shift away from US goods, into quarterly paths for **real imports and customs import values by sector and source** (US, Mexico, China, EU, Other). It is meant to sit alongside `tariff_price_model` (the IO price layer). The price model gives price effects, and this model gives the import volumes and the trade diversion.

> **The sample data is illustrative.** Files named `*_ILLUSTRATIVE.csv` contain round numbers chosen so the pipeline runs. Replace them with CIMT and Finance Canada data before using the output. See *Workflow* below.

## Model

The model is applied one sector *s* at a time. Hats denote log deviations from a no-new-tariff baseline.

1. **Effective tariff.** τ_sj,t = rate × coverage × (1 − remission) × share of the quarter in force. This uses the same weighting as BoC MPR Oct 2025 (ref A2).
2. **Landed price.** ln p_sj = ln(1 + φ_s τ_sj) + IO price effect + preference shifter. φ ≈ 1 (refs B2, B3).
3. **Lower nest (choice of source).** Imports are CES across sources with elasticity σ_s (ref B1). Source shares follow m_j/M = w_j (p_j / P_M)^(−σ). This is the **trade-diversion** channel.
4. **Upper nest (domestic vs imported).** Total imports follow M = ω D (P_M/P)^(−η), with η ≈ 1 (ref B4). This is the **substitution toward domestic goods** channel.
5. **Activity.** ln D = α × (import-weighted final demand deviation), with α ≈ 1.5 (ref B5). Supply this from your macro scenario, for example Moody's scenario minus baseline.
6. **Dynamics.** Each source moves toward its long-run target with partial adjustment λ per quarter (ref B5). λ is calibrated to the 2025 episode.
7. **Customs value.** Customs value = quantity × (1 − (1 − φ)τ). When φ < 1, foreign exporters absorb part of the tariff.

Two scenarios ship with the project:

| Config | What it adds |
|---|---|
| `config/counter_tariffs_2026.yaml` | The tariff channel and the activity channel |
| `config/counter_tariffs_2026_buy_canadian.yaml` | Adds a fading preference shift against US goods. BoC (ref A3) attributes part of the drop in US imports to factors other than tariffs. |

The tariff timeline in the sample:

| Date | Measure |
|---|---|
| Mar–Apr 2025 | Counter-tariffs: 25% general, steel/aluminum, and autos |
| 1 Sep 2025 | Repeal of everything except steel, aluminum and autos |
| 8 Sep 2026 | New 15/25/50% list in response to US s.338; steel/aluminum raised to 50% |

## Layout

```
src/tariff_import_model/
  engine.py      nested-CES + activity + partial adjustment; aggregation and source shares
  tariffs.py     measures -> quarterly effective tariffs; HS-list builder; BoC-style average tariff
  calibrate.py   grid search of σ scale and λ against observed US-share change (2025 episode)
  run.py         YAML-driven runner -> Excel (total, by_source, by_sector, shares, tariff check, detail)
config/          scenario YAMLs
data/sample/     elasticities.csv, HS->sector concordance template, illustrative inputs
docs/REFERENCES.md   annotated sources, mapped to each parameter
tests/           8 unit tests (theory limits, diversion sign, convergence, HS build, calibration recovery)
```

## Run

```bash
pip install -e ".[dev]"
pytest -q
python -m tariff_import_model.run config/counter_tariffs_2026.yaml   # -> output/counter_tariffs_2026.xlsx
```

## Workflow to make it production-grade

1. **Baseline.** Take 2024 imports by HS6 and **country of origin** from CIMT or StatCan 12-10-0178. Map HS6 to sectors with `hs_concordance_TEMPLATE.csv`, then write `[sector, source, value]`.
2. **Tariff measures.** Load the Finance Canada HS lists (A5, A6) as `[measure_id, hs, rate]`, plus a meta table with dates and remission shares. Run `tariffs.build_measures_from_hs(...)` to get the sector coverage shares and value-weighted rates.
3. **Check the tariff rate.** `avg_tariff_check` for 2026Q4 should land near BoC's **3.9%** (A1). The illustrative inputs give 3.1%. Remissions are the usual source of a gap.
4. **Elasticities.** Replace σ in `elasticities.csv` with import-weighted medians from the Fontagné–Guimbard–Orefice GTAP file (B1). Keep η ≈ 1 and α ≈ 1.5 unless you have your own estimates.
5. **Calibrate λ and the σ scale.** Use monthly 2025 CIMT data on the counter-tariff sectors with `calibrate.grid_calibrate`. Then check out of sample: after the September 2025 repeal, the model should reproduce the partial reversal BoC reports (A3).
6. **Link the price model.** Write the `tariff_price_model` P output as `[quarter, sector, source, value]` (log price change) and set `inputs.io_price`. Use a domestic price effect for the upper nest if you extend `long_run_target(domestic_price=...)`.
7. **Activity.** Set `activity` to the import-weighted final-demand deviation from your macro scenario. Weight consumption, investment, government spending and exports by their import content. The StatCan supply-use or IO tables give those import shares, and they are the same tables your IO price model already uses.

## Sample results (illustrative inputs, tariff + activity scenario)

| | 2025Q3 | 2026Q2 (after repeal) | 2027Q4 |
|---|---|---|---|
| Real imports from US | −4.8% | −4.3% | −7.7% |
| Real imports from Mexico | +3.7% | +3.1% | +3.8% |
| US share in tariffed sectors | −2.1 pp | −1.6 pp | −2.8 pp |

The direction and the partial reversal after September 2025 match BoC's description. The magnitudes depend on the illustrative baseline and coverage inputs.

## Known limits / extensions

- Foreign export supply is assumed horizontal. For terms-of-trade effects, add an upward-sloping export supply (ω*) as in Fajgelbaum et al. (2020).
- There is no explicit transshipment channel. Use 12-10-0178 to split imports by origin and export country, and model the shift away from US routing (A3) as a cost shifter.
- Inputs into exports (about one-fifth US content, per A3) are captured only through activity. A further extension would drive intermediate imports from the export forecast.
